﻿using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Trainer
{
    public partial class AssignedVisit : System.Web.UI.Page
    {
        long _biodataid = 0;
        long _CurrentTrainerID;

        ConnectionManager _connMgr = new ConnectionManager();

        protected void Page_Load(object sender, EventArgs e)
        {
            _biodataid = Convert.ToInt64(Session["active_biodataid"]);

            var _biodataidd = _biodataid;



          var  displayProfile = _connMgr.displayTrainerProfile(_biodataid);

            if (displayProfile != null && displayProfile.Rows.Count > 0)
            {

                TrainerID.Value = displayProfile.Rows[0]["ID"].ToString();

            }

           var  _CurrentTrainerID = Convert.ToInt64(TrainerID.Value);

            var result = _connMgr.GETASSIGNEDVISITBYID2(_CurrentTrainerID);
            if (result == null || result.Rows.Count <=0)
            {
                lblalert.Text = ShowError("Not Yet Assigned Any Officer .");
            }

            gvState.DataSource = result;
            gvState.DataBind();


        }
        public string ShowSuccess(string Message)
        {
            return "<div class='alert alert-success alert-dismissable'> <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>" + Message + " </div>";
        }


        public string ShowError(string Message)
        {

            return "<div class='alert alert-danger alert-dismissable'> <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>" + Message + " </div>";

        }
    }
}