﻿using NIOB.Util;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Trainer
{
    public partial class UserProfile : System.Web.UI.Page
    {
        ConnectionManager connMgr = new ConnectionManager();

        int _biodataid = 0;

        DataTable displayProfile = null;
        Utility utilities = new Utility();

        protected void Page_Load(object sender, EventArgs e)
        {
            _biodataid = Convert.ToInt32(Session["active_biodataid"]);

            if (!Page.IsPostBack)
            {


                // retrieve from the  connection manager return the datatable.

                displayProfile = connMgr.displayTrainerProfile(_biodataid);

                if (displayProfile != null && displayProfile.Rows.Count > 0)
                {
                    compRegNumber.Value = displayProfile.Rows[0]["COMPANYREG"].ToString();
                    notp.Value = displayProfile.Rows[0]["NAMEOFTRAININGPROVIDER"].ToString();
                    contactPerson.Value = displayProfile.Rows[0]["CONTACTPERSON"].ToString();

                    uniqueid.Value = displayProfile.Rows[0]["UNIQUEID"].ToString();
                    // dor.Value = displayProfile.Rows[0]["DATEOFREG"].ToString();
                    phonenumber.Value = displayProfile.Rows[0]["PHONENUMBER"].ToString();
                    email.Value = displayProfile.Rows[0]["EMAIL"].ToString();
                    officeAddress.Value = displayProfile.Rows[0]["OFFICEADDRESS"].ToString();
                  
                
                }


            }
        }


        public bool Admin_UpdateTrainerInfo(string _companyRegNumber, string _nameofTrainingProvider,
        string _contactPerson, string _phonenumber, string _emailAddress, string _officeAddress)
        {
            bool updateRecord = false;
            int biodataID = _biodataid;
            

            OracleConnection conn = new OracleConnection();
            // OracleDataAdapter da;
            try
            {

                conn = connMgr.getConnection();
                //using (OracleConnection conn = new OracleConnection())
                //{
                using (OracleCommand cmd = new OracleCommand("UPDATE_TRAINERINFO", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new OracleParameter("V_COMPANYREG", OracleDbType.Varchar2, _companyRegNumber, ParameterDirection.Input));
                    cmd.Parameters.Add(new OracleParameter("V_NOTP", OracleDbType.Varchar2, _nameofTrainingProvider, ParameterDirection.Input));
                    cmd.Parameters.Add(new OracleParameter("V_CONTACTPERSON", OracleDbType.Varchar2, _contactPerson, ParameterDirection.Input));
                    cmd.Parameters.Add(new OracleParameter("V_OFFICEADDRESS", OracleDbType.Varchar2, _officeAddress, ParameterDirection.Input));
                    cmd.Parameters.Add(new OracleParameter("V_EMAIL", OracleDbType.Varchar2, _emailAddress, ParameterDirection.Input));
                    cmd.Parameters.Add(new OracleParameter("V_PHONENUMBER", OracleDbType.Varchar2, _phonenumber, ParameterDirection.Input));
                    cmd.Parameters.Add(new OracleParameter("V_BIODATAID", OracleDbType.Int32, Convert.ToInt32(biodataID), ParameterDirection.Input));


                    if (conn.State != ConnectionState.Open)
                    {
                        conn.Open();
                    }
                    try
                    {
                        cmd.ExecuteNonQuery();
                        updateRecord = true;
                    }
                    catch (Exception ex)
                    {

                    }

                }

                // }

            }
            catch (Exception ex)
            {

            }

            return updateRecord;
        }

        

        protected void updateProfile_Click(object sender, EventArgs e)
        {

            bool updatetrainer = Admin_UpdateTrainerInfo(compRegNumber.Value, notp.Value, contactPerson.Value, phonenumber.Value, email.Value, officeAddress.Value);

            if (updatetrainer == true)

                updateDisplay.Text = utilities.ShowSuccess("Record Update Successfully.");
            else
                updateDisplay.Text = utilities.ShowError("Record Update Failed.");



        }
    }
}