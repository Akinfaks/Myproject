﻿var ongoing = 0, pending = 0, completed = 0, approved = 0;
$("#user_fullname").ready(function () {
    $("#fullname").html(function () {
        return $("#user_fullname").html();
    })
});

//get total records
//Send the AJAX call to the server
$(function () {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetPaymentDue",
        data: '',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            console.log(result)
            if (result.d != "") {
                $("#div_duepayment").css("display", "block");
                var html = "";
                if (data.length != 0) {
                    console.log(data)
                    for (var i = 0; i < data.length; i++) {
                        if (i == 3) break;
                        var item = data[i];

                        html += "<tr class='spaceunder'><td>" + item.ITEM + "</td><td>" + item.DESCRIPTION + "</td><td> ₦ " + item.PRICE + "</td><td><a onclick='makePayment(\"" + item.ID + "\")' style='text-align:left; cursor: pointer;'><b>Pay</b></a></td></tr>";
                    }
                    $("#tbody").html(html);

                } 
            }
            else {
                $("#div_nopayment").css("display", "block");
            }
        }
    });
})

function makePayment(item) {
    sessionStorage.setItem('itemID', item);
    window.location = "Payment";
}

//get Get Training Overview
//Send the AJAX call to the server
$(function () {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetUserTrainings",
        data: '{"filter":""}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            console.log(result)
            if (result.d != "") {
                if (data.length != 0) {
                    console.log(data)
                    
                    for (var i = 0; i < data.length; i++) {                       
                        var item = data[i];
                        incrementStatus(item.STATUS);
                    }
                }
            }
        }
    });
})

function incrementStatus(statusid) {
    switch (statusid) {
        case 1:
            pending++;
            $("#pending").html(pending);
            break;
        case 2:
            ongoing++;
            $("#ongoing").html(ongoing);
            break;
        case 3:
            completed++;
            $("#completed").html(completed);
            break;
        case 4:
            approved++;
            $("#approved").html(approved);
            break;
        default:
            return "";
    }
}

//Get News Overview
//Send the AJAX call to the server
$(function () {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetNews",
        data: '',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            console.log(result)
            if (result.d != "") {
                if (data.length != 0) {
                    var html = "";
                    for (var i = 0; i < data.length; i++) {
                        var item = data[i];
                        if (i == 5) break;

                        html += "<li><a style='cursor:pointer' onclick='viewNewsbyID(" + item.ID + ")'>" + (item.TITLE).split(0, 120) + "</a></li>"
                    }

                    $("#newsoverview").append(html);
                }
            }
        }
    });
})

function viewNewsbyID(newsId) {
    sessionStorage["activeNews"] = newsId;
    window.location = "News";
}