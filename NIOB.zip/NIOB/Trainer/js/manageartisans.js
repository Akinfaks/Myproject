﻿var totalrecords = 0, totalpages = 0; var _data = null, activeRecord = null, activeFilter = "All";
var pagecount = 10, searchstring = "", from = "", to = "", sortstring = "";

getTotalRecords("");

$(document).ready(function () {
    populateTable();
})

function getTotalRecords() {
    //populate table
    //Send the AJAX call to the server
    $(function () {
        totalrecords = 0;

        $.ajax({
            type: "POST",
            url: "../Service.asmx/GetArtisanInfo",
            data: '{filter:"' + searchstring + '"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                var data = eval(result.d);
                if (result.d != "") {
                    if (data.length != 0) {
                        totalrecords = data.length;
                    }
                }
            }
        });
    })
}

function populateTable() {
    //check total records
    if (totalrecords == 0) {
        $('#norecord').html("<center>No record found</center>")
    }
    else {
        if (totalrecords % pagecount > 0) {
            totalpages = totalrecords / pagecount + 1;
        } else {
            totalpages = totalrecords / pagecount;
        }
        $('#pagination').twbsPagination({
            totalPages: totalpages,
            visiblePages: 5,
            onPageClick: function (event, page) {
                //$('#page-content').text('Page ' + page);
                var html = "";
                $.ajax({
                    type: "POST",
                    url: "../Service.asmx/GetArtisanInfoBatch",
                    data: '{pageno:"' + page + '",pagecount: "' + pagecount + '",searchstring: "' + searchstring + '",from: "' + from + '",to:"' + to + '",sortstring: "' + sortstring + '"}',
                    contentType: "application/json; charset=utf-8",
                    //dataType: "json",
                    async: true,
                    success: function (result) {
                        var data = eval(result.d);
                        if (result.d != "") {
                            if (data.length != 0) {
                                console.log(data)
                                _data = data;
                                $.each(data, function (index, item) {
                                    var editable = item.EDITABLE == "1" ? "Pending" : "Submitted";
                                    //var status = item.ASSESSMENTSTATUS == null ? "NOT VISITED" : item.ASSESSMENTSTATUS;
                                    html += "<tr onclick='openModal(\"" + item.ID + "\")' style='cursor:pointer'><td>" + item.R + "</td><td>" + item.FIRSTNAME + " " + item.SURNAME + "</td><td>" + item.EMAIL + "</td><td>" + item.PHONENUMBER + "</td><td>" + item.TRAININGSTATUS + "</td><td>" + editable + "</td></tr>";
                                });
                                $("#tbody").html(html);
                            }
                        }
                    }
                });
            }
        });
    }
}


//manage modal box
var modal = document.getElementById('myModal');
// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];


function showModal() {
    modal.style.display = "block";
}
function hideModal() {
    modal.style.display = "none";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function () {
    hideModal()
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
    if (event.target == modal) {
        hideModal();
    }
}

function openModal(id) {
    $("#artisanphoto").prop("src","");
    showModal();
    for (var i = 0; i < _data.length; i++) {
        item = _data[i];
        
        if (item.ID == id) {
            activeRecord = item;
            //get photograph
            getPhoto(item.ID);
            $("#uniqueid").html(item.UNIQUEID);
            $("#artisanname").html(item.FIRSTNAME + " " + item.SURNAME);
            $("#email").html(item.EMAIL);
            $("#mobile").html(item.PHONENUMBER);
            $("input#" + (item.TRAININGSTATUS).toLowerCase().replace(" ", "")).prop("checked", true);
            $("#result").val(item.RESULT);
            $("#recommendation").val(item.RECOMMENDATION);

            //disable input if submitted
            if (item.EDITABLE == 0) {
                $("input[name=status]").prop("disabled", true);
                $("#result").prop("disabled", true);
                $("#recommendation").prop("disabled", true);
                $("a.btn_update").css("display", "none");

            } else {
                $("input[name=status]").prop("disabled", false);
                $("#result").prop("disabled", false);
                $("#recommendation").prop("disabled", false);
                $("a.btn_update").css("display", "inline");
            }


            break;
        }
    }
}

function getPhoto(id) {
    console.log(id)
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetPhotographByID",
        data: '{id:"' + id + '"}',
        contentType: "application/json; charset=utf-8",
        //dataType: "json",
        async: true,
        success: function (result) {
            console.log(result)
            var data = eval(result);
            if (result.d != "") {
                if (data.length != 0) {
                    $("#artisanphoto").prop("src", "data:image/jpeg;base64," + data.d);
                    data.dispose;
                }
            }
        }
    });
}

//manage tab filter on click
$("ul#filternavbar li a").click(function (event) {
    var filter = event.toElement.innerText;
    activeFilter = filter;
    refreshView();
})

//save artisan assessment 
function updateAssessment(action) {
    if (action == "submit" && !confirm("You will not be able to edit assessment after submitting!")) return;
    if (activeRecord != null && activeRecord.UNIQUEID == $("#uniqueid").html()) {
        var artisanid = activeRecord.ID,
            status = $("input[name=status]:checked").val(),
            result = $("#result").val(),
            recom = $("#recommendation").val();

        //updateartisanAssessment
        //Send the AJAX call to the server
        $.ajax({
            type: "POST",
            url: "../Service.asmx/UpdateArtisanAssessment",
            data: '{id:"' + artisanid + '",status: "' + status + '",result: "' + result + '",recommendation: "' + recom + '", action: "' + action + '"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                console.log(result)
                var data = eval(result);
                console.log(data.d)
                if (data.d) {
                    action == "submit" ? alert("submitted successfully") : alert("saved successfully");
                    refreshView();
                }
            }
        });
        hideModal();
    }
}

function getStatusID(filter) {
    switch (filter) {
        case "COMPLETED":
            return 1;
        case "UNCOMPLETED":
            return 2;
        case "ABSENT":
            return 0;
        default:
            return "";
    }
}

function refreshView() {
    //reset pagination
    $('#pagination').empty();
    $('#pagination').removeData("twbs-pagination");
    $('#pagination').unbind("page");

    var html = ""; $("#norecord").html(""); $("#tbody").html("");
    searchstring = getStatusID(activeFilter);

    getTotalRecords();
    populateTable();
}