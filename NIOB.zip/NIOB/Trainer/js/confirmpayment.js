﻿var refno;
var price;
var display_msg;

$(document).ready(function () {
    refno = $("#ContentPlaceHolder1_refno").val();
    price = $("#ContentPlaceHolder1_price").val();
    display_msg = $("#message_lbl");
    payWithPaystack();
})

function payWithPaystack() {
    display_msg.html("Processing Transaction...");

    if (price == "" || refno == "") {
        window.location = "Payment";
        return;
    }

    var handler = PaystackPop.setup({
        key: 'pk_test_faee2a75ce31263ae15fc792666ace63824e198b',
        email: 'nnajiisrael@gmail.com',
        amount: price,
        callback_url: "PaymentSuccessfull?refno=" + refno,
        ref: refno,
        metadata: {
            custom_fields: [
               {
                   display_name: "Mobile Number",
                   variable_name: "mobile_number",
                   value: "+234805264687"
               }
            ]
        },
        callback: function (response) {
            display_msg.html("Transaction Successful...");
            logPaymentInfo(response.reference, "Payment", "Successful");
            window.location = "PaymentSuccessfull?refno=" + response.reference;
        },
        onClose: function () {
            display_msg.html("Cancelling Transaction...");
            logPaymentInfo(refno, "Payment", "Cancelled");
            alert('Transaction Cancelled..');
            window.location = "Payment";
        }
    });
    handler.openIframe();
}

function logPaymentInfo(reference, activetable, status) {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/LogPaymentInfo",
        data: '{refno:"' + reference + '", table:"' + activetable + '", status:"' + status + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            if (result.d != "") {
                if (data.length != 0) {
                    console.log(data)
                }
            }
        }
    });
}
