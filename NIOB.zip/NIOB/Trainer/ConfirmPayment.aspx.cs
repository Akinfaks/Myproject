﻿using NIOB.BusinessLogic;
using NIOB.BusinessObjects;
using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Trainer
{
    public partial class ConfirmPayment : System.Web.UI.Page
    {
        Logic logic = new Logic();
        String _username;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //get username
                IPrincipal principal = Thread.CurrentPrincipal;
                IIdentity identity = principal == null ? null : principal.Identity;
                _username = identity == null ? "" : identity.Name;

                if (_username == "") Response.Redirect("../Login");
                if (Session["selectedItems"] == null) Response.Redirect("../Payment");

                //set price and refno variables
                int _totalprice = 0;
                string _refno;
                //get selected item
                string itemlist_query = Session["selectedItems"].ToString();
                string[] selecteditemlist = itemlist_query.Split(',');
                int number;

                //get and check if refno exist in paymentlog table, if true, regenerate
                _refno = Guid.NewGuid().ToString().Replace("-", "").Substring(0,20).ToUpper();

                foreach (String item in selecteditemlist)
                {
                    //get payment item class
                    Payment_Item payitem = new Payment_Item();
                    payitem = logic.GetPaymentItemByID(Convert.ToInt32(item));

                    //get payment info class
                    Payment_Info payinfo = new Payment_Info();
                    if (payitem != null)
                    {
                        payinfo.ItemID = payitem.ID;
                        payinfo.Price = payitem.Price;
                        payinfo.RefrenceNo = _refno;
                        payinfo.Status = 0;

                        _totalprice += Int32.TryParse(payitem.Price, out number) ? Convert.ToInt32(payitem.Price) : _totalprice;

                        //save transaction in paymentinfo(individual payment item)
                        logic.InsertUserPaymentInfo(_username, payinfo);
                    }                    

                    
                    //if (selecteditemlist.Contains(item.ID.ToString()))
                    //{
                        
                    //}
                }

                //get payment lgo class
                if (_totalprice > 0)
                {
                    Payment_Log paylog = new Payment_Log();
                    paylog.PaymentType = "Dues";
                    paylog.Amount = _totalprice.ToString();
                    paylog.ReferenceNo = _refno;
                    paylog.Status = 0;

                    //save transaction in paymentlog (one per transaction)
                    logic.InsertPaymentLog(_username, paylog);

                    price.Value = (_totalprice * 100).ToString();
                    refno.Value = _refno;
                    Session["activeRedirect"] = "Payment";
                    Session["refno"] = _refno;
                }
                else
                {
                    Response.Redirect("Payment");
                }                
            }
            else
            {
                Response.Redirect("../Login");
            }
            
        }
    }
}