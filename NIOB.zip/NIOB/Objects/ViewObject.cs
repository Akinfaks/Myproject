﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NIOB.BusinessObjects
{
    public class ViewObject
    {
        public Payment_Item paymentItem { get; set; }
    }

    public class Payment_Item
    {
        public int ID { get; set; }
        public string Item { get; set; }
        public string Description { get; set; }
        public string Price { get; set; }
        public string DateCreated { get; set; }
    }

    public class AvailableTraining
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Venue { get; set; }
        public string Duration { get; set; }
        public string StartDate { get; set; }
        public string Price { get; set; }
    }
}