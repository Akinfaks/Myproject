﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Register
{
    public partial class ActivationMail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string actionLink = "";

            if (Request.QueryString["actionLink"] == null) Response.Redirect("Error", true);
            else
            {
                actionLink = Request.QueryString["actionLink"].ToString();

                actionLinkBtn.InnerHtml = "<a href='http://154.113.0.163:1010/niob-dev/Register/Authentication?key=" + actionLink + "' target='_blank' style='font-weight:bold; color:#ffffff; font-size:16px; font-family:Helvetica, Arial, sans-serif; text-decoration:none; display:inline-block;'><span style='color:#ffffff;'> &nbsp; &nbsp; Activate my account &nbsp; &nbsp;</span></a>";
            }
        }
    }
}