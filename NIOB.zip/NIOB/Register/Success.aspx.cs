﻿using NIOB.BusinessLogic;
using System;
using System.Data;
using System.IO;
using System.Net;
using System.Web.UI;

namespace NIOB.Artisan
{
    public partial class Success : System.Web.UI.Page
    {
        Logic logic = new Logic();
        private ChamsMailService.WebServiceSoapClient _mailService = new ChamsMailService.WebServiceSoapClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            active_email.Value = Session["active_email"] != null ? Session["active_email"].ToString() : "";

        }

        protected void ResendActivationLink_Click(object sender, EventArgs e)
        {
            string email = Session["active_email"].ToString();

            //send confirmation mail to user email
            try
            {
                DataTable dt = new DataTable();

                dt = logic.GetUserInfoByEmail(email);

                if (dt != null & dt.Rows.Count > 0)
                {
                    string key = dt.Rows[0]["KEY"].ToString();
                    string surname = dt.Rows[0]["SURNAME"].ToString();
                    string message = WebPageToCode("http://localhost/niob-dev/Register/ActivationMail?actionLink=" + key);
                    if (_mailService.sendmail1(email, surname, message))
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Activation Link resent Successfully.');", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Error!');", true);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        public String WebPageToCode(string Url)
        {

            HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(Url);
            myRequest.Method = "GET";
            WebResponse myResponse = myRequest.GetResponse();
            StreamReader sr = new StreamReader(myResponse.GetResponseStream(), System.Text.Encoding.UTF8);
            string result = sr.ReadToEnd();
            sr.Close();
            myResponse.Close();

            return result;
        }
    }
}