﻿using NIOB.BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Register
{
    public partial class Authentication : System.Web.UI.Page
    {
        Logic logic = new Logic();
        protected void Page_Load(object sender, EventArgs e)
        {
            string activationKey = Request.QueryString["key"];
            bool activate = false;
            if (!Page.IsPostBack)
            {
                activate = logic.ActivateAccount(activationKey);
                if (activate)
                {
                    displayText.InnerHtml = "<h5 style='color:darkgreen'>You have been successfully authenticated. Click <a href='../Login'>here to login to your account.</a></h5>";

                }
                else
                {
                    displayText.InnerHtml = "<h6 style='color:red'>An error occured while processing your request. Try again later or Click <a href='/Login'>here to register.</a></h6>";
                }
            }
        }
    }
}