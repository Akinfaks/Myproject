﻿using NIOB.Util;
using NIOB.BusinessLogic;
using NIOB.BusinessObjects;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Security.AccessControl;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Net;

namespace NIOB.Register
{
    public partial class Artisan : System.Web.UI.Page
    {
        Logic logic = new Logic();      //instantiate logic class
        ////call email service
        private ChamsMailService.WebServiceSoapClient _mailService = new ChamsMailService.WebServiceSoapClient();
        SendEmail mailSv = new SendEmail();

        protected void Page_Load(object sender, EventArgs e)
        {
            populateDDLs();
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            UserObject _user = new UserObject();     //instantiate user object
            //validate required field
            if (!checkValidation())
            {
                Response.Redirect( "Error", true);
            }

            //populate user object
            _user = populateUserObject(); 
            
            //initiate insert function
            long biodataid = logic.InsertUser(_user);
            if (biodataid > 0)
            {
                //save previous employment 
                insertPreviousEmp(biodataid);

                //save images and document to memory/db
                saveDocumentToFile(biodataid);

                new Thread(() =>
                {   
                    //send activation key to mail email
                    sendMailtoUser(_user);
                }).Start();

                //redirect to success page
                Session["active_email"] = email.Value.Trim();
                Response.Redirect("Success");
            }
            else
            {
                
            }
        }        

        private UserObject populateUserObject()
        {
            UserObject _user = new UserObject();     //instantiate user object

            //instantiate all user info class
            Biodata userbiodata = new Biodata();
            Tbl_User usertbl_user = new Tbl_User();
            Employment_Info userempinfo = new Employment_Info();
            Education_info usereduinfo = new Education_info();
            Address_Info useraddressinfo = new Address_Info();
            Association userassociation = new Association();
            ActivationKey useractivationkey = new ActivationKey();
            UserPhotograph userphotograph = new UserPhotograph();

            ////collect html field values into user info params
            //biodata
            userbiodata.Title = title.Value.ToUpper();
            userbiodata.Firstname = firstname.Value.ToUpper().Trim();
            userbiodata.Surname = lastname.Value.ToUpper().Trim();
            userbiodata.DOB = Request.Form["dob"] == null ? "0" : Request.Form["dob"].ToString();
            userbiodata.Gender = gender.Value.ToUpper();
            userbiodata.PhoneNumber = phoneNo.Value.ToUpper().Trim();
            userbiodata.StateID = Request.Form["state"] == null ? "0" : Request.Form["state"].ToString();

            //tbl_user info
            usertbl_user.Username = username.Value.Trim();
            usertbl_user.Password = Common.EncryptText(password.Value);
            usertbl_user.Email = email.Value.Trim();
            usertbl_user.UserType = 1;

            //address info
            useraddressinfo.Street = houseAddress.Value.Trim();
            useraddressinfo.LGA = Request.Form["lga"] == null ? "0" : Request.Form["lga"].ToString();
            useraddressinfo.State = userbiodata.StateID;

            //employment info
            userempinfo.Title = designation.Value.ToUpper().Trim();
            userempinfo.Employer = employername.Value.ToUpper().Trim();
            userempinfo.Scope = scopeofresp.Value.Trim();
            userempinfo.Address = employeraddress.Value.Trim();
            userempinfo.StartDate = Request.Form["appointmentdate"] == null ? "0" : Request.Form["appointmentdate"].ToString();

            //education info
            usereduinfo.Primary = primary.Value.ToUpper().Trim();
            usereduinfo.Secondary = secondary.Value.ToUpper().Trim();
            usereduinfo.Technical = technical.Value.ToUpper().Trim();
            usereduinfo.Tertiary = tertiary.Value.ToUpper().Trim();
            usereduinfo.PrimaryCert = primaryCert.Value.ToUpper();
            usereduinfo.SecondaryCert = secondaryCert.Value.ToUpper();
            usereduinfo.TechnicalCert = technicalCert.Value.ToUpper();
            usereduinfo.TertiaryCert = tertiaryCert.Value.ToUpper();
            
            //association
            userassociation.Name = associationname.Value.ToUpper().Trim();
            userassociation.PositionHeld = positionheld.Value.ToUpper().Trim();
            userassociation.Datejoined = Request.Form["assodatejoined"] == null ? "0" : Request.Form["assodatejoined"].ToString();

            //generate activation key and load user activation property
            useractivationkey = getActivationKey();

            //get user photograph 
            userphotograph = getUserPhotograph();

            //inject user info into user object
            _user.biodata = userbiodata;
            _user.edu_info = usereduinfo;
            _user.emp_info = userempinfo;
            _user.tbl_user = usertbl_user;
            _user.association = userassociation;
            _user.address_info = useraddressinfo;

            _user.acticationkey = useractivationkey;
            _user.photo = userphotograph;
            return _user;
        }

        private UserPhotograph getUserPhotograph()
        {
            UserPhotograph photo = new UserPhotograph();
            HttpPostedFile hpf = Request.Files["photo"] as HttpPostedFile;
            photo.Photograph = convertPostedFiletoImage(hpf);
            return photo;
        }

        private ActivationKey getActivationKey()
        {
            ActivationKey useractKey = new ActivationKey();
            string key = Guid.NewGuid().ToString().Replace("-", "").ToUpper();
            useractKey.ActivationStatus = 0;
            useractKey.EmailAddress = email.Value;
            useractKey.Key = key;
            return useractKey;            
        }

        private void insertPreviousEmp(Int64 biodataid)
        {
            Prev_Employment_Info prev_emp_info = new Prev_Employment_Info();
            for (int i = 0; i < 5; i++)
            {
                string preEmpName = i == 0 ? "prev_employername" : "prev_employername" + i;
                string datefrom = i == 0 ? "datefrom" : "datefrom" + i;
                string dateto = i == 0 ? "dateto" : "dateto" + i;

                if (Request.Form[preEmpName] != null)
                {
                    Employment_Info prev_emp = new Employment_Info();
                    prev_emp.BiodataID = biodataid;
                    prev_emp.Employer = Request.Form[preEmpName] == null ? "" : Request.Form[preEmpName].ToString();
                    prev_emp.StartDate = Request.Form[datefrom] == null ? null : Request.Form[datefrom].ToString();
                    prev_emp.EndDate = Request.Form[dateto] == null ? null : Request.Form[dateto].ToString();
                    logic.InsertPrev_Emp(prev_emp);
                }
            }
        }

        //**************Backend Validations***************//
        
        public bool checkValidation()
        {
            if (title.Value == "" || firstname.Value == "" || lastname.Value == "" || gender.Value == "" || username.Value == "" || password.Value == "" || password.Value.Length < 8)
            {
                return false;
            }

            if (checkForEmail(email.Value.Trim()) != true)
            {
                return false;
            }
            return true;            
        }

        public static bool checkForEmail(string email)
        {
            bool IsValid = false;
            Regex reg = new Regex(@"^([\w\.\-+)@([\w\-]+)((\.(\w){2,3})+)$");
            if (reg.IsMatch(email))
                IsValid = true;
            return IsValid;
        }

        public static bool checkForPhoneNumber(string phone)
        {
            bool IsValid = false;
            Regex r = new Regex(@"^[0]\d{10}$");
            if (r.IsMatch(phone))
                IsValid = true;
            return IsValid;
        }       
        //************************************************//

        private void populateDDLs()
        {
            //Populate your stateOfOriginDDL
            state.DataSource = logic.GetStates();
            state.DataTextField = "STATENAME";
            state.DataValueField = "STATEID";
            state.DataBind();
            state.Items.Insert(0, new ListItem("Select State", ""));
            lga.Items.Insert(0, new ListItem("Select LGA", ""));
        }

        private byte[] convertPostedFiletoImage(HttpPostedFile hpf)
        {
            int hpf_length = hpf.ContentLength;
            // Check file size (mustn’t be 0)
            if (hpf_length == 0) return null;

            // Read file into a data stream
            byte[] myData = new Byte[hpf_length];
            hpf.InputStream.Read(myData, 0, hpf_length);

            return myData;
        }

        private void saveDocumentToFile(long biodataid)
        {
            try
            {
                foreach (string _file in Request.Files)
                {
                    HttpPostedFile hpf = Request.Files[_file] as HttpPostedFile;
                    if (hpf.ContentLength == 0) continue;
                    if (_file == "photo") continue; 
                    string rootParent, savedFolderName, savedFilename, documentType = "";
                    var path = ""; string doc_name = "";
                   
                    
                    doc_name = _file;
                    //doc_name = Regex.Replace(doc_name, @"\s|[^0-9a-zA-Z]+", String.Empty).ToUpper();
                    documentType = getDocumentName(_file.ToString());
                    var fileName = Path.GetFileName(hpf.FileName);

                    // Check file extension (must be JPG)
                    string file_ext = Path.GetExtension(hpf.FileName).ToLower();
                    if (file_ext != ".jpg" && file_ext != ".jpeg" && file_ext != ".pdf") return;

                    // Read file into a data stream
                    byte[] myData = convertPostedFiletoImage(hpf);

                    // Save the stream to disk
                    rootParent = new DirectoryInfo(Server.MapPath("~/")).FullName;
                    savedFolderName = rootParent + "Content\\Uploads\\" + documentType + "\\";

                    //using (new Impersonator("Coleola", "Coleola", "password"))
                    //{
                    //    // The following code is executed under the impersonated user.
                        if (!Directory.Exists(savedFolderName)) Directory.CreateDirectory(savedFolderName);

                        ////grant write access to folder
                        //writeAccess.AddDirectorySecurity(savedFolderName, @"Coleola\Coleola", FileSystemRights.ReadData, AccessControlType.Allow);

                        savedFilename = biodataid.ToString(); ;
                        path = Path.Combine(savedFolderName, savedFilename + file_ext);
                        FileStream fs = new FileStream(path, FileMode.Create);
                        fs.Write(myData, 0, myData.Length);
                        fs.Close();

                        ////remove write access to folder
                        //writeAccess.RemoveDirectorySecurity(savedFolderName, @"Coleola\Coleola", FileSystemRights.ReadData, AccessControlType.Allow);
                    //}
                    saveDocumentInfo(biodataid, documentType, path);
                }
            }
            catch (Exception e)
            {

            }
        }

        private void saveDocumentInfo(Int64 biodataid, string documentType,string path)
        {
            Document_Info docInfo = new Document_Info();
            docInfo.BiodataID = biodataid;
            docInfo.DocumentType = documentType;
            docInfo.DocumentUrl = path;

            logic.saveDocumentInfo(docInfo);
        }

        private string getDocumentName(string doc_name)
        {
            switch (doc_name)
            {
                case "photo":
                    return "Photograph";
                case "primarycertUpload":
                    return "PrimaryCertificate";
                case "secondarycertUpload":
                    return "SecondaryCertificate";
                case "technicalcertUpload":
                    return "TechnicalCertificate";
                case "tertiarycertUpload":
                    return "TertiaryCertificate";
                default: return "";
            }
        }

        private void sendMailtoUser(UserObject user)
        {
            //send confirmation mail to user email
            try
            {
                string message = WebPageToCode("http://localhost/niob-dev/Register/ActivationMail?actionLink=" + user.acticationkey.Key);
                logic.sendMailtoUser(user.tbl_user.Email, user.biodata.Surname, message);
            }
            catch(Exception ex)
            {
                
            }
        }

        public String WebPageToCode(string Url)
        {

            HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(Url);
            myRequest.Method = "GET";
            WebResponse myResponse = myRequest.GetResponse();
            StreamReader sr = new StreamReader(myResponse.GetResponseStream(), System.Text.Encoding.UTF8);
            string result = sr.ReadToEnd();
            sr.Close();
            myResponse.Close();

            return result;
        }
    }
}