﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NIOB.Util;

namespace NIOB.Assessor
{
    public partial class AssignedVisit : System.Web.UI.Page
    {
            long _biodataid = 0;

            ConnectionManager _connMgr = new ConnectionManager();

            protected void Page_Load(object sender, EventArgs e)
            {
                _biodataid = Convert.ToInt64(Session["active_biodataid"]);

                var _biodataidd = _biodataid;

                var result = _connMgr.GETASSIGNEDVISITBYID(_biodataidd);
                if (result == null)
                {
                    lblalert.Text = ShowError("Not Yet Assigned Any Officer .");
                }

                gvState.DataSource = result;
                gvState.DataBind();


            }
            public string ShowSuccess(string Message)
            {
                return "<div class='alert alert-success alert-dismissable'> <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>" + Message + " </div>";
            }


            public string ShowError(string Message)
            {

                return "<div class='alert alert-danger alert-dismissable'> <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>" + Message + " </div>";

            }

    }
 }


