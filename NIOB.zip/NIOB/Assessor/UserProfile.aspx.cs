﻿using NIOB.Util;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Assessor
{
    public partial class UserProfile : System.Web.UI.Page
    {

        ConnectionManager connMgr = new ConnectionManager();
        long _biodataid = 0;
        DataTable displayProfile = null;
        Utility utilities = new Utility();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                _biodataid = Convert.ToInt64(Session["active_biodataid"]);

                displayProfile = connMgr.displayAssesorProfile(_biodataid);

                if (displayProfile != null && displayProfile.Rows.Count > 0)
                {
                    title.Value = displayProfile.Rows[0]["TITLE"].ToString();
                    firstname.Value = displayProfile.Rows[0]["FIRSTNAME"].ToString();
                    lastname.Value = displayProfile.Rows[0]["SURNAME"].ToString();
                    gender.Value = displayProfile.Rows[0]["GENDER"].ToString();
                    dob.Value = displayProfile.Rows[0]["DOB"].ToString();
                    phonenumber.Value = displayProfile.Rows[0]["PHONENUMBER"].ToString();
                    email.Value = displayProfile.Rows[0]["EMAIL"].ToString();
                    username.Value = displayProfile.Rows[0]["USERNAME"].ToString();
                    address.Value = displayProfile.Rows[0]["STREET"].ToString();
                    stateOfOrigin.Value = displayProfile.Rows[0]["STATENAME"].ToString();
                    lga.Value = displayProfile.Rows[0]["LGANAME"].ToString();

                    primary.Value = displayProfile.Rows[0]["PRIMARYSCH"].ToString();
                    secondary.Value = displayProfile.Rows[0]["SECONDARY"].ToString();

                    technical.Value = displayProfile.Rows[0]["TECHNICAL"].ToString();
                    tertiary.Value = displayProfile.Rows[0]["TERTIARY"].ToString();

                    primarycert.Value = displayProfile.Rows[0]["PRIMARY_CERT"].ToString();
                    secondarycert.Value = displayProfile.Rows[0]["SECONDARY_CERT"].ToString();
                    technicalcert.Value = displayProfile.Rows[0]["TECHNICAL_CERT"].ToString();
                    tertiarycert.Value = displayProfile.Rows[0]["TERTIARY_CERT"].ToString();

                    titledesg.Value = displayProfile.Rows[0]["OCCUPATION"].ToString();
                    empaddress.Value = displayProfile.Rows[0]["ADDRESS"].ToString();
                    empname.Value = displayProfile.Rows[0]["EMPLOYER"].ToString();
                    appdate.Value = displayProfile.Rows[0]["STARTDATE"].ToString();


                }
            }
        }


        public bool Admin_UpdateTrainerInfo(string _title, string _firstname,
                       string _lastname, string _phonenumber, string _address)
        {
            bool updateRecord = false;
            //long biodataID = _biodataid;
            long biodataID = Convert.ToInt64(Session["active_biodataid"]);

            OracleConnection conn = new OracleConnection();
            // OracleDataAdapter da;
            try
            {

                conn = connMgr.getConnection();
                //using (OracleConnection conn = new OracleConnection())
                //{
                using (OracleCommand cmd = new OracleCommand("UPDATE_ASSESORINFO", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new OracleParameter("V_TITLE", OracleDbType.Varchar2, _title, ParameterDirection.Input));
                    cmd.Parameters.Add(new OracleParameter("V_FIRSTNAME", OracleDbType.Varchar2, _firstname, ParameterDirection.Input));
                    cmd.Parameters.Add(new OracleParameter("V_SURNAME", OracleDbType.Varchar2, _lastname, ParameterDirection.Input));
                    cmd.Parameters.Add(new OracleParameter("V_PHONENUMBER", OracleDbType.Varchar2, _phonenumber, ParameterDirection.Input));
                    cmd.Parameters.Add(new OracleParameter("V_STREET", OracleDbType.Varchar2, _address, ParameterDirection.Input));
                    cmd.Parameters.Add(new OracleParameter("V_BIODATAID", OracleDbType.Int32, Convert.ToInt32(biodataID), ParameterDirection.Input));
                    if (conn.State != ConnectionState.Open)
                    {
                        conn.Open();
                    }
                    try
                    {
                        cmd.ExecuteNonQuery();
                        updateRecord = true;
                    }
                    catch (Exception ex)
                    {

                    }

                }

                // }

            }
            catch (Exception ex)
            {

            }

            return updateRecord;
        }


        protected void updateProfile_Click(object sender, EventArgs e)
        {

            bool updatetrainer = Admin_UpdateTrainerInfo(title.Value, firstname.Value, lastname.Value,  phonenumber.Value, address.Value);

            if (updatetrainer == true)

                updateDisplay.Text = utilities.ShowSuccess("Record Update Successfully.");
            else
                updateDisplay.Text = utilities.ShowError("Record Update Failed.");



        }
    }
}