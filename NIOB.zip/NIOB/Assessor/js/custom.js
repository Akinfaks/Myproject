﻿setActiveSidebar();
var username;

//get username from cookies on page load
$(function () {
    $(document).ready(function () {
        username = getCookie('UserdID');
        if (username == null)
            window.location = "/niob/Login";
        else
            localStorage.setItem("username", username);
    })
})

function getCookie(cookieName) {
    var cookieValue = document.cookie;
    var cookieStart = cookieValue.indexOf(" " + cookieName + "=");
    if (cookieStart == -1) {
        cookieStart = cookieValue.indexOf("=");
    }
    if (cookieStart == -1) {
        cookieValue = null;
    }
    else {
        cookieStart = cookieValue.indexOf("=", cookieStart) + 1;
        var cookieEnd = cookieValue.indexOf(";", cookieStart);
        if (cookieEnd == -1) {
            cookieEnd = cookieValue.length;
        }
        cookieValue = unescape(cookieValue.substring(cookieStart, cookieEnd));
    }
    return cookieValue;
}

function setActiveSidebar () {
    var url = window.location;
    var element = $('ul.nav-list li ul.submenu a').filter(function () {
        return this.href === url.href;
    }).parent();
    var parent_element = element.parent().parent();
    if (element.is('li')) {
        element.addClass('active');
        element.children(0).removeAttr("href");
    }
    if (parent_element.is('li')) {
        parent_element.addClass('active').addClass("open");
        parent_element.children(0).removeClass("dropdown-toggle");
        parent_element.children(0).children("b.arrow").css("display", "none");
    }
}

$("#sidebar > span").click(function() {
    $("#menu-toggler").click();
})

//***********add and delete implement on previous employment page
var count = 0;
$(function () {
    $(".add-button").click(function () {
        if (count >= 5) {
            alert("You cannot add more than 6 entries!!");
            return;
        }
        count++;
        var element = "<div class='col-md-2' id='photograph1" + count + "'><input style='height: 120px; width: 100%; margin-top: 15px;'  name='photograph1' disabled='disabled" + count + "'  /><br/><br/><a class='btn btn-danger custom-btn delete-button' style='display:inline;' onclick='deleteEntry(" + count + ")'> × Del </a></div>";
        $("#pixholder").append(element);
    })
});

function deleteEntry(index) {
    if (confirm("Are you sure?")) {
        $("#photograph1" + index).remove();
        count--
    }
}

        
function toggleIcon(e) {
    $(e.target)
        .prev('.panel-heading')
        .find(".more-less")
        .toggleClass('glyphicon-plus glyphicon-minus');
}
$('.panel-group').on('hidden.bs.collapse', toggleIcon);
$('.panel-group').on('shown.bs.collapse', toggleIcon);

