﻿var totalPayment = 0;
var username;

$(function () {
    $(document).ready(function () {
        //set username on pageload
        username = localStorage.getItem("username");

        //set checkbox to false on page ready //to handle backbutton
        $("input[type='checkbox']").prop("checked", false);
    })
})

$(function () {
    $("table.table").ready(function () {
        // Get pay item from sessionStorage
        var payItemID = sessionStorage.getItem('itemID');
        if (payItemID != null) {
            $("#cbox_" + payItemID).trigger("click");
        }
        sessionStorage.removeItem('itemID');
    })
})

//set variables to take payment items to update payment log on payclick
var selectedItems = [];

//sum selected payment on checkbox change
function addToPayment(id, itemID, price) {
    var elem = $("#" + id + " input[type='checkbox']");
    var total = $("#total_payment");
    total.val(" ₦ " + totalPayment);

    //add price if element is checked
    if (elem[0].checked) {

        //push selected items to list
        selectedItems.push(itemID)
        total.text(function () {
            totalPayment += parseInt(price)
            return " ₦ " + totalPayment;
        });
    } else {
        //remove selected items to list
        var index = selectedItems.indexOf(itemID.toString());
        if (index > -1) {
            selectedItems.splice(index, 1);
        }

        if (totalPayment != 0) {
            total.text(function () {
                totalPayment -= parseInt(price)
                return " ₦ " + totalPayment;
            });
        }        
    }
}

//call paystack payment gateway
function proceedToPayment() {
    if (selectedItems.length == 0) {
            alert("Select Item to make payment!");
            return;
    } 
    else {
        $("#ContentPlaceHolder1_selectedItems").val(selectedItems.join(","));
    }
}