﻿var totalrecords = 0, totalpages = 0;
var pagecount = 10, searchstring = "", from = "", to = "", sortstring = "";

//get total records
//Send the AJAX call to the server
$(function () {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetPaymentInfo",
        data: '',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            if (result.d != "") {
                var count = 0;
                if (data.length != 0) {
                    $.each(data, function (index, item) {
                        if (item.STATUS == "1") count++;
                    });

                    totalrecords = count;
                }
            }
        }
    });
})

$(document).ready(function () {
    //check total records
    if (totalrecords == 0) {
        $('#norecord').html("<center>No record found</center>")
    }
    else {
        if (totalrecords % pagecount > 0) {
            totalpages = totalrecords / pagecount + 1;
        } else {
            totalpages = totalrecords / pagecount;
        }

        $('#pagination').twbsPagination({
            totalPages: totalpages,
            visiblePages: 5,
            onPageClick: function (event, page) {
                //$('#page-content').text('Page ' + page);
                var html = "";
                $.ajax({
                    type: "POST",
                    url: "../Service.asmx/GetPaymentHistoryBatch",
                    data: '{pageno:"' + page + '",pagecount: "' + pagecount + '",searchstring: "' + searchstring + '",from: "' + from + '",to:"' + to + '",sortstring: "' + sortstring + '"}',
                    contentType: "application/json; charset=utf-8",
                    //dataType: "json",
                    async: true,
                    success: function (result) {
                        var data = eval(result.d);
                        if (result.d != "") {
                            if (data.length != 0) {
                                $.each(data, function (index, item) {
                                    var status = item.STATUS == "1" ? "Success" : "Failed";
                                    html += "<tr><td>" + item.R + "</td><td>" + item.REFERENCENO + "</td><td>" + item.ITEM + "</td><td> ₦ " + item.PRICE + "</td><td>" + formatDate(item.DATECREATED) + "</td><td>" + status + "</td></tr>";
                                });
                                $("#tbody").html(html);
                            }
                        }
                    }
                });
            }
        });
    }    
});

function formatDate(dateString) {
    return dateString.replace("T", " ");
}

