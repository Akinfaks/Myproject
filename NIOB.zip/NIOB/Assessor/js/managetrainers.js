﻿var totalrecords = 0, totalpages = 0; var _data = null, activeRecord = null, activeFilter = "All";
var pagecount = 10, searchstring = "", from = "", to = "", sortstring = "";

getTotalRecords("");

$(document).ready(function () {
    populateTable();
})

function getTotalRecords() {
    //populate table
    //Send the AJAX call to the server
    $(function () {
        totalrecords = 0;

        $.ajax({
            type: "POST",
            url: "../Service.asmx/GetTrainerInfo",
            data: '{filter:"' + searchstring + '"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                var data = eval(result.d);
                if (result.d != "") {
                    if (data.length != 0) {
                        totalrecords = data.length;
                    }
                }
            }
        });
    })
}

function populateTable() {
    //check total records
    if (totalrecords == 0) {
        $('#norecord').html("<center>No record found</center>")
    }
    else {
        if (totalrecords % pagecount > 0) {
            totalpages = totalrecords / pagecount + 1;
        } else {
            totalpages = totalrecords / pagecount;
        }

        $('#pagination').twbsPagination({
            totalPages: totalpages,
            visiblePages: 5,
            onPageClick: function (event, page) {
                //$('#page-content').text('Page ' + page);
                var html = "";
                $.ajax({
                    type: "POST",
                    url: "../Service.asmx/GetTrainerInfoBatch",
                    data: '{pageno:"' + page + '",pagecount: "' + pagecount + '",searchstring: "' + searchstring + '",from: "' + from + '",to:"' + to + '",sortstring: "' + sortstring + '"}',
                    contentType: "application/json; charset=utf-8",
                    //dataType: "json",
                    async: true,
                    success: function (result) {
                        var data = eval(result.d);
                        if (result.d != "") {
                            if (data.length != 0) {
                                _data = data;
                                
                                $.each(data, function (index, item) {
                                    var editable = item.EDITABLE == "1" ? "Pending" : "Submitted";
                                    //var status = item.ASSESSMENTSTATUS == null ? "NOT VISITED" : item.ASSESSMENTSTATUS;
                                    html += "<tr onclick='openModal(\"" + item.BIODATAID + "\")' style='cursor:pointer'><td>" + item.R + "</td><td>" + item.FIRSTNAME + " " + item.SURNAME + "</td><td>" + item.BUSINESSNAME + "</td><td>" + item.SPECIALIZATION + "</td><td>" + item.ASSESSMENTSTATUS + "</td><td>" + editable + "</td></tr>";
                                });
                                $("#tbody").html(html);
                            }
                        }
                    }
                });
            }
        });
    }
}


//manage modal box
var modal = document.getElementById('myModal');
// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];


function showModal() {
    modal.style.display = "block";
}
function hideModal() {
    modal.style.display = "none";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function () {
    hideModal()
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
    if (event.target == modal) {
        hideModal();
    }
}

function openModal(id) {
    showModal();
    $("#trainerphoto").prop("src","");
    for (var i = 0; i < _data.length; i++) {
        item = _data[i];
        if (item.BIODATAID == id) {
            activeRecord = item;
            //get photograph
            getPhoto(item.BIODATAID);
            $("#traineruniqueid").html(item.UNIQUEID);
            $("#trainername").html(item.FIRSTNAME + " " + item.SURNAME);
            $("#companyname").html(item.BUSINESSNAME);
            $("#specialization").html(item.SPECIALIZATION);
            $("#officeaddress").html(item.OFFICEADDRESS);
            $("#trainingaddress").html(item.TRAININGADDRESS);
            $("#landmark").html(item.LANDMARK);
            $("#description").html(item.DESCRIPTION);
            $("#mobile").html(item.PHONENUMBER);
            $("input#" + (item.ASSESSMENTSTATUS).toLowerCase().replace(" ", "")).prop("checked", true);
            $("#result").val(item.RESULT);
            $("#recommendation").val(item.RECOMMENDATION);

            //disable input if submitted
            if (item.EDITABLE == 0) {
                $("input[name=status]").prop("disabled", true);
                $("#result").prop("disabled", true);
                $("#recommendation").prop("disabled", true);
                $("a.btn_update").css("display", "none");

            } else {
                $("input[name=status]").prop("disabled", false);
                $("#result").prop("disabled", false);
                $("#recommendation").prop("disabled", false);
                $("a.btn_update").css("display", "inline");
            }


            break;
        }
    }
}

function getPhoto(id) {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetPhotographByID",
        data: '{id:"' + id + '"}',
        contentType: "application/json; charset=utf-8",
        //dataType: "json",
        async: true,
        success: function (result) {
            var data = eval(result);
            if (result.d != "") {
                if (data.length != 0) {
                    $("#trainerphoto").prop("src", "data:image/jpeg;base64,"+data.d);
                }
            }
        }
    });
}

//manage tab filter on click
$("ul#filternavbar li a").click(function (event) {
    var filter = event.toElement.innerText;
    activeFilter = filter;
    refreshView();
})

//save trainer assessment 
function updateAssessment(action) {
    if (action == "submit" && !confirm("You will not be able to edit assessment after submitting!")) return;
    if (activeRecord != null && activeRecord.UNIQUEID == $("#traineruniqueid").html()) {
        var trainerid = activeRecord.BIODATAID,
            status = $("input[name=status]:checked").val(),
            result = $("#result").val(),
            recom = $("#recommendation").val();

        //updateTrainerAssessment
        //Send the AJAX call to the server
        $.ajax({
            type: "POST",
            url: "../Service.asmx/UpdateTrainerAssessment",
            data: '{id:"' + trainerid + '",status: "' + status + '",result: "' + result + '",recommendation: "' + recom + '", action: "'+action +'"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                console.log(result)
                var data = eval(result);
                console.log(data.d)
                if (data.d) {
                    action == "submit" ? alert("submitted successfully") : alert("saved successfully");
                    refreshView();
                }
            }
        });
        hideModal();
    }
}

function getStatusID(filter) {
    switch (filter) {
        case "ASSESSED":
            return 1;
        case "VISITED":
            return 2;
        case "NOT VISITED":
            return 0;
        default:
            return "";
    }
}

function refreshView() {
     //reset pagination
    $('#pagination').empty();
    $('#pagination').removeData("twbs-pagination");
    $('#pagination').unbind("page");

    var html = ""; $("#norecord").html(""); $("#tbody").html("");
    searchstring = getStatusID(activeFilter);

    getTotalRecords();
    populateTable();
}