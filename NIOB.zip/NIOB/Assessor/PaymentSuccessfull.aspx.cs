﻿using NIOB.BusinessLogic;
using NIOB.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Assessor
{
    public partial class PaymentSuccessfull : System.Web.UI.Page
    {
        Logic logic = new Logic();
        String _username;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //get username
                IPrincipal principal = Thread.CurrentPrincipal;
                IIdentity identity = principal == null ? null : principal.Identity;
                _username = identity == null ? "" : identity.Name;

                if (_username == "") Response.Redirect("../Login");

                //get refno from querystring
                string refno = Request.QueryString["refno"].ToString();
                refno_span.InnerText = refno;

                //get active redirect page
                String activeRedirect = Session["activeRedirect"].ToString();
                if (activeRedirect == "Payment")
                {
                    backtoprevious.Text = "  &laquo; Back to Payment Items";
                    backtoprevious.PostBackUrl = activeRedirect;
                }
                else if (activeRedirect == "AvailableTrainings")
                {
                    backtoprevious.Text = "  &laquo; Back to Available Trainings";
                    backtoprevious.PostBackUrl = activeRedirect;
                }
                else
                {
                    Response.Redirect("Home");
                }
                
                //send reference number to user email
                //
                //
            }             
        }
    }
}