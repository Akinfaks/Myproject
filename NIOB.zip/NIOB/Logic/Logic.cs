﻿using NIOB.BusinessObjects;
using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;

namespace NIOB.BusinessLogic
{
    public class Logic
    {
        ConnectionManager connMngr = new ConnectionManager();
        SendEmail _mailService = new SendEmail();
        Common common = new Common();

        internal UserObject GetUser(string _uname, string _pwd)
        {
            UserObject _user = new UserObject();
            DataTable dt = new DataTable();
            dt = connMngr.getUserInfo(_uname, _pwd);
            if (dt != null && dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];
                _user.tbl_user = new Tbl_User();
                _user.tbl_user.BiodataID = Convert.ToInt32(dr["BIODATAID"]);
                _user.tbl_user.Email = dr["EMAIL"].ToString();
                _user.tbl_user.ID = Convert.ToInt32(dr["ID"]);
                _user.tbl_user.Password = dr["PASSWORD"].ToString();
                _user.tbl_user.Username = dr["USERNAME"].ToString();
                _user.tbl_user.UserType = Convert.ToInt32(dr["USERTYPE"]);
                _user.tbl_user.DateCreated = dr["DATECREATED"].ToString();
                _user.tbl_user.Status = Convert.ToInt32(dr["STATUS"]);
                _user.tbl_user.ApprovalFlag = Convert.ToInt32(dr["APPROVALFLAG"]);
            }
            else
            {
                _user = null;
            }

            return _user;
        }

        internal long InsertUser(UserObject user)
        {
            int usertype = user.tbl_user.UserType;
            //generate uniqueID
            string uniqueNumber = GenerateUniqueID.GetUID(6);
            string uniqueId = (usertype == 1 ? "AR" : usertype == 2 ? "AS" : usertype == 3 ? "TR" : "") + uniqueNumber;
            while (connMngr.CheckUID(uniqueId, usertype))
                uniqueNumber = GenerateUniqueID.GetUID(6);

            user.biodata.UniqueID = (usertype == 1 ? "AR" : usertype == 2 ? "AS" : usertype == 3 ? "TR" : "") + uniqueNumber;

            //resize photogrAPH
            //user.photo.Photograph = ImageResizer.ResizeImage(Image.FromStream(new MemoryStream(user.photo.Photograph)), 240, 320);
           
            long biodataid = connMngr.InsertUser(user);
            //long biodataid2 = connMngr.InsertTrainerInfo(trainerinfo);
            if (biodataid > 0)
                return biodataid;
           
            else
                return 0;
           

        }

        internal DataTable GetStates()
        {
            DataTable dt = new DataTable();
            dt = connMngr.GetStates();
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal DataTable GetLGA(string stateid)
        {
            DataTable dt = new DataTable();
            dt = connMngr.GetLGA(stateid);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal void InsertPrev_Emp(Employment_Info prev_emp)
        {
            connMngr.InsertPrev_Emp(prev_emp);
        }

        internal void saveDocumentInfo(Document_Info docInfo)
        {
            connMngr.InsertDocumentInfo(docInfo);
        }

        internal DataTable CheckUsername(string username)
        {
            DataTable dt = new DataTable();
            dt = connMngr.checkUsername(username);
            if (dt != null && dt.Rows.Count > 0)
            {
                return dt;
            }
            else
            {
                return null;
            }
        }

        internal DataTable GetPaymentHistoryBatch(string username, string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {

            DataTable dt = new DataTable();
            dt = connMngr.GetPaymentHistoryBatch(username, Convert.ToInt32(pageno), Convert.ToInt32(pagecount), searchstring, from, to, sortstring);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal DataTable CheckEmail(string email)
        {
            DataTable dt = new DataTable();
            dt = connMngr.checkEmail(email);
            if (dt != null && dt.Rows.Count > 0)
            {
                return dt;
            }
            else
            {
                return null;
            }
        }

        internal bool ActivateAccount(string activationKey)
        {
            long response = connMngr.ActivateAccount(activationKey);
            if (response > 0)
                return true;
            else return false;
        }

        internal UserObject GetInfoByUsername(string username)
        {
            UserObject _user = new UserObject();
            DataSet ds = new DataSet();
            ds = connMngr.getInfoByUsername(username);
            if (ds != null && ds.Tables.Count > 0)
            {
                Biodata userbiodata = new Biodata();
                userbiodata.ID = Convert.ToInt64(ds.Tables[0].Rows[0]["ID"]);
                userbiodata.Firstname = ds.Tables[0].Rows[0]["FIRSTNAME"].ToString();
                userbiodata.Surname = ds.Tables[0].Rows[0]["SURNAME"].ToString();
                userbiodata.Title = ds.Tables[0].Rows[0]["TITLE"].ToString();
                userbiodata.DOB = ds.Tables[0].Rows[0]["DOB"].ToString();
                userbiodata.Gender = ds.Tables[0].Rows[0]["GENDER"].ToString();
                userbiodata.PhoneNumber = ds.Tables[0].Rows[0]["PHONENUMBER"].ToString();
                userbiodata.StateID = ds.Tables[0].Rows[0]["STATEOFRESIDENCE"].ToString();
                userbiodata.UniqueID = ds.Tables[0].Rows[0]["UNIQUEID"].ToString();

                UserPhotograph userphoto = new UserPhotograph();
                userphoto.Photograph = (byte[])ds.Tables[1].Rows[0]["PHOTOGRAPH"];

                _user.biodata = userbiodata;
                _user.photo = userphoto;
            }
            else
            {
                _user = null;
            }

            return _user;
        }

        internal List<Payment_Item> GetPaymentItemsByCategory(int p)
        {
            List<Payment_Item> paymentItems = new List<Payment_Item>();
            DataSet ds = new DataSet();
            ds = connMngr.GetPaymentItemsByCategory(p);
            if (ds != null && ds.Tables.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    Payment_Item item = new Payment_Item();
                    item.ID = Convert.ToInt32(dr["ID"]);
                    item.Item = dr["ITEM"].ToString();
                    item.Price = dr["PRICE"].ToString();
                    item.Description = dr["DESCRIPTION"].ToString();
                    paymentItems.Add(item);
                }
            }
            else
            {
                paymentItems = null;
            }

            return paymentItems;
        }

        internal List<Payment_Info> GetUserPaymentInfo(string username)
        {
            DataTable dt = new DataTable();
            List<Payment_Info> userpaymentinfo = new List<Payment_Info>();

            dt = connMngr.GetUserPaymentInfo(username);
            if (dt != null & dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    Payment_Info paymentitem = new Payment_Info();
                    paymentitem.ItemID = Convert.ToInt32(dr["ITEMID"]);
                    paymentitem.BiodataID = Convert.ToInt64(dr["BIODATAID"]);
                    paymentitem.DateCreated = dr["datecreated"].ToString();
                    paymentitem.Status = Convert.ToInt32(dr["status"]);
                    userpaymentinfo.Add(paymentitem);
                }
            }
            return userpaymentinfo;
        }

        internal bool InsertUserPaymentInfo(String username, Payment_Info paymentinfo)
        {
            long insertid = connMngr.InsertUserPaymentInfo(username, paymentinfo);
            if (insertid > 0)
                return true;
            else return false;
        }

        //internal void UpdateUserPaymentInfo(String username, Payment_Info paymentinfo)
        //{
        //    connMngr.UpdateUserPaymentInfo(username, paymentinfo);
        //}

        internal bool InsertPaymentLog(String username, Payment_Log paymentlog)
        {
            long insertid = connMngr.InsertPaymentLog(username, paymentlog);
            if (insertid > 0)
                return true;
            else return false;
        }

        internal void UpdatePaymentLog(String username, Payment_Log paymentlog, String table)
        {
            connMngr.UpdatePaymentLog(username, paymentlog, table);
        }

        internal DataTable GetAvailableTrainingsBatch(string username, string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = connMngr.GetAvailableTrainingsBatch(username, Convert.ToInt32(pageno), Convert.ToInt32(pagecount), searchstring, from, to, sortstring);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal DataTable GetUserTrainingsBatch(string username, string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = connMngr.GetUserTrainingsBatch(username, Convert.ToInt32(pageno), Convert.ToInt32(pagecount), searchstring, from, to, sortstring);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal bool InsertUserTrainingInfo(string _username, Training_Info traininginfo)
        {
            long insertid = connMngr.InsertUserTrainingInfo(_username, traininginfo);
            if (insertid > 0)
                return true;
            else return false;
        }

        internal AvailableTraining GetTrainingByID(string id)
        {
            AvailableTraining item;
            DataTable ds = new DataTable();
            ds = connMngr.GetTrainingByID(id);
            if (ds != null && ds.Rows.Count > 0)
            {
                item = new AvailableTraining();
                item.ID = Convert.ToInt32(ds.Rows[0]["ID"]);
                item.Description = ds.Rows[0]["DESCRIPTION"].ToString();
                item.Duration = ds.Rows[0]["DURATION"].ToString();
                item.StartDate = ds.Rows[0]["STARTDATE"].ToString();
                item.Price = ds.Rows[0]["PRICE"].ToString();
                item.Title = ds.Rows[0]["TITLE"].ToString();
                item.Venue = ds.Rows[0]["VENUE"].ToString();
            }
            else
            {
                item = null;
            }

            return item;
        }

        internal Payment_Item GetPaymentItemByID(int p)
        {
            Payment_Item item;
            DataTable ds = new DataTable();
            ds = connMngr.GetPaymentItemByID(p);
            if (ds != null && ds.Rows.Count > 0)
            {
                item = new Payment_Item();
                item.ID = Convert.ToInt32(ds.Rows[0]["ID"]);
                item.Item = ds.Rows[0]["ITEM"].ToString();
                item.Price = ds.Rows[0]["PRICE"].ToString();
                item.Description = ds.Rows[0]["DESCRIPTION"].ToString();
            }
            else
            {
                item = null;
            }

            return item;
        }

        internal void logUserAction(string _uname, string action)
        {
            connMngr.logUserAction(_uname, action, IPLocator.GetUser_IP());
        }

        internal string ResendActivationLink(string email)
        {
            DataTable dt = new DataTable();

            dt = connMngr.GetUserInfoByEmail(email);

            if (dt != null & dt.Rows.Count > 0)
            {
                string key = dt.Rows[0]["KEY"].ToString();
                string surname = dt.Rows[0]["SURNAME"].ToString();
                if (sendMailtoUser(email, surname, key))
                    return "true";
                else return "error";
            }

            else return "false";
        }

        internal string ResendPassword(string email)
        {
            DataTable dt = new DataTable();

            dt = connMngr.GetUserPwdByEmail(email);

            if (dt != null & dt.Rows.Count > 0)
            {
                string pwd = Common.DecryptText(dt.Rows[0]["PASSWORD"].ToString());
                string surname = dt.Rows[0]["SURNAME"].ToString();
                if (resendPwdtoUser(email, surname, pwd))
                    return "true";
                else return "error";
            }

            else return "false";
        }

        private bool resendPwdtoUser(string email, string surname, string pwd)
        {
            // send confirmation mail to user email
            string success_mail = "Dear " + surname + ",<br/><br/>" +
                       " Your NIOB password: <b>" + pwd + "</b>";
            bool sendMail = false;
            try
            {
                sendMail = _mailService.sendMail(email, "NIOB Password Reset", success_mail);
            }
            catch
            {

            }
            return sendMail;
        }

        internal DataTable GetUserInfoByEmail(string email)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = connMngr.GetUserInfoByEmail(email);
            }
            catch
            {

            }
            return dt;
        }

        internal bool sendMailtoUser(string email, string surname,  string success_mail)
        {
            bool sendMail = false;
            try
            {
                sendMail = _mailService.sendMail(email, "NIOB Verification Key", success_mail);
            }
            catch
            {

            }
            return sendMail;
        }

        internal DataTable GetTrainerInfoBatch(string username, string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = connMngr.GetTrainerInfoBatch(username, Convert.ToInt32(pageno), Convert.ToInt32(pagecount), searchstring, from, to, sortstring);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal long UpdateTrainerAssessment(string username, string id, string status, string result, string recommendation, string action)
        {
            int editstatus = action.ToLower() == "submit" ? 0 : 1;
            return (connMngr.UpdateTrainerAssessment(username, id, status, result, recommendation, editstatus));
        }

        internal DataTable GetArtisanInfoBatch(string username, string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = connMngr.GetArtisanInfoBatch(username, Convert.ToInt32(pageno), Convert.ToInt32(pagecount), searchstring, from, to, sortstring);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal long UpdateArtisanAssessment(string username, string id, string status, string result, string recommendation, string action)
        {
            int editstatus = action.ToLower() == "submit" ? 0 : 1;
            return (connMngr.UpdateArtisanAssessment(username, id, status, result, recommendation, editstatus));
        }

        internal void InsertTrainerInfo(TrainerInfo trainerInfo)
        {
            connMngr.InsertTrainerInfo(trainerInfo);
           // long biodataid = connMngr.InsertTrainerInfo(trainerInfo);
         //   if (biodataid > 0)
            //    return biodataid;
          //  else
           //     return 0;

        }

        internal DataTable Admin_GetUsersByCategory(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = connMngr.Admin_GetUsersByCategory(Convert.ToInt32(pageno), Convert.ToInt32(pagecount), searchstring
              //  , from, to, sortstring
                );
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal DataTable Admin_GetPendingUsersByCategory(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = connMngr.Admin_GetPendingUsersByCategory(Convert.ToInt32(pageno), Convert.ToInt32(pagecount), searchstring
               // , from, to, sortstring
                );
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal DataTable Admin_GetTrainingBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = connMngr.Admin_GetTrainingBatch(Convert.ToInt32(pageno), Convert.ToInt32(pagecount), searchstring, from, to, sortstring);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal DataTable Admin_GetPaymentItemsBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = connMngr.Admin_GetPaymentItemsBatch(Convert.ToInt32(pageno), Convert.ToInt32(pagecount), searchstring, from, to, sortstring);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal DataTable Admin_GetPaymentHistoryBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = connMngr.Admin_GetPaymentHistoryBatch(Convert.ToInt32(pageno), Convert.ToInt32(pagecount), searchstring, from, to, sortstring);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal DataTable Admin_GetNewsBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = connMngr.Admin_GetNewsBatch(Convert.ToInt32(pageno), Convert.ToInt32(pagecount), searchstring, from, to, sortstring);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal DataTable GetUserInfoByUsername(string _username)
        {
            DataTable dt = new DataTable();
            dt = connMngr.GetUserInfoByUsername(_username);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }

        internal DataTable GetTransactionDetails(string refno, string _username)
        {
            DataTable dt = new DataTable();
            dt = connMngr.GetTransactionDetails(refno, _username);
            if (dt != null & dt.Rows.Count > 0)
                return dt;
            else return null;
        }
    }
}