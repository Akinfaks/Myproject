﻿using NIOB.BusinessLogic;
using NIOB.BusinessObjects;
using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB
{
    public partial class Login : System.Web.UI.Page
    {
        Dictionary<string, UserObject> activeUsers = new Dictionary<string, UserObject>();
        Logic logic = new Logic();
        UserObject _user = new UserObject();

        
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        

        protected void login_Click(object sender, EventArgs e)
        {
            _user.tbl_user = new Tbl_User();
            string _uname = uname.Value.ToLower();
           
            string _pwd = pwd.Value;
            error_lbl.InnerText = "";
            if (!String.IsNullOrEmpty(_uname) && !String.IsNullOrEmpty(_pwd))
            {

                if ((_uname == "admin") && (_pwd == "welcome10@"))
                {
                    _user.tbl_user.Password = _pwd;
                    _user.tbl_user.Username = _uname;
                    AllowUser(_user);
                }
                else
                {
                    _user = logic.GetUser(_uname, Common.EncryptText(_pwd));

                    if (_user != null)
                    {
                        if (_user.tbl_user.Status == 1)
                       //if(_user.tbl_user.ApprovalFlag == 1)
                        {
                            AllowUser(_user);
                        }
                        else
                        {
                            Session["activeLoginEmail"] = _user.tbl_user.Email;
                            resendlink_lbl.Style["display"] = "inline-block";
                        }                        
                    }
                    else
                    {
                        error_lbl.InnerText = "Invalid credentials. Please try again.";
                    }
                }
            }
            else
            {
                error_lbl.InnerText = "Username/Password cannot be empty.";
            }   
            
        }

        private void AllowUser(UserObject user)
        {
            Session["user_tblinfo"] = user.tbl_user;
            string _uname = user.tbl_user.Username;
            if (Application["activeUsers"] != null) activeUsers = (Dictionary<string, UserObject>)Application["activeUsers"];
            if (activeUsers.Keys.Contains(_uname))
            {
                FormsAuthentication.SignOut();
                logic.logUserAction(_uname, "logged out");
                activeUsers.Remove(_uname);
            }

            FormsAuthentication.SetAuthCookie(_uname, false);
            logic.logUserAction(_uname, "logged in");
            activeUsers.Add(_uname, user);

            Application["activeUsers"] = activeUsers;
            //   Response.Redirect(UserType.getTypeName(user.tbl_user.UserType) +"/Home");
            Response.Redirect(UserType.getTypeName(user.tbl_user.UserType) + "/Home");
        }

        protected void ResendActivationLink_Click(object sender, EventArgs e)
        {
            string email = Session["activeLoginEmail"].ToString();
            error_lbl.InnerText = "";

            //send confirmation mail to user email
            try
            {
                DataTable dt = new DataTable();

                dt = logic.GetUserInfoByEmail(email);

                if (dt != null & dt.Rows.Count > 0)
                {
                    string key = dt.Rows[0]["KEY"].ToString();
                    string surname = dt.Rows[0]["SURNAME"].ToString();
                    string message = WebPageToCode("http://localhost/niob-dev/Register/ActivationMail?actionLink=" + key);
                    if (logic.sendMailtoUser(email, surname, message)) {
                        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Activation Link resent Successfully.');", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Error!');", true);
                    }
                }                
            }
            catch (Exception ex)
            {

            }
        }

        public String WebPageToCode(string Url)
        {

            HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(Url);
            myRequest.Method = "GET";
            WebResponse myResponse = myRequest.GetResponse();
            StreamReader sr = new StreamReader(myResponse.GetResponseStream(), System.Text.Encoding.UTF8);
            string result = sr.ReadToEnd();
            sr.Close();
            myResponse.Close();

            return result;
        }
    }
}