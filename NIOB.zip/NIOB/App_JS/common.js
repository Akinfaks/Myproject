﻿var upload1, upload2, upload3, upload4;

$(function () {
    //clear error label on page load
    $(document).ready(function () {
        $('#error_lbl').html("");

        $('._date').datetimepicker({
            timepicker: false,
            //mask: true,
            format: 'm/d/Y',
            //minDate: '-1970/01/01',//yesterday is minimum date(for today use 0 or -1970/01/01)
            maxDate: '-1970/01/01'//tomorrow is maximum date calendar
            //onChangeDateTime: function (dp, $input) {
            //    alert($input.val())
            //}
        });
    })

    //populate lga ddl on state ddl selectchange event
    $(document).ready(function () {
        $('#state').on('change', function () {
            if ($('#state').val() == "") {
               // $("#lga").empty();
                $("#lga").append($("<option />").val("").text("Loading..."));
                return;
            }
            var _stateid = $('#state').val();
            $.ajax({
                type: "POST",
                url: "../Service.asmx/GetLGA",
                data: '{"stateid":"' + _stateid + '"}',
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                async: true,
                success: function (result) {
                    var data = eval(result.d);//JSON.parse(result.d);
                    $("#lga").empty();
                    var options = $("#lga");
                    options.append($("<option />").val("").text("Select LGA"));
                    $.each(data, function () {
                        options.append($("<option />").val(this.LGAID).text(this.LGANAME.trim()));
                    });
                },
                error: function (xhr, status, error) {
                    console.log("error " + error);
                }
            });
        });
    });
});

//save upload target on file select
$(function () {
    $("#primarycertUpload").change(function (e) {
        upload1 = e.target.files;
    })
    $("#secondarycertUpload").change(function (e) {
        upload2 = e.target.files;
    })
    $("#technicalcertUpload").change(function (e) {
        upload3 = e.target.files;
    })
    $("#tertiarycertUpload").change(function (e) {
        upload4 = e.target.files;
    })
})

//***********set username exits variable
var username_exist = false, emailexist = false;


//***********check for username availability on change      
$("#username").change(function () {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/CheckUsername",
        data: '{"username":"' + $("#username").val().trim() + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: true,
        success: function (result) {
            var data = eval(result);//JSON.parse(result.d);
            console.log(data)
            if (data.d != "") {
                username_exist = true;
                $('#error_lbl_username').html('<span style="color: red; font-style: italic; text-align: right">* username already exists!</span>');
                $('#lbl_username').css('color', 'red');
            } else {
                username_exist = false;
                $('#lbl_username').css('color', 'black');
                $('#error_lbl_username').html("");
            }
        },
        error: function (xhr, status, error) {
            console.log("error " + error);
        }
    });
});

//***********check for email availability on change      
$("#email").change(function () {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/CheckEmail",
        data: '{"email":"' + $("#email").val().trim() + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: true,
        success: function (result) {
            var data = eval(result);//JSON.parse(result.d);
            if (data.d != "") {
                emailexist = true;
                $('#error_lbl_email').html('<span style="color: red; font-style: italic; text-align: right">* email already exists!</span>');
                $('#lbl_email').css('color', 'red');
            } else {
                emailexist = false;
                $('#lbl_email').css('color', 'black');
                $('#error_lbl_email').html("");
            }
        },
        error: function (xhr, status, error) {
            console.log("error " + error);
        }
    });
});


//***********add and delete implement on previous employment page
var count = 0;
$(function () {
    $(".add-button").click(function () {

        if (count >= 4) {
            alert("You cannot add more than 5 entries!!");
            return;
        }
        count++;
        var element = "<div id='previousjobs" + count + "'><div class='col-md-2'><input name='prev_emptitle" + count + "' type='text' id='prev_emptitle" + count + "' class='form-control' runat='server'/><br></div><div class='col-md-3'><input name='prev_employername" + count + "' type='text' id='prev_employername" + count + "' class='form-control' runat='server'/><br></div><div class='col-md-3'><input type='text' name='date' class='form-control _date' name='datefrom" + count + "' id='datefrom" + count + "' required='required' runat='server'/><br></div><div class='col-md-3'><input type='text' name='date' class='form-control _date' name='dateto" + count + "' id='dateto" + count + "' required='required' runat='server'/><br></div><div class='col-md-1' style='margin-top:5px;'><a class='btn btn-danger custom-btn delete-button' style='display:inline;' onclick='deleteEntry(" + count + ")'> × Del </a></div></div>";
        $("#prev_employmentlist").append(element);

        $('#prev_employmentlist input[name="date"]').datetimepicker({
            timepicker: false,
            //mask: true,
            format: 'm/d/Y',
            //minDate: '-1970/01/01',//yesterday is minimum date(for today use 0 or -1970/01/01)
            maxDate: '-1970/01/01'//tomorrow is maximum date calendar
            //onChangeDateTime: function (dp, $input) {
            //    alert($input.val())
            //}
        });

    })
});



function deleteEntry(index) {
    if (confirm("Are you sure?")) {
        $("#previousjobs" + index).remove();
        count--
    }
}

//**************
//**************validate number input cotrol
$(function () {
    $('._numberInput').on('keydown', function (e) { -1 !== $.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) || /65|67|86|88/.test(e.keyCode) && (!0 === e.ctrlKey || !0 === e.metaKey) || 35 <= e.keyCode && 40 >= e.keyCode || (e.shiftKey || 48 > e.keyCode || 57 < e.keyCode) && (96 > e.keyCode || 105 < e.keyCode) && e.preventDefault() });
})

//*****************validate email input on change
$(function () {
    $('#email').on('change', function () {
        if (!(validateEmail($('#email').val()))) {
            $('#error_lbl').html("");
            $('#error_lbl').html('<span style="color: red; font-style: italic; text-align: right">* invalid email format!</span>');
            $('#lbl_email').css('color', 'red');

        }
    });
})

function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
//**********************
//**************validate constraint on submit event
function submitForm_Click() {
    removeError();
    if ($('#error_lbl').length) $('#error_lbl').html("");

    if (emailexist) {
        $('#lbl_email').css('color', 'red');
        $('#error_lbl_email').html('<span style="color: red; font-style: italic; text-align: right">* email already exists!</span>');
    }
    else if (!checkConfirmPassword() || !validatePasswordChar()) {
        $('#lbl_confirmpassword').css('color', 'red');
        $('#error_lbl_confpass').html('<span style="color: red; font-style: italic; text-align: right">* password does not match!</span>');
    }
    else if (username_exist) {
        $('#lbl_username').css('color', 'red');
        $('#error_lbl_username').html('<span style="color: red; font-style: italic; text-align: right">* username already exists!</span>');
    }
    else if ($('#email').val() != "" && !(validateEmail($('#email').val()))) {
        $('#error_lbl').html("");
        $('#error_lbl').html('<span style="color: red; font-style: italic; text-align: right">* invalid email format!</span>');
    }
    else if ($('#lastname').val() != "" && $('#firstname').val() != "" && ($('#lastname').val().indexOf(" ") > 0 || $('#firstname').val().indexOf(" ") > 0)) {
        $('#error_lbl').html("");
        $('#error_lbl').html('<span style="color: red; font-style: italic; text-align: right">* field(s) cannot contain whitespace!</span>');
        if ($('#lastname').val().indexOf(" ") > 0) $('#lbl_lastname').css('color', 'red');
        if ($('#firstname').val().indexOf(" ") > 0) $('#lbl_firstname').css('color', 'red');
    }
    else if (validateInput()) {
        return true;
    }
    else {
        $('#error_lbl').html('<span style="color: red; font-style: italic; text-align: right">* required fields cannot be empty!</span>');

        if ($('#title').val() == "") $('#lbl_title').css('color', 'red');
        if ($('#lastname').val() == "") $('#lbl_lastname').css('color', 'red');
        if ($('#firstname').val() == "") $('#lbl_firstname').css('color', 'red');
        if ($('#phoneNo').val() == "") $('#lbl_phoneNo').css('color', 'red');
        if ($('#dob').val() == "") $('#lbl_dob').css('color', 'red');
        if ($('#email').val() == "") $('#lbl_email').css('color', 'red');
        if ($('#username').val() == "") $('#lbl_username').css('color', 'red');
        if ($('#password').val() == "") $('#lbl_password').css('color', 'red');
        if ($('#confirmpassword').val() == "") $('#lbl_confirmpassword').css('color', 'red');
        if ($('#gender').val() == "") $('#lbl_gender').css('color', 'red');
        if ($('#blahh').attr('src') == undefined || $('#blahh').attr('src') == '') $('#lbl_photo').css('color', 'red');
    }
    $('#mytabs a[href="#tab1"]').tab('show');
    return false;
}

function validateInput() {
    if ($('#title').val() == "" || $('#lastname').val() == "" || $('#firstname').val() == "" || $('#gender').val() == "" || $('#phoneNo').val() == "" || $('#email').val() == "" || $('#username').val() == "" || $('#password').val() == "" || $('#confirmpassword').val() == "" || $('#dob').val() == "" || $('#blahh').attr('src') == undefined || $('#blahh').attr('src') == '' || $('#lastname').val().indexOf(" ") > 0 || $('#firstname').val().indexOf(" ") > 0) {
        return false
    }
    return true
}

//************populate summary page on input /slect chnage
$(function () {
    $("#summary_tab").click(function () {
        //console.log($('input, textarea'));

        $('#personaldata_sum_row').css('dislplay', 'none');
        $('#education_sum_row').css('dislplay', 'none');
        $('#employment_sum_row').css('dislplay', 'none');
        $('#membership_sum_row').css('dislplay', 'none');

        var personaldatacount = 0, educationdatacount = 0, employmentdatacount = 0, membershipdata = 0;

        $.each($('input, textarea'), function (index, item) {
            var id = $("#" + item.id);
            var summary_id = $("#" + item.id + "_sum");

            summary_id.html(function () {
                if (id.val() != '') {
                    if ($(item).parents('#tab1').length) {
                        personaldatacount++;
                    }
                    if ($(item).parents('#tab2').length) {
                        educationdatacount++;
                    }
                    if ($(item).parents('#tab3').length) {
                        employmentdatacount++;
                    }

                    if ($(item).parents('#membership_section').length) {
                        membershipdata++;
                    }
                }
                if (id.attr('type') == 'file')
                    return "<a onclick='displayImage(\"" + id.attr('id') + "\")'>" + id.val() + "</a>";
                else
                    return id.val();
            })
        })


        $.each($('select'), function (index, item) {
            var id = $("#" + item.id + " option:selected");
            var summary_id = $("#" + item.id + "_sum");

            summary_id.text(function () {

                if (id.val() != '') {
                    if ($(item).parents('#tab1').length) {
                        personaldatacount++;
                    }
                    if ($(item).parents('#tab2').length) {
                        educationdatacount++;
                    }
                    if ($(item).parents('#tab3').length) {
                        employmentdatacount++;
                    }
                    if ($(item).parents('#membership_section').length) {
                        membershipdata++;
                    }
                }
                return id.text();
            })
        })
        if (personaldatacount > 0) $('#personaldata_sum_row').css('display', 'inline-block');
        else $('#personaldata_sum_row').css('display', 'none');

        if (educationdatacount > 0) $('#education_sum_row').css('display', 'inline-block');
        else $('#education_sum_row').css('display', 'none');

        if (employmentdatacount > 0) $('#employment_sum_row').css('display', 'inline-block');
        else $('#employment_sum_row').css('display', 'none');

        if (membershipdata > 0) $('#membership_sum_row').css('display', 'inline-block');
        else $('#membership_sum_row').css('display', 'none');
    })
})

function displayImage(id) {
    var input = getTargetFile(id);
    var myWindow = window.open("", "MsgWindow", "width=600, height=600", true);
    var imgsrc;

    if (input && input[0]) {
        var reader = new FileReader();

        reader.onloadend = function (e) {
            imgsrc = e.target.result
            myWindow.document.write("<img src='" + imgsrc + "'/>");
            myWindow.document.title = setTitle(id);
        }
        reader.readAsDataURL(input[0]);
    }
}

function setTitle(id) {
    switch (id) {
        case "primarycertUpload":
            return "Primary Certificate";
        case "secondarycertUpload":
            return "Secondary Certificate";
        case "technicalcertUpload":
            return "Technical Certificate";
        case "tertiarycertUpload":
            return "Tertiary Certificate";
        default: return "";

    }
}

function getTargetFile(id) {
    switch (id) {
        case "primarycertUpload":
            return upload1;
        case "secondarycertUpload":
            return upload2;
        case "technicalcertUpload":
            return upload3;
        case "tertiarycertUpload":
            return upload4;
        default: return "";
    }
}



//$('input, textarea').change(function () {

//})

//$('select').change(function () {
//    var id = $("#" + this.id +" option:selected");
//    var summary_id = $("#" + this.id + "_sum");

//    summary_id.text(function () {
//        return id.text();
//    })
//})

//******clear error label
$('input, select').change(function () {
    if ($('#error_lbl').text() != "") {
        $('#error_lbl').html("");
        removeError();
    }
})

//*****************remove error on label function
function removeError() {
    $('#lbl_title').css('color', 'black');
    $('#lbl_lastname').css('color', 'black');
    $('#lbl_firstname').css('color', 'black');
    $('#lbl_phoneNo').css('color', 'black');
    $('#lbl_dob').css('color', 'black');
    $('#lbl_photo').css('color', 'black');
    $('#lbl_gender').css('color', 'black');
    $('#lbl_email').css('color', 'black');
    $('#lbl_username').css('color', 'black');
}
//validate date input
$(function () {
    $('._date').prop('max', function () {
        return new Date().toJSON().split('T')[0];
    });

    $("#lga").change(function () {
        $("#lga2").val(function () {
            return $("#lga").val()
        })
    })
})

//set selected image in picturebox on file select
$(function () {
    $('#photo').change(function () {
        readURL(this);
    });
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blahh').attr('src', e.target.result);
                $('#blahh_sum').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
})

//************validate confirm password
function checkConfirmPassword() {
    if ($("#confirmpassword").val() != "" && $("#confirmpassword").val() != $("#password").val()) {
        $('#error_lbl_confpass').html('<span style="color: red; font-style: italic; text-align: right">* password does not match!</span>');
        $('#lbl_confirmpassword').css('color', 'red');
        return false;
    }
    else {
        $('#lbl_confirmpassword').css('color', 'black');
        $('#error_lbl_confpass').html("");
        return true;
    }
}


//************validate password length
function validatePasswordChar() {
    if ($("#password").val() != "" && $("#password").val().length < 8) {
        $('#error_lbl_pass').html('<span style="color: red; font-style: italic; text-align: right">* password must be 8 or more characters!</span>');
        $('#lbl_password').css('color', 'red');
        return false;
    }
    else {
        $('#lbl_password').css('color', 'black');
        $('#error_lbl_pass').html("");
        return true;
    }
}

$(function () {
    $("a.btn.custom-btn.navigation-btn").click(function () {
        $("body").scrollTop(0);
    })
})

