﻿function ResendActivation() {
    $('.custom-btn').css('display', 'none');
    $('#result_lbl').html("");
    $('#resendLinkButton').css('display', 'inline-block')
    modal.style.display = "block";
}

function ResendPassword() {
    $('.custom-btn').css('display', 'none');
    $('#result_lbl').html("");
    $('#resendPwdButton').css('display', 'inline-block')
    modal.style.display = "block";
}


function resendPassword() {
    $("#spinner-img").css("display", "inline"); $("#resendmail").prop("disabled", "disabled")
    var email = $("#resendmail").val();
    console.log(email)
    $.ajax({
        type: "POST",
        url: "Service.asmx/ResendPassword",
        data: '{email:"' + email + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: true,
        success: function (result) {
            var data = result.d;
            if (result.d != "") {
                if (data == "true") {
                    alert("Password sent to Email..");
                    $('#result_lbl').html("Password sent successfully");
                } else if (data == "false") {
                    alert("Email does not exist!");
                    $("#error_lbl").html("Email does not exist!");
                } else if (data == "error") {
                    alert("Error! try again later");
                    $("#error_lbl").html("Error! try again later");
                }
                $("#spinner-img").css("display", "none");
                modal.style.display = "none"; $("#error_lbl").html("");
            }
        }
    });
}

function resendLink() {
    $("#spinner-img").css("display", "inline"); $("#resendmail").prop("disabled","disabled")
    var email = $("#resendmail").val();
    console.log(email)
    $.ajax({
        type: "POST",
        url: "Service.asmx/ResendActivationLink",
        data: '{email:"' + email + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: true,
        success: function (result) {
            var data = result.d;
            if (result.d != "") {
                if (data == "true") {
                    alert("Activation link resent successfully");
                    $('#result_lbl').html("Activation link resent successfully");
                } else if (data == "false") {
                    alert("Email does not exist!");
                    $("#error_lbl").html("Email does not exist!");
                } else if (data == "error") {
                    alert("Error! try again later");
                    $("#error_lbl").html("Error! try again later!");
                }
                $("#spinner-img").css("display", "none");
                modal.style.display = "none"; $("#error_lbl").html("");
            }
        }
    });    
}

var modal = document.getElementById('myModal');

//// Get the button that opens the modal
//var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
//btn.onclick = function () {
//    modal.style.display = "block";
//}

// When the user clicks on <span> (x), close the modal
span.onclick = function () {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
