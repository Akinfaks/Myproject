﻿using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Admin
{
    public partial class RegisteredTrainers : System.Web.UI.Page
    {
        ConnectionManager connMgr = new ConnectionManager();
        Utility utilities = new Utility();
        DataSet displayTrainerList = null;
        DataTable displaySearchTrainers = null; 

        protected void Page_Load(object sender, EventArgs e)
        {
            displayTrainerList = connMgr.Admin_DisplayRegisteredTrainers();
            if (displayTrainerList != null && displayTrainerList.Tables.Count > 0)
            {
                viewRegTrainers.DataSource = displayTrainerList;
                viewRegTrainers.DataBind();
                Session["dt"] = displayTrainerList;
            }
        }

        protected void viewsearchTrainers_Click(object sender, EventArgs e)
        {
            displaySearchTrainers = connMgr.DisplayDatabyIDTrainers(viewtrainers.Value);

            if (displaySearchTrainers != null && displaySearchTrainers.Rows.Count > 0)
            {
                //biodataid = displayArtisans.Rows[0]["ID"].ToString();
                viewRegTrainers.DataSource = displaySearchTrainers;
                viewRegTrainers.DataBind();

            }
        }

        protected void exportTrainers_Click(object sender, EventArgs e)
        {
            utilities.ExportToExcel(((DataSet)Session["dt"]), HttpContext.Current, "Trainers List");
        }

        protected void viewRegTrainers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            viewRegTrainers.PageIndex = e.NewPageIndex;
            viewRegTrainers.DataBind();
        }

        protected void viewRegTrainers_DataBound(object sender, EventArgs e)
        {
            GridViewRow pagerrow = viewRegTrainers.BottomPagerRow;
            Label pageno = (Label)pagerrow.Cells[0].FindControl("L3");
            Label totalpageno = (Label)pagerrow.Cells[0].FindControl("L4");

            if ((pageno != null) && (totalpageno != null))
            {
                int pagen = viewRegTrainers.PageIndex + 1;
                int tot = viewRegTrainers.PageCount;

                pageno.Text = pagen.ToString();
                totalpageno.Text = tot.ToString();
            }
            else
            {
                Response.Write("<script>alert('No more Data to Display');</script>");
            }

        }
    }
}