﻿using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Admin
{
    public partial class ManageUsers : System.Web.UI.Page
    {
        ConnectionManager connMgr = new ConnectionManager();
        EmailService.WebService emailWS = new EmailService.WebService();
        
        Utility utilities = new Utility();
        DataSet displayArtisans = null;
        DataTable displayArisanList = null;
        DataTable displayPhotograph = null;
        DataTable displayUniqueIDResult = null;
       // DataTable approval = null; 
        string biodataid = null;
        string _biodataid = null;
        string _emailaddress = "";
        string _phonenumber = "";
        string _fullname = "";
        bool _approveUser = false;

        

        protected void Page_Load(object sender, EventArgs e)

        {
            displayArtisans = connMgr.Admin_GetArtisans();

            if (displayArtisans != null && displayArtisans.Tables.Count > 0)
            {
                //biodataid = displayArtisans.Rows[0]["ID"].ToString();
                trainerview.DataSource = displayArtisans;
                trainerview.DataBind();
                Session["dt"] = displayArtisans;
            }
        }

        protected void trainerview_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            trainerview.PageIndex = e.NewPageIndex;
            trainerview.DataBind();

        }

        protected void trainerview_DataBound(object sender, EventArgs e)
        {
            GridViewRow pagerrow = trainerview.BottomPagerRow;
            Label pageno = (Label)pagerrow.Cells[0].FindControl("L3");
            Label totalpageno = (Label)pagerrow.Cells[0].FindControl("L4");

            if ((pageno != null) && (totalpageno != null))
            {
                int pagen = trainerview.PageIndex + 1;
                int tot = trainerview.PageCount;

                pageno.Text = pagen.ToString();
                totalpageno.Text = tot.ToString();
            }
            else
            {
                Response.Write("<script>alert('No more Data to Display');</script>");
            }
        }

        //protected void viewReg_Click(object sender, EventArgs e)
        //{
          



        //}

        protected void viewArtisans_Click(object sender, EventArgs e)
        {
            approveID.Visible = true;
            biodataid = ((LinkButton)sender).CommandArgument;
            //(LinkButton)row.FindControl("BtnApprove");
            //(Button)row.FindControl("BtnApprove");
          //  Session["active_biodata"] = biodataid;

            displayArisanList = connMgr.Admin_displayArtisanlist(Convert.ToInt32(biodataid));

            if (displayArisanList.Rows.Count > 0)
            {
                surname.Value = displayArisanList.Rows[0]["SURNAME"].ToString();
                firstname.Value = displayArisanList.Rows[0]["FIRSTNAME"].ToString();
                gender.Value = displayArisanList.Rows[0]["GENDER"].ToString();
                uniqueid.Value = displayArisanList.Rows[0]["UNIQUEID"].ToString();
                dob.Value = displayArisanList.Rows[0]["DOB"].ToString();
                phonenumber.Value = displayArisanList.Rows[0]["PHONENUMBER"].ToString();
                emailadd.Value = displayArisanList.Rows[0]["EMAIL"].ToString();
                address.Value = displayArisanList.Rows[0]["STREET"].ToString();
                city.Value = displayArisanList.Rows[0]["CITY"].ToString();
                state.Value = displayArisanList.Rows[0]["STATENAME"].ToString();

                Session["generic_biodataid"] = displayArisanList.Rows[0]["ID"].ToString();
              

            }
            else
            {

            }

            displayPhotograph = connMgr.GetPhotographByID(biodataid);
            if (displayPhotograph.Rows.Count > 0)
            {
                byte[] photoString = (byte[])displayPhotograph.Rows[0]["PHOTOGRAPH"];
                //  imgdisplay.ImageUrl = System.Text.Encoding.UTF8.GetString(photoString);
                imgdisplay.ImageUrl = "data:image;base64," + Convert.ToBase64String(photoString);

            }



        }

        

        protected void excelExport_Click(object sender, EventArgs e)
        {
            utilities.ExportToExcel(((DataSet)Session["dt"]), HttpContext.Current, "Artisans List");
        }

        protected void searchbyUID_Click(object sender, EventArgs e)
        {
            displayUniqueIDResult = connMgr.DisplayDatabyID(searchbyUniqueID.Value);

            if (displayUniqueIDResult != null && displayUniqueIDResult.Rows.Count > 0)
            {
                //biodataid = displayArtisans.Rows[0]["ID"].ToString();
                trainerview.DataSource = displayUniqueIDResult;
                trainerview.DataBind();
                
            }
        }

        protected void approveID_Click(object sender, EventArgs e)
        {
            artisanApproval();
        }

        internal void artisanApproval()
        {
            _biodataid = Session["generic_biodataid"].ToString();
            _emailaddress = emailadd.Value;
            _phonenumber = phonenumber.Value;
            _fullname = surname.Value + ", " + firstname.Value;

            _approveUser = connMgr.AdminApproveArtisans(Convert.ToInt32(_biodataid));

            if(_approveUser == true)
            {

                // string _subject = "NIOB Approval Notification.";
                string _subject = "NIOB Approval Notification.";
                string _body = " Dear " + _fullname + " you are receiving this email because your registration has been reviewed and approved.";

                try
                {

                    try
                    {
                        emailWS.sendmail1(_emailaddress, _subject, _body);
                    }
                    catch (Exception ex) { }

                    try { utilities.sendSmsAsync(_phonenumber, _body, _subject); }
                    catch (Exception ex) { }

                    notification.Text = utilities.ShowSuccess("Approval is successful and Notification has been sent.");

                }
                catch (Exception ex)
                {

                }
            }
           
           

           
        }
    }
}