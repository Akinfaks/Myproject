﻿using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Admin
{
    public partial class ApproveTrainers : System.Web.UI.Page
    {

        ConnectionManager connMgr = new ConnectionManager();
        EmailService.WebService emailWS = new EmailService.WebService();

        Utility utilities = new Utility();
        DataSet displayTrainers = null;
        DataTable displayPhotograph, displayTrainerList, displayUniqueIDResult = null;
        string biodataid = null;
        string _biodataid, _emailaddress, _phonenumber, _contactPerson, _trainingProvider = "";
        bool _approveUser = false;
   



        protected void Page_Load(object sender, EventArgs e)
        {
            displayTrainers = connMgr.Admin_Gettrainers();

            if (displayTrainers != null && displayTrainers.Tables.Count > 0)
            {
                GridView1.DataSource = displayTrainers;
                GridView1.DataBind();
                Session["dt"] = displayTrainers;
            }
        }

        protected void searchbyUID_Click(object sender, EventArgs e)
        {
            displayUniqueIDResult = connMgr.DisplayDatabyIDTrainers(searchbyUniqueID.Value);

            if (displayUniqueIDResult != null && displayUniqueIDResult.Rows.Count > 0)
            {
                //biodataid = displayArtisans.Rows[0]["ID"].ToString();
                GridView1.DataSource = displayUniqueIDResult;
                GridView1.DataBind();

            }
        }

        protected void excelExport_Click(object sender, EventArgs e)
        {
            utilities.ExportToExcel(((DataSet)Session["dt"]), HttpContext.Current, "Trainers List");
        }

        protected void approveID_Click(object sender, EventArgs e)
        {
            trainerApproval();
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            GridView1.DataBind();
        }

        protected void GridView1_DataBound(object sender, EventArgs e)
        {
            GridViewRow pagerrow = GridView1.BottomPagerRow;
            Label pageno = (Label)pagerrow.Cells[0].FindControl("L3");
            Label totalpageno = (Label)pagerrow.Cells[0].FindControl("L4");

            if ((pageno != null) && (totalpageno != null))
            {
                int pagen = GridView1.PageIndex + 1;
                int tot = GridView1.PageCount;

                pageno.Text = pagen.ToString();
                totalpageno.Text = tot.ToString();
            }
            else
            {
                Response.Write("<script>alert('No more Data to Display');</script>");
            }
        }

        protected void viewTrainers_Click(object sender, EventArgs e)
        {
            approveID.Visible = true;
            biodataid = ((LinkButton)sender).CommandArgument;

            displayTrainerList = connMgr.Admin_displayTrainerlist(Convert.ToInt32(biodataid));
            if (displayTrainerList.Rows.Count > 0)
            {
                compRegNo.Value = displayTrainerList.Rows[0]["COMPANYREG"].ToString();
                trainingProvider.Value = displayTrainerList.Rows[0]["NAMEOFTRAININGPROVIDER"].ToString();
                contactPerson.Value = displayTrainerList.Rows[0]["CONTACTPERSON"].ToString();
                uniqueid.Value = displayTrainerList.Rows[0]["UNIQUEID"].ToString();
                officeAddress.Value = displayTrainerList.Rows[0]["OFFICEADDRESS"].ToString();
                doReg.Value = displayTrainerList.Rows[0]["DATEOFREG"].ToString();
                emailAddress.Value = displayTrainerList.Rows[0]["EMAIL"].ToString();
                phoneNumber.Value = displayTrainerList.Rows[0]["PHONENUMBER"].ToString();

                Session["generic_biodataid"] = displayTrainerList.Rows[0]["BIODATAID"].ToString();

            }

            displayPhotograph = connMgr.GetPhotographByID(biodataid);
            if (displayPhotograph.Rows.Count > 0)
            {
                byte[] photoString = (byte[])displayPhotograph.Rows[0]["PHOTOGRAPH"];
                imgdisplay.ImageUrl = "data:image;base64," + Convert.ToBase64String(photoString);
            }


        }


        public static byte[] ToByteArray(string value)
        {
            char[] charArr = value.ToCharArray();
            byte[] bytes = new byte[charArr.Length];
            for (int i = 0; i < charArr.Length; i++)
            {
                byte current = Convert.ToByte(charArr[i]);
                bytes[i] = current;
            }

            return bytes;
        }

        internal void trainerApproval()
        {
            _biodataid = Session["generic_biodataid"].ToString();
            _emailaddress = emailAddress.Value;
            _phonenumber = phoneNumber.Value;
            _contactPerson = contactPerson.Value;
            _trainingProvider = trainingProvider.Value;

            _approveUser = connMgr.AdminApproveArtisans(Convert.ToInt32(_biodataid));

            if (_approveUser == true)
            {

                // string _subject = "NIOB Approval Notification.";
                string _subject = "NIOB Approval Notification.";
                string _body = " Dear " + _contactPerson + " you are receiving this email on behalf of " + _trainingProvider + " because the registration you made has been reviewed and approved.";

                try
                {

                    try
                    {
                        emailWS.sendmail1(_emailaddress, _subject, _body);
                    }
                    catch (Exception ex) { }

                    try { utilities.sendSmsAsync(_phonenumber, _body, _subject); }
                    catch (Exception ex) { }

                    notification.Text = utilities.ShowSuccess("Approval is successful and Notification has been sent.");

                }
                catch (Exception ex)
                {

                }
            }




        }

    }
}