﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Admin
{
    public partial class Admin : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["admin"] == null) 
                Response.Redirect("Login");
                
        }

        protected void logout_Click(object sender, EventArgs e)
        {
            Session.Remove("admin");
            Response.Redirect("Login");
        }

       
    }
}