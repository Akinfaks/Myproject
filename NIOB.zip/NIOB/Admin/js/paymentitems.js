﻿var pagecount = 10, totalrecords = 0, searchstring = "", from = "", to = "", sortstring = "";
var _activedata


$(function () {
    getTotalCount();
    $(document).ready(function () {
        populateTable();
    })
});

//get total records
//Send the AJAX call to the server
function getTotalCount() {
    //get total records
    //Send the AJAX call to the server
    $(function () {
        $.ajax({
            type: "POST",
            url: "../Service.asmx/Admin_GetPaymentItemsCount",
            data: '',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                var data = JSON.parse(result.d);
                if (result.d != "") {
                    var html = "";
                    if (data.length != 0) {
                        totalrecords = data[0].COUNT;
                    }
                }
            }
        })
    })
}

//populate tables
function populateTable() {
    resetPagination(); $('#norecord').html("");
    //check total records
    if (totalrecords == 0) {
        $('#norecord').html("<center>No record found</center>")
    }
    else {
        if (totalrecords % pagecount > 0) {
            totalpages = totalrecords / pagecount + 1;
        } else {
            totalpages = totalrecords / pagecount;
        }

        $('#pagination').twbsPagination({
            totalPages: totalpages,
            visiblePages: 3,
            onPageClick: function (event, page) {
                //$('#page-content').text('Page ' + page);
                var html = "";
                $.ajax({
                    type: "POST",
                    url: "../Service.asmx/Admin_GetPaymentItemsBatch",
                    data: '{pageno:"' + page + '",pagecount: "' + pagecount + '",searchstring: "' + searchstring + '",from: "' + from + '",to:"' + to + '",sortstring: "' + sortstring + '"}',
                    contentType: "application/json; charset=utf-8",
                    //dataType: "json",
                    async: true,
                    success: function (result) {
                        console.log(result)
                        var data = JSON.parse(result.d);
                        if (result.d != "") {
                            if (data.length != 0) {
                                console.log(data)
                                _activedata = data;
                                var count = (page-1) * pagecount;
                                $.each(data, function (index, item) {
                                    count++;
                                    var status = "", lbl_status = "";
                                    ////if (startdate <= Date.now() && enddate >= Date.now()) {
                                        status = "Active";
                                        lbl_status = "info";
                                    //} else if (startdate > Date.now()) {
                                    //    status = "Upcoming";
                                    //    lbl_status = "default";
                                    //} else {
                                    //    status = "Expired";
                                    //    lbl_status = "danger";
                                    //}

                                        html += "<tr><td>" + count + "</td><td style='width:20%'>" + item.ITEM + "</td><td style='width:20%'>" + item.DESCRIPTION + "</td><td>" + item.PRICE + "</td><td>" + getUserCategory(item.USERTYPE) + "</td><td class='hidden-480'><center><span class='label label-sm label-" + lbl_status + "'>" + status + "</span></center></td><td style='width:10%'><div class='btn-group'><button class='btn btn-xs' title='View Info'><i class='ace-icon fa fa-eye bigger-120'></i></button><button class='btn btn-xs btn-danger' title='Delete'><i class='ace-icon fa fa-ban bigger-120'></i></button></div></td></tr>";
                                });
                                $("#tbody_payment").html(html);
                            }
                        }
                    }
                });
            }
        });
    }
}

function formatDate(dateString) {
    return dateString.split("T")[0];
}

function getUserCategory(id) {
    switch (id) {
        case 1:
            return "Artisan";
        case 2:
            return "Assessor";
        case 3:
            return "Trainer";
        case 4:
            return "Company";
        default: return "-";
    }
}

//save training function
function savePayment() {
    var item = $("#item").val(), description = $("#description").val(), usertype = $("#category").val(),
        price = $("#price").val(), paymenttype = $("#paymenttype").val();

    if (validateInput()) {
        //save training
        //Send the AJAX call to the server
        $(function () {
            $.ajax({
                type: "POST",
                url: "../Service.asmx/Admin_SavePaymentItems",
                data: '{item:"' + item + '",description:"' + description + '",paymenttype:"' + paymenttype + '",price:"' + price + '",usertype:"' + usertype + '"}',
                contentType: "application/json; charset=utf-8",
                //dataType: "json",
                async: false,
                success: function (result) {                    
                    if (result.d != "") {
                        var data = result.d;
                        var html = "";
                        if (data == "true") {
                            clearInput();
                            getTotalCount();
                            populateTable()
                            bootbox.alert("Saved successfully!");
                        } else if (data == "false") {
                            bootbox.alert("An internal error occured");
                        } else if (data == "error") {
                            bootbox.alert("All fields are required!");
                        }
                    }
                }
            })
        })
    } else {
        bootbox.alert("All fields are required!");
    }

    return false;
}

//reset  pagination fnction
function resetPagination() {
    //reset pagination
    $('#pagination').empty();
    $('#pagination').removeData("twbs-pagination");
    $('#pagination').unbind("page");
}


function validateInput() {
    if ($("#item").val() == "" || $("#description").val() == "" || $("#paymenttype").val() == "" || $("#category").val() == "" || $("#price").val() == "")
        return false;
    else return true;
}

function clearInput() {
    $("#item").val(''); $("#description").val(''); $("#paymenttype").val(''); $("#category").val(''); $("#price").val('');
}