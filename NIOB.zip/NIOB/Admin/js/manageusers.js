﻿var totalartisan = 0, totaltrainer = 0, totalassessor = 0, totalcompany = 0, totalpages = 0, _activedata = null;
var pagecount = 10, searchstring = "ARTISAN", from = "", to = "", sortstring = "";
var ongoingcount = 0, pendingcount = 0, completedcount = 0, approvedcount = 0;

$(function () {
    getUserTotalCount();

    $(document).ready(function () {
        populateTable();
    });
});

//get total records
//Send the AJAX call to the server
function getUserTotalCount() {
    //get total records
    //Send the AJAX call to the server
    $(function () {
        $.ajax({
            type: "POST",
            url: "../Service.asmx/Admin_GetUsersOverView",
            data: '',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                var data = JSON.parse(result.d);
                if (result.d != "") {
                    var html = "";
                    if (data.length != 0) {
                        totalartisan = data.Table1[0]["ARTISANS"];
                        totaltrainer = data.Table3[0]["TRAINERS"];
                        totalassessor = data.Table2[0]["ASSESSORS"];
                        //totalcompany = data.Table4[0]["COMPANY"];
                    }
                }
            }
        })
    })
}

//manage tab filter on click
$("ul#category_tab li a").click(function (event) {

    resetPagination();
    var html = ""; $("#norecord").html(""); $("#tbody").html("");
    var filter = event.toElement.innerText;
    searchstring = filter.toUpperCase();
    getUserTotalCount();
    populateTable();
})

function formatDate(dateString) {
    return dateString.split("T")[0];
}

function formatDate2(dateString) {
    return dateString.replace("T"," ").substring(0, 19);
}

function populateTable() {    
    //get active totalrecords
    var totalrecords = getActiveTotal()


    //check total records
    console.log(totalrecords)
    if (totalrecords == 0) {
        $('#norecord').html("<center>No record found</center>")
    }
    else {
        if (totalrecords % pagecount > 0) {
            totalpages = totalrecords / pagecount + 1;
        } else {
            totalpages = totalrecords / pagecount;
        }

        $('#pagination').twbsPagination({
            totalPages: totalpages,
            visiblePages: 3,
            onPageClick: function (event, page) {
                //$('#page-content').text('Page ' + page);
                var html = "";
                $.ajax({
                    type: "POST",
                    url: "../Service.asmx/Admin_GetUsersByCategory",
                    data: '{pageno:"' + page + '",pagecount: "' + pagecount + '",searchstring: "' + searchstring + '",from: "' + from + '",to:"' + to + '",sortstring: "' + sortstring + '"}',
                    contentType: "application/json; charset=utf-8",
                    //dataType: "json",
                    async: true,
                    success: function (result) {
                        
                        var data = JSON.parse(result.d);
                        if (result.d != "") {
                            if (data.length != 0) {

                                _activedata = data;

                                $.each(data, function (index, item) {
                                    //get age from dob
                                    var dob = new Date(formatDate(item.DOB))
                                    var age = Math.ceil((Date.now() - dob) / (1000 * 60 * 60 * 24 * 365)) - 1;

                                    //get photograph
                                    var photo = getPhotograph(item.ID)

                                    //format adress
                                    var address = "";
                                    address = (item.STREET != null ? item.STREET.toLowerCase() + ", " : "") + (item.LGANAME != null ? item.LGANAME.toLowerCase() + ", " : "") + (item.STATENAME != null ? item.STATENAME.toLowerCase() : "");

                                    //getstatus and set active controls
                                    var status = "", showBtn = "inline", attrBtn = "inline", showAssessorBtn = "none";

                                    if (item.USERTYPE == "3") {
                                        showAssessorBtn = "inherited";
                                    }

                                    if (item.USERTYPE == "1") {
                                        status = "Active";
                                        showBtn = "none";
                                    } else if (item.APPROVALFLAG == "1") {
                                        status = "Approved";
                                        showBtn = "none";
                                    } else {
                                        status = "Pending";
                                    }


                                    html += "<tr class='tablerow'><td class='center'><div class='action-buttons'><a href='#' onclick='showUserInfo()' class='green bigger-140 show-details-btn' title='Show Details'><i class='ace-icon fa fa-angle-double-down'></i><span class='sr-only'>Details</span></a></div></td><td><a href='#'>" + item.UNIQUEID + "</a></td><td>" + item.FIRSTNAME + " " + item.SURNAME + "</td><td>" + item.STATENAME + "</td><td class='hidden-480'><span class='label label-sm label-" + getLabelStatus(status) + "'>" + status + "</span></td></tr>" +

                                    "<tr class='detail-row'><td colspan='8'><div class='table-detail'><div class='row'><div class='col-xs-12 col-sm-2'><div class='text-center'><img height='150' id='" + item.ID + "' class='thumbnail inline no-margin-bottom' alt='Domain Owner's Avatar' src=''/><br /><div class='label label-info label-xlg' style='margin-top:5px'><div class='inline position-relative'><a class='user-title-label' href='#'><span class='white' style='font-size:12px;font-style:bold'>" + item.FIRSTNAME + " " + item.SURNAME + "</span></a></div></div></div></div><div class='col-xs-12 col-sm-7'><div class='space visible-xs'></div><div class='profile-user-info profile-user-info-striped'><div class='profile-info-row'><div class='profile-info-name'> Username </div><div class='profile-info-value'><span>" + item.USERNAME + "</span></div></div><div class='profile-info-row'><div class='profile-info-name'> Address </div><div class='profile-info-value'><i class='fa fa-map-marker light-orange bigger-110'></i>&nbsp;<span>" + address + "</span></div></div><div class='profile-info-row'><div class='profile-info-name'> Age </div><div class='profile-info-value'><span>" + age + " years</span></div></div><div class='profile-info-row'><div class='profile-info-name'> Registered </div><div class='profile-info-value'><span>" + formatDate2(item.REGISTEREDDATE) + "</span></div></div><div class='profile-info-row'><div class='profile-info-name'> Email </div><div class='profile-info-value'><span>" + item.EMAIL + "</span></div></div><div class='profile-info-row'><div class='profile-info-name'> Mobile </div><div class='profile-info-value'><span>" + item.PHONENUMBER + "</span></div></div><div class='profile-info-row' style='display:" + showAssessorBtn + "'><div class='profile-info-name'> Assessor </div><div class='profile-info-value'><span>" + item.ASSESSORUID + "</span></div></div></div></div><div class='col-xs-12 col-sm-3' style='padding:20px'><div class='col-xs-12' style='border: 1px solid lightgrey; text-align: center; margin-bottom: 20px; padding: 15px'><h3><b>" + status.toUpperCase() + "</b></h3></div><br /><br /><div class='space visible-xs'></div><div class='col-xs-12' style='padding: 5px;'><center><div><span class='btn btn-info btn-sm tooltip-info' style='width:80px; font-style:bold' data-rel='tooltip' data-placement='right' title='View Info'>View</span>&nbsp;&nbsp;&nbsp;&nbsp;<span class='btn btn-info btn-sm tooltip-info' style='width:80px;font-style:bold; display:" + showBtn + "' data-rel='tooltip' data-placement='right' title='Approve User' onclick='approve(\""+ item.ID +"\")'>Approve</span></div></center></div></div></div></div></td></tr>";
                                });
                                $("#tbody_manageusers").html(html);
                            }
                        }
                    }
                });
            }
        });
    }
}

function getPhotograph(biodataid) {
    $(function () {
        $.ajax({
            type: "POST",
            url: "../Service.asmx/GetPhotographByID",
            data: '{"id":"' + biodataid + '"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: true,
            success: function (result) {
                $("#" + biodataid).prop("src", "data:image/png;base64," + result.d)
            }
        })
    })
}

function getLabelStatus(item) {
    switch (item.toUpperCase()) {
        case "PENDING":
            return "warning";
        case "APPROVED":
            return "success";
        case "ACTIVE":
            return "info";
    }
}

function getActiveTotal() {
    console.log(searchstring)
    switch (searchstring) {
        case "ARTISAN":
            return totalartisan;
        case "ASSESSOR":
            return totalassessor;
        case "TRAINER":
            return totaltrainer;
        //case "COMPANIES":
        //    return totalcompany;
    }
}

var prevElem;
function showUserInfo() {
    //e.preventDefault();
    var elem = this.document.activeElement;
    console.log(elem)
   
    if (elem != prevElem) {
        $.each($("#tbody_manageusers").children(), function (index, item) {
            var elems_ = item.children["0"].childNodes["0"].firstChild
            $(elems_).closest('tr').next().removeClass('open');
            $(elems_).find(ace.vars['.icon']).addClass('fa-angle-double-down').removeClass('fa-angle-double-up');       
        })
    }
    
    $(elem).closest('tr').next().toggleClass('open');
    $(elem).find(ace.vars['.icon']).toggleClass('fa-angle-double-down').toggleClass('fa-angle-double-up');

    //$(window).scrollTop(function () {
    //    return $(elem).offset().top;
    //});

    $("html, body").animate({
        scrollTop: $(elem).offset().top + 'px'
    }, 1);
    prevElem = elem;
}

//modal box confirm approval
function approve(id) {
    var filter = getItemByID(id)
    console.log(filter)
    bootbox.confirm({
        message: "Are you sure you want to approve " + filter[0].FIRSTNAME + " " + filter[0].SURNAME + "?",
        buttons: {
            confirm: {
                label: "Approve",
                className: "btn-primary btn-sm",
            },
            cancel: {
                label: "Cancel",
                className: "btn-sm",
                }
            },
            callback: function (result) {
                if (result) {
                    approveUser(filter[0]);
                }
            }
        }
    );
}

function getItemByID(code) {
    return _activedata.filter(
        function (_activedata) { return _activedata.ID == code }
    );
}

//reset  pagination fnction
function resetPagination() {
    //reset pagination
    $('#pagination').empty();
    $('#pagination').removeData("twbs-pagination");
    $('#pagination').unbind("page");
}

////Approval function
function approveUser(item) {
    //ajax call to approve user
    //Send the AJAX call to the server
    $(function () {
        $.ajax({
            type: "POST",
            url: "../Service.asmx/Admin_ApproveUsers",
            data: '{"biodataid":"' + item.ID + '"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                var data = JSON.parse(result.d);
                if (result.d != "") {
                    var html = "";
                    if (data.length != 0) {
                        bootbox.alert(item.SURNAME + " approved successfully!");
                    }
                }
            }
        });        
    })
    resetPagination();
    populateTable();
}