﻿var pagecount = 10, totalrecords = 0, searchstring = "", from = "", to = "", sortstring = "";
var _activedata


$(function () {
    getTotalCount();
    $(document).ready(function () {
        populateTable();
    })
});

//get total records
//Send the AJAX call to the server
function getTotalCount() {
    //get total records
    //Send the AJAX call to the server
    $(function () {
        $.ajax({
            type: "POST",
            url: "../Service.asmx/Admin_GetTrainingCount",
            data: '',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function (result) {
                var data = JSON.parse(result.d);
                if (result.d != "") {
                    var html = "";
                    if (data.length != 0) {
                        totalrecords = data[0].COUNT;
                    }
                }
            }
        })
    })
}

//populate tables
function populateTable() {
    resetPagination(); $('#norecord').html("");
    //check total records
    if (totalrecords == 0) {
        $('#norecord').html("<center>No record found</center>")
    }
    else {
        if (totalrecords % pagecount > 0) {
            totalpages = totalrecords / pagecount + 1;
        } else {
            totalpages = totalrecords / pagecount;
        }

        $('#pagination').twbsPagination({
            totalPages: totalpages,
            visiblePages: 3,
            onPageClick: function (event, page) {
                //$('#page-content').text('Page ' + page);
                var html = "";
                $.ajax({
                    type: "POST",
                    url: "../Service.asmx/Admin_GetTrainingBatch",
                    data: '{pageno:"' + page + '",pagecount: "' + pagecount + '",searchstring: "' + searchstring + '",from: "' + from + '",to:"' + to + '",sortstring: "' + sortstring + '"}',
                    contentType: "application/json; charset=utf-8",
                    //dataType: "json",
                    async: true,
                    success: function (result) {

                        var data = JSON.parse(result.d);
                        if (result.d != "") {
                            if (data.length != 0) {
                                console.log(data)
                                _activedata = data;
                                var count = (page-1) * pagecount;
                                $.each(data, function (index, item) {
                                    count++;
                                    var status = "", lbl_status = "";
                                    //format status column
                                    var startdate = new Date(formatDate(item.STARTDATE))
                                    var enddate = new Date(formatDate(item.ENDDATE))
                                    if (startdate <= Date.now() && enddate >= Date.now()) {
                                        status = "Ongoing";
                                        lbl_status = "info";
                                    } else if (startdate > Date.now()) {
                                        status = "Upcoming";
                                        lbl_status = "default";
                                    } else {
                                        status = "Expired";
                                        lbl_status = "danger";
                                    }

                                    html += "<tr><td>" + count + "</td><td style='widtd:40%'>" + item.TITLE + "</td><td>" + item.DURATION + "</td><td>" + formatDate(item.STARTDATE) + "</td><td class='hidden-480'><center><span class='label label-sm label-" + lbl_status + "'>" + status + "</span></center></td><td><div class='btn-group'><button class='btn btn-xs' title='View Info'><i class='ace-icon fa fa-eye bigger-120'></i></button><button class='btn btn-xs' title='Edit'><i class='ace-icon fa fa-pencil bigger-120'></i></button><button class='btn btn-xs btn-danger' title='Delete'><i class='ace-icon fa fa-trash-o bigger-120'></i></button></div></td></tr>";
                                });
                                $("#tbody_training").html(html);
                            }
                        }
                    }
                });
            }
        });
    }
}

function formatDate(dateString) {
    return dateString.split("T")[0];
}

//save training function
function saveTraining() {
    var title = $("#title").val(), description = $("#description").val(), venue = $("#venue").val(), duration = $("#duration").val(),
        price = $("#price").val(), startDate = $("#startDate").val(), endDate = $("#endDate").val();

    if (validateInput()) {
        //save training
        //Send the AJAX call to the server
        $(function () {
            $.ajax({
                type: "POST",
                url: "../Service.asmx/Admin_SaveTrainingInfo",
                data: '{title:"' + title + '",description:"' + description + '",venue:"' + venue + '",price:"' + price + '",duration:"' + duration + '",startDate:"' + startDate + '",endDate:"' + endDate + '"}',
                contentType: "application/json; charset=utf-8",
                //dataType: "json",
                async: false,
                success: function (result) {                    
                    if (result.d != "") {
                        var data = result.d;
                        var html = "";
                        if (data == "true") {
                            clearInput();
                            getTotalCount();
                            populateTable()
                            bootbox.alert("Saved successfully!");
                        } else if (data == "false") {
                            bootbox.alert("An internal error occured");
                        } else if (data == "error") {
                            bootbox.alert("All fields are required!");
                        }
                    }
                }
            })
        })
    } else {
        bootbox.alert("All fields are required!");
    }

    return false;
}

//reset  pagination fnction
function resetPagination() {
    //reset pagination
    $('#pagination').empty();
    $('#pagination').removeData("twbs-pagination");
    $('#pagination').unbind("page");
}


function validateInput() {
    if ($("#title").val() == "" || $("#description").val() == "" || $("#venue").val() == "" || $("#duration").val() == "" || $("#price").val() == "" || $("#startDate").val() == "" || $("#endDate").val() == "") return false;
    else return true;
}

function clearInput() {
    $("#title").val(''); $("#description").val(''); $("#venue").val(''); $("#duration").val(''); $("#price").val(''); $("#startDate").val(''); $("#endDate").val('');
}