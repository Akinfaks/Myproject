﻿$(function() {
    populateOverview()
    populatePaymentOverview()
    populateUsersOverview()
    populateTrainingOverview()

});

function populateOverview() {
    $("#spinner_overview").css("display", "initial")
    //get total records
    //Send the AJAX call to the server
    $(function () {
        $.ajax({
            type: "POST",
            url: "../Service.asmx/Admin_GetOverView",
            data: '',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: true,
            success: function (result) {
                var data = JSON.parse(result.d);
                if (result.d != "") {
                    var html = "";
                    if (data.length != 0) {
                        $("#totalpayment").html(data.Table[0]["TOTALPAYMENT"]);
                        $("#totalusers").html(data.Table1[0]["TOTALUSERS"]);
                        $("#totaltraining").html(data.Table2[0]["TOTALTRAINING"]);
                        $("#pendingapprovals").html(data.Table3[0]["PENDINGAPPROVALS"]);
                        $("#spinner_overview").css("display", "none");
                    }
                }
            }
        })
    })
}

function populatePaymentOverview() {
    $("#spinner_paymenttbl").css("display", "initial");
    $("#spinner_paymentoverview").css("display", "initial");
    //get total records
    //Send the AJAX call to the server
    $(function () {
        $.ajax({
            type: "POST",
            url: "../Service.asmx/Admin_GetPaymentOverView",
            data: '',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: true,
            success: function (result) {
                var data = JSON.parse(result.d);
                console.log(result.d)
                if (result.d != "") {
                    var html = "";
                    if (data.length != 0) {
                        $("#allpayment").html(data.Table[0]["ALLPAYMENT"]);
                        $("#dues").html(data.Table1[0]["DUES"]);
                        $("#trainingfee").html(data.Table2[0]["TRAININGFEE"]);
                        $("#spinner_paymentoverview").css("display", "none");
                        if (data.Table3.length != 0) {
                            
                            for (var i = 0; i < data.Table3.length; i++) {
                                var item = data.Table3[i];
                                if (i >= 3) break;
                                var status = item.STATUS == "1" ? "Success" : "Failed";
                                html += "<tr><td class='center'>" + (i + 1) + "</td><td>" + item.PAYMENTTYPE + "</td><td>" + item.UNIQUEID + "</td><td> ₦ " + item.AMOUNT + "</td><td>" + formatDate(item.DATECREATED) + "</td><td><span class='label label-sm label-success'>" + status + "</span></td></tr>";
                            }
                            $("#tbody_payment").html(html);
                            $("#spinner_paymenttbl").css("display", "none");
                        }
                    }
                }
            }
        })
    })
}

function populateUsersOverview() {
    $("#spinner_useroverview").css("display", "initial"); $("#spinner_usertbl").css("display", "initial");
    //get total records
    //Send the AJAX call to the server
    $(function () {
        $.ajax({
            type: "POST",
            url: "../Service.asmx/Admin_GetUsersOverView",
            data: '',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: true,
            success: function (result) {
                var data = JSON.parse(result.d);
                if (result.d != "") {
                    var html = "";
                    if (data.length != 0) {
                        $("#allusers").html(data.Table[0]["TOTALUSERS"]);
                        $("#artisan").html(data.Table1[0]["ARTISANS"]);
                        $("#assessor").html(data.Table2[0]["ASSESSORS"]);
                        $("#trainer").html(data.Table3[0]["TRAINERS"]);
                        $("#spinner_useroverview").css("display", "none"); 
                        var displayList = [];
                        if (data.Table4.length != 0) {
                            console.log(data.Table4)
                            var count = 1;
                            for (var i = 0; i < data.Table4.length; i++) {
                                var item = data.Table4[i];
                                if (displayList.indexOf(item.MEMBERID) >= 0) continue;

                                html += "<tr><td class='center'>" + count++ + "</td><td>" + item.MEMBERID + "</td><td>" + item.USERTYPE + "</td><td>" + formatDate(item.DATECREATED) + "</td></tr>";

                                displayList.push(item.MEMBERID);
                                
                                if (displayList.length == 3) break;                                
                            }
                            $("#tbody_users").html(html);
                            $("#spinner_usertbl").css("display", "none");
                        }
                    }
                }
            }
        })
    })
}

function populateTrainingOverview() {
    $("#spinner_trainingoverview").css("display", "initial"); $("#spinner_trainingtbl").css("display", "initial");
    //get total records
    //Send the AJAX call to the server
    $(function () {
        $.ajax({
            type: "POST",
            url: "../Service.asmx/Admin_GetTrainingOverView",
            data: '',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: true,
            success: function (result) {
                var data = JSON.parse(result.d);
                if (result.d != "") {
                    var html = "";
                    if (data.length != 0) {
                        $("#alltrainings").html(data.Table[0]["TOTALTRAINING"]);
                        $("#activetr").html(data.Table1[0]["ACTIVE"]);
                        $("#upcomingtr").html(data.Table2[0]["UPCOMING"]);
                        $("#activetrainees").html(data.Table3[0]["ACTIVETRAINEES"]);
                        $("#spinner_trainingoverview").css("display", "none");
                        if (data.Table3.length != 0) {
                            for (var i = 0; i < data.Table4.length; i++) {
                                var item = data.Table4[i];
                                if (i >= 3) break;
                                html += "<tr><td class='center'>" + (i + 1) + "</td><td>" + item.TITLE + "</td><td>" + item.PARTICIPANTS + "</td><td>" + item.DURATION + "</td><td>" + formatDate2(item.STARTDATE) + "</td><td>" + formatDate2(item.ENDDATE) + "</td></tr>";
                            }
                            $("#tbody_training").html(html);
                            $("#spinner_trainingtbl").css("display", "none");
                        }
                    }
                }
            }
        })
    })
}

function formatDate(dateString) {
    return dateString.replace("T", " ").substring(0,19);
}

function formatDate2(dateString) {
    return dateString.split("T")[0];
}