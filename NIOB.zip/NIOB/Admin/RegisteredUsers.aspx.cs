﻿using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Admin
{
    public partial class RegisteredUsers : System.Web.UI.Page
    {

        ConnectionManager connMgr = new ConnectionManager();
        DataSet displayRegUser, searchRegUsersbyID = null;
        Utility utilities = new Utility();
        string _uniqueID = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            displayRegUser = connMgr.Admin_DisplayRegisteredUsers();
            if (displayRegUser != null && displayRegUser.Tables.Count > 0)
            {
                // display value of dataset table to a variable.
                _uniqueID = Convert.ToString(displayRegUser.Tables[0].Rows[0]["UNIQUEID"]);

                regUsers.DataSource = displayRegUser;
                regUsers.DataBind();

                Session["dt"] = displayRegUser;
            }
           

        }

        protected void regUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            regUsers.PageIndex = e.NewPageIndex;
            regUsers.DataBind();
        }

        protected void regUsers_DataBound(object sender, EventArgs e)
        {
            GridViewRow pagerrow = regUsers.BottomPagerRow;
            Label pageno = (Label)pagerrow.Cells[0].FindControl("L3");
            Label totalpageno = (Label)pagerrow.Cells[0].FindControl("L4");

            if ((pageno != null) && (totalpageno != null))
            {
                int pagen = regUsers.PageIndex + 1;
                int tot = regUsers.PageCount;

                pageno.Text = pagen.ToString();
                totalpageno.Text = tot.ToString();
            }
            else
            {
                Response.Write("<script>alert('No more Data to Display');</script>");
            }
        }

        protected void searchbyUID_Click(object sender, EventArgs e)
        {
            searchRegUsersbyID = connMgr.Admin_SearchRegisteredUsers(_uniqueID);

            if (searchRegUsersbyID != null && searchRegUsersbyID.Tables.Count > 0)
            {
                //biodataid = displayArtisans.Rows[0]["ID"].ToString();
                regUsers.DataSource = searchRegUsersbyID;
                regUsers.DataBind();

            }
        }

     

        protected void excelExport_Click(object sender, EventArgs e)
        {
            utilities.ExportToExcel(((DataSet)Session["dt"]), HttpContext.Current, "NIOB Users List");
        }
    }
}