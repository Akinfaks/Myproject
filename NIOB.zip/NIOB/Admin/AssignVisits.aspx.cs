﻿using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Admin
{
    public partial class AssignVisits : System.Web.UI.Page
    {
        ConnectionManager _connMgr = new ConnectionManager();
        long assignVisitID = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                fillGrid();
            }

            if (!Page.IsPostBack)
            {

                foreach (DataRow dr in _connMgr.GetTrainerLists().Tables[0].Rows)
                {
                    TrainerList.Items.Add(new ListItem(dr["NAMEOFTRAININGPROVIDER"].ToString(), dr["ID"].ToString()));
                }
                foreach (DataRow dr in _connMgr.GetTrainingLists().Tables[0].Rows)
                {
                    TrainingList.Items.Add(new ListItem(dr["TITLE"].ToString(), dr["ID"].ToString()));
                }

                foreach (DataRow dr in _connMgr.GetAssesorLists().Tables[0].Rows)
                {
                    AssesorList.Items.Add(new ListItem(dr["ASSESORS"].ToString(), dr["ID"].ToString()));
                }
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {

            try
            {
              

                _connMgr.InsertAssignVisit( Int32.Parse(TrainingList.SelectedItem.Value), Int32.Parse(TrainerList.SelectedItem.Value), Int32.Parse(AssesorList.SelectedItem.Value));


                lblalert.Text = ShowSuccess("Assign officer was assigned successfully.");

                //clear entries
                
                TrainerList.SelectedIndex = 0;
                TrainingList.SelectedIndex = 0;
                AssesorList.SelectedIndex = 0;



            }
            catch (Exception ex)
            {
                lblalert.Text = ShowError("An error occured while performing this task.");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
      
         {
            try
            {
            
                assignVisitID = Convert.ToInt64((((Button)sender).CommandArgument));

                _connMgr.DeleteAssignVisit(assignVisitID);

                lblalert.Text = ShowSuccess("Item  deleted successfully.");


            }
            catch (Exception ex)
            {
                lblalert.Text = ShowError("An error occured while performing this task.");
            }

        }
        private void fillGrid()
        {
            var result = _connMgr.DisplayAssignVisit();
            if (result == null)
            {
               lblalert.Text = ShowError("Not Yet Assigned Any Officer .");
            }

            gvState.DataSource = result;
            gvState.DataBind();
        }

        public string ShowSuccess(string Message)
        {
            return "<div class='alert alert-success alert-dismissable'> <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>" + Message + " </div>";
        }


        public string ShowError(string Message)
        {

            return "<div class='alert alert-danger alert-dismissable'> <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>" + Message + " </div>";

        }

    }
}
