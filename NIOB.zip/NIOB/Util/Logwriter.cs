﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace NIOB.Util
{
    public class Logwriter
    {
        private const string path = @"C:/ErrorLog/niob";

        public static void logError(string message) {
            var timestamp = DateTime.Now;
            string txtfile = path + "/" + timestamp.Date + ".txt";
            if (!Directory.Exists(txtfile))
            {
                Directory.CreateDirectory(txtfile);
            }
            if (String.IsNullOrEmpty(message))
                File.AppendAllText(txtfile, timestamp + " " + message);
        }
    }
}