﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NIOB.Util
{
    public class UserType
    {
        internal static string getTypeName(int p)
        {
            switch (p)
            {
                case 1:
                    return "Artisan";
                case 2:
                    return "Assessor";
                case 3:
                    return "Trainer";
                case 4:
                    return "Company";
                case 5:
                    return "Admin";
                default:
                    return "";
            }
        }

        internal static int getTypeID(string p)
        {
            switch (p)
            {
                case "Artisan":
                    return 1;
                case "Assessor":
                    return 2;
                case "Trainer":
                    return 3;
                case "Company":
                    return 4;
                case "Admin":
                    return 5;
                default:
                    return 0;
            }
        }
    }
}