﻿using System.Net.Mail;

namespace NIOB.Util
{
    public class SendEmail
    {
        internal bool sendMail(string to, string subject, string body)
        {
            var objeto_mail = new MailMessage();
            SmtpClient client = new SmtpClient();
            client.Host = "smtp.gmail.com";
            client.Port = 587;
            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            System.Net.NetworkCredential nc = new System.Net.NetworkCredential();
            nc.UserName = "services@chams.com";
            nc.Password = "welcome12@";
            client.Credentials = nc;

            objeto_mail.From = new MailAddress("services@chams.com", "NIOB");

            // to = "afakokunde@chams.com,akinfaks@yahoo.com";

            if (to.Contains(","))
            {
                foreach (string add in to.Split(','))
                {
                    objeto_mail.To.Add(new MailAddress(add));
                }
            }
            else
            {
                objeto_mail.To.Add(new MailAddress(to));
            }

            objeto_mail.Subject = subject;
            objeto_mail.Body = body;
            objeto_mail.IsBodyHtml = true;
            client.Send(objeto_mail);
            return true;
        }
    }
}