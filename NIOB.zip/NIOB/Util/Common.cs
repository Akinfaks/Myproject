﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace NIOB.Util
{
    public class Common
    {
        private static string encrypt(string value, string key)
        {
            TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
            des.IV = new byte[8];
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(key, new byte[-1 + 1]);
            des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
            MemoryStream ms = new MemoryStream((value.Length * 2) - 1);
            CryptoStream encStream = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write);
            byte[] plainBytes = Encoding.UTF8.GetBytes(value);
            encStream.Write(plainBytes, 0, plainBytes.Length);
            encStream.FlushFinalBlock();
            byte[] encryptedBytes = new byte[Convert.ToInt32(ms.Length - 1) + 1];
            ms.Position = 0;
            ms.Read(encryptedBytes, 0, Convert.ToInt32(ms.Length));
            encStream.Close();
            return Convert.ToBase64String(encryptedBytes);
        }

        private static string decrypt(string value, string key)
        {
            TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
            des.IV = new byte[8];
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(key, new byte[-1 + 1]);
            des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
            byte[] encryptedBytes = Convert.FromBase64String(value);
            MemoryStream ms = new MemoryStream(value.Length);
            CryptoStream decStream = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write);
            decStream.Write(encryptedBytes, 0, encryptedBytes.Length);
            decStream.FlushFinalBlock();
            byte[] plainBytes = new byte[Convert.ToInt32(ms.Length - 1) + 1];
            ms.Position = 0;
            ms.Read(plainBytes, 0, Convert.ToInt32(ms.Length));
            decStream.Close();
            return Encoding.UTF8.GetString(plainBytes);
        }

        public static string EncryptText(string PlainText, string constantString)
        {
            //String constantString = ConfigurationManager.AppSettings["secretkey"].ToString();
            return encrypt(PlainText, constantString);//"chams123#"
        }

        public static string DecryptText(string CipherText, string constantString)
        {
            //String constantString = ConfigurationManager.AppSettings["secretkey"].ToString();
            return decrypt(CipherText, constantString);//"chams123#"
        }

        public static string EncryptText(string CipherText)
        {
            if (CipherText == "")
            {
                return "";
            }
            String constantString = ConfigurationManager.AppSettings["secretkey"].ToString();
            return encrypt(CipherText, constantString);//"chams123#"
        }

        public static string DecryptText(string CipherText)
        {
            String constantString = ConfigurationManager.AppSettings["secretkey"].ToString();
            return decrypt(CipherText, constantString);//"chams123#"
        }       
    }
}