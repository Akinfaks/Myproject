﻿using NIOB.BusinessObjects;
//using Oracle.DataAccess.Client;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace NIOB.Util
{
    public class ConnectionManager
    {
        private static string connString = ConfigurationManager.ConnectionStrings["OracleString"].ConnectionString;
        TrainerInfo trainerinfos = new TrainerInfo();
        internal OracleConnection getConnection()
        {
            OracleConnection con = new OracleConnection(connString);
            return con;
        }



        /// <summary>
        /// DisplayAssignVisit T & A 
        /// </summary>

        internal DataTable DisplayAssignVisit()
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection();
                OracleCommand cmd = new OracleCommand("GETASSIGNEDVISIT", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }
            return dt;
        }



        internal DataTable GETASSIGNEDVISITBYID2(long _CurrentTrainerID)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection();
                OracleCommand cmd = new OracleCommand("GETASSIGNEDVISITBYID2", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_TRAINERID", OracleDbType.Int64, _CurrentTrainerID, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);

            }
            catch (Exception ex)
            {
                throw new Exception();
            }
            return dt;
        }
        internal DataTable GETASSIGNEDVISITBYID(long biodataid)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection();
                OracleCommand cmd = new OracleCommand("GETASSIGNEDVISITBYID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_ASSESSORID", OracleDbType.Int64, biodataid, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);

            }
            catch (Exception ex)
            {
                throw new Exception();
            }
            return dt;
        }
        internal DataTable DeleteAssignVisit(long assignVisitID)
        {
            DataTable dt = new DataTable();

            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {

                conn = getConnection();
                OracleCommand cmd = new OracleCommand("DELETEASSIGNVISIT", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_ID", OracleDbType.Int64, assignVisitID, ParameterDirection.Input));
               // cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);

            }
            catch (Exception ex)
            {

            }
            return dt;

        }

        internal DataTable displayTrainerProfile(long biodataid)
        {
            DataTable dt = new DataTable();

            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {

                conn = getConnection();
                OracleCommand cmd = new OracleCommand("Admin_TrainerProfile", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_BID", OracleDbType.Int64, biodataid, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);

            }
            catch (Exception ex)
            {

            }
            return dt;

        }




        internal DataTable displayArtisanrProfile(long biodataid)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection();
                OracleCommand cmd = new OracleCommand("Admin_ArtisanProfile", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_BID", OracleDbType.Int64, biodataid, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);

            }
            catch (Exception ex)
            {
                throw new Exception();
            }
            return dt;
        }


        internal DataTable displayAssesorProfile(long biodataid)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection();
                OracleCommand cmd = new OracleCommand("ADMIN_ASSESORPROFILE", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_BID", OracleDbType.Int64, biodataid, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);

            }
            catch (Exception ex)
            {
                throw new Exception();
            }
            return dt;
        }




        internal DataTable getUserInfo(string username, string pwd)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetUserInfo", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PASSWORD", OracleDbType.Varchar2, pwd, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }

            return dt;
        }

        internal long InsertUser(UserObject user)
        {
            OracleConnection conn = new OracleConnection();
            long biodataid = 0;



            //format date
            //string DOB, StartDate, DateJoined;
            DateTime DOB = new DateTime(), StartDate = new DateTime(), DateJoined = new DateTime();
            DOB = Convert.ToDateTime(user.biodata.DOB);
            if (user.emp_info.StartDate != "") { StartDate = Convert.ToDateTime(user.emp_info.StartDate); }

            if (user.association.Datejoined != "") { DateJoined = Convert.ToDateTime(user.association.Datejoined); }
            int usertype = user.tbl_user.UserType;

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection

                OracleCommand cmd = new OracleCommand("InsertUser", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                //biodata
                cmd.Parameters.Add(new OracleParameter("V_TITLE", OracleDbType.Varchar2, user.biodata.Title, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FIRSTNAME", OracleDbType.Varchar2, user.biodata.Firstname, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SURNAME", OracleDbType.Varchar2, user.biodata.Surname, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_DOB", OracleDbType.Date, DOB, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_GENDER", OracleDbType.Varchar2, user.biodata.Gender, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PHONENUMBER", OracleDbType.Varchar2, user.biodata.PhoneNumber, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_STATE", OracleDbType.Varchar2, user.biodata.StateID, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_UID", OracleDbType.Varchar2, user.biodata.UniqueID, ParameterDirection.Input));

                //eduinfo
                cmd.Parameters.Add(new OracleParameter("V_PRIMARY", OracleDbType.Varchar2, user.edu_info.Primary, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SECONDARY", OracleDbType.Varchar2, user.edu_info.Secondary, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TECHNICAL", OracleDbType.Varchar2, user.edu_info.Technical, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TERTIARY", OracleDbType.Varchar2, user.edu_info.Tertiary, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PRIMARYCERT", OracleDbType.Varchar2, user.edu_info.PrimaryCert, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SECONDARYCERT", OracleDbType.Varchar2, user.edu_info.SecondaryCert, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TECHNICALCERT", OracleDbType.Varchar2, user.edu_info.TechnicalCert, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TERTIARYCERT", OracleDbType.Varchar2, user.edu_info.TertiaryCert, ParameterDirection.Input));

                //address info
                cmd.Parameters.Add(new OracleParameter("V_STREET", OracleDbType.Varchar2, user.address_info.Street, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_LGA", OracleDbType.Varchar2, user.address_info.LGA, ParameterDirection.Input));

                //emp info
                cmd.Parameters.Add(new OracleParameter("V_EMP_TITLE", OracleDbType.Varchar2, user.emp_info.Title, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_EMPLOYER", OracleDbType.Varchar2, user.emp_info.Employer, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_EMPLOYERADDRESS", OracleDbType.Varchar2, user.emp_info.Address, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SCOPE", OracleDbType.Varchar2, user.emp_info.Scope, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_STARTDATE", OracleDbType.Date, StartDate, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_EMPSTATUS", OracleDbType.Varchar2, user.emp_info.Status, ParameterDirection.Input));

                //tbl_user info
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, user.tbl_user.Username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PASSWORD", OracleDbType.Varchar2, user.tbl_user.Password, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_EMAIL", OracleDbType.Varchar2, user.tbl_user.Email, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_USERTYPE", OracleDbType.Varchar2, user.tbl_user.UserType, ParameterDirection.Input));

                //association info
                cmd.Parameters.Add(new OracleParameter("V_ASSOCIATIONNAME", OracleDbType.Varchar2, user.association.Name, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_POSITION", OracleDbType.Varchar2, user.association.PositionHeld, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_DATEJOINED", OracleDbType.Date, DateJoined, ParameterDirection.Input));

                //activationkey info
                cmd.Parameters.Add(new OracleParameter("V_ACTIVATIONKEY", OracleDbType.Varchar2, user.acticationkey.Key, ParameterDirection.Input));

                //photograph
                cmd.Parameters.Add(new OracleParameter("V_PHOTO", OracleDbType.Blob, user.photo.Photograph, ParameterDirection.Input));

                //declare biodata return param
                cmd.Parameters.Add(new OracleParameter("V_BIODATAID", OracleDbType.Int32)).Direction = ParameterDirection.Output;

                //cmd.BindByName = true;
                cmd.ExecuteNonQuery();

                biodataid = Convert.ToInt64(cmd.Parameters["V_BIODATAID"].Value.ToString());

            }
            catch (Exception ex)
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
            return biodataid;
        }

        internal bool CheckUID(string uniqueNumber, int p)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            string uniqueId = (p == 1 ? "AR" : p == 2 ? "AS" : p == 3 ? "TR" : "") + uniqueNumber;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("CheckUniqueID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_UID", OracleDbType.Varchar2, uniqueId, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            //if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection

            return dt.Rows.Count > 0;
        }

        private string getPrefix(int p)
        {
            switch (p)
            {
                case 1:
                    return "AR";
                case 2:
                    return "AS";
                case 3:
                    return "TR";
                default:
                    return "";
            }
        }

        internal DataTable GetPaymentHistoryBatch(string username, int pageno, int pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("GetPaymentHistoryBatch", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGENO", OracleDbType.Int32, pageno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGECOUNT", OracleDbType.Int32, pagecount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SEARCHSTRING", OracleDbType.Varchar2, searchstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FROM", OracleDbType.Varchar2, from, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TO", OracleDbType.Varchar2, to, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SORTSTRING", OracleDbType.Varchar2, sortstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            return dt;
        }

        internal DataTable GetStates()
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("GetStates", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            //if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection

            return dt;
        }

        internal DataTable GetLGA(string stateid)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("GETLGA", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_STATEID", OracleDbType.Varchar2, stateid, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            //if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection

            return dt;
        }



        //Insert assigned trainerandassessors

        internal void InsertAssignVisit( Int32 Training, Int32 TrainerList, Int32 Assesor)
        {
            OracleConnection conn = new OracleConnection();
            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("INSERTASSIGNEDTA", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_TRAININGID", OracleDbType.Int32, Training, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TRAINERID", OracleDbType.Int32, TrainerList, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ASSESSORID", OracleDbType.Int32, Assesor, ParameterDirection.Input));
                cmd.ExecuteNonQuery();


            }
            catch
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection

        }

    

        internal void InsertTrainerInfo(TrainerInfo trainerinfo)
        {
            OracleConnection conn = new OracleConnection();
            //long biodataid2 = 0;
            DateTime DOR = new DateTime();
            DOR = Convert.ToDateTime(trainerinfo.DateOfRegistration);

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("InsertTrainerInfo", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                //trainer info
                cmd.Parameters.Add(new OracleParameter("V_COMPREG", OracleDbType.Varchar2, trainerinfo.CompanyReg, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_NOTP", OracleDbType.Varchar2, trainerinfo.NameofTrainingProvider, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_CONTPERSON", OracleDbType.Varchar2, trainerinfo.ContactPerson, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_OFFADDRESS", OracleDbType.Varchar2, trainerinfo.OfficeAddress, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_DATEOFREG", OracleDbType.Date, DOR, ParameterDirection.Input));
                //cmd.Parameters.Add(new OracleParameter("V_STATE", OracleDbType.Varchar2, trainerinfo.State, ParameterDirection.Input));
                //cmd.Parameters.Add(new OracleParameter("V_PHNUMBER", OracleDbType.Varchar2, trainerinfo.PhoneNumber, ParameterDirection.Input));
                //cmd.Parameters.Add(new OracleParameter("V_EMAILADD", OracleDbType.Varchar2, trainerinfo.EmailAddress, ParameterDirection.Input));
                //cmd.Parameters.Add(new OracleParameter("V_PASSWORD", OracleDbType.Varchar2, trainerinfo.Password, ParameterDirection.Input));



                cmd.ExecuteNonQuery();
                // biodataid2 = Convert.ToInt64(cmd.Parameters["V_BIODATAID"].Value.ToString());
            }
            catch
            {
                throw new Exception();
            }
            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
                                                                 // return biodataid2;
        }

        internal int InsertPrev_Emp(Employment_Info prev_emp)
        {
            OracleConnection conn = new OracleConnection();
            int res = 0;

            //format date
            string StartDate, EndDate;
            StartDate = prev_emp.StartDate != "" ? Convert.ToDateTime(prev_emp.StartDate).ToString("dd-MMM-yyyy") : null;
            EndDate = prev_emp.StartDate != "" ? Convert.ToDateTime(prev_emp.EndDate).ToString("dd-MMM-yyyy") : null;

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("InsertPrevEmpInfo", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                //doc info
                cmd.Parameters.Add(new OracleParameter("V_BIODATAID", OracleDbType.Int32, prev_emp.BiodataID, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TITLE", OracleDbType.Varchar2, prev_emp.Title, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_EMPLOYER", OracleDbType.Varchar2, prev_emp.Employer, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_STARTDATE", OracleDbType.Varchar2, StartDate, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ENDDATE", OracleDbType.Varchar2, EndDate, ParameterDirection.Input));

                res = cmd.ExecuteNonQuery();
            }
            catch
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
            return res;
        }

        internal void InsertDocumentInfo(Document_Info doc_info)
        {
            OracleConnection conn = new OracleConnection();

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("InsertUserDocInfo", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                //doc info
                cmd.Parameters.Add(new OracleParameter("V_BIODATAID", OracleDbType.Int32, doc_info.BiodataID, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_DOCTYPE", OracleDbType.Varchar2, doc_info.DocumentType, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_DOCURL", OracleDbType.Varchar2, doc_info.DocumentUrl, ParameterDirection.Input));

                cmd.ExecuteNonQuery();
            }
            catch
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
        }

        internal DataTable checkUsername(string username)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("CheckUsername", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            //if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection

            return dt;
        }

        internal DataTable checkEmail(string email)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("CheckEmail", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_EMAIL", OracleDbType.Varchar2, email, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            //if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection

            return dt;
        }

        internal Int64 ActivateAccount(string activationKey)
        {
            OracleConnection conn = new OracleConnection();
            long response = 0;

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("ActivateAccount", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_KEY", OracleDbType.Varchar2, activationKey, ParameterDirection.Input));
                //declare biodata return param
                cmd.Parameters.Add(new OracleParameter("V_BIODATAID", OracleDbType.Int64)).Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                response = Convert.ToInt64(cmd.Parameters["V_BIODATAID"].Value.ToString());
            }
            catch
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
            return response;
        }

        internal DataSet getInfoByUsername(string username)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("GetInfoByUsername", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR2", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            //if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection

            return ds;
        }

        internal DataSet GetPaymentItemsByCategory(int usertype)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetPaymentItemsByCategory", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERTYPE", OracleDbType.Varchar2, usertype, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds;
        }

        internal DataTable GetUserPaymentInfo(string username)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetUserPaymentInfo", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable GetUserPaymentLog(string username)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetUserPaymentLog", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal Int64 InsertUserPaymentInfo(String username, Payment_Info paymentinfo)
        {
            OracleConnection conn = new OracleConnection();
            long insertID = 0;

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("InsertUserPaymentInfo", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ITEMID", OracleDbType.Varchar2, paymentinfo.ItemID, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PRICE", OracleDbType.Varchar2, paymentinfo.Price, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_REFNO", OracleDbType.Varchar2, paymentinfo.RefrenceNo, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_STATUS", OracleDbType.Int32, paymentinfo.Status, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ID", OracleDbType.Int32, ParameterDirection.Output));
                cmd.ExecuteNonQuery();
                insertID = Convert.ToInt64(cmd.Parameters["V_ID"].Value.ToString());

            }
            catch
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
            return insertID;
        }

        //internal void UpdateUserPaymentInfo(String username, Payment_Info paymentinfo)
        //{
        //    OracleConnection conn = new OracleConnection();

        //    try
        //    {
        //        conn = getConnection(); // connect to oracle
        //        if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
        //        OracleCommand cmd = new OracleCommand("UpdateUserPaymentInfo", conn);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
        //        cmd.Parameters.Add(new OracleParameter("V_REFNO", OracleDbType.Varchar2, paymentinfo.RefrenceNo, ParameterDirection.Input));
        //        cmd.Parameters.Add(new OracleParameter("V_STATUS", OracleDbType.Int32, paymentinfo.Status, ParameterDirection.Input));

        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.ExecuteNonQuery();
        //    }
        //    catch
        //    {
        //        throw new Exception();
        //    }

        //    if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
        //}

        internal long InsertPaymentLog(String username, Payment_Log paymentlog)
        {
            OracleConnection conn = new OracleConnection();
            long insertID = 0;
            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("InsertPaymentLog", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TYPE", OracleDbType.Varchar2, paymentlog.PaymentType, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PRICE", OracleDbType.Varchar2, paymentlog.Amount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_REFNO", OracleDbType.Varchar2, paymentlog.ReferenceNo, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_STATUS", OracleDbType.Int32, paymentlog.Status, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ID", OracleDbType.Int32, ParameterDirection.Output));
                cmd.ExecuteNonQuery();
                insertID = Convert.ToInt64(cmd.Parameters["V_ID"].Value.ToString());
            }
            catch
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
            return insertID;
        }

        internal void UpdatePaymentLog(String username, Payment_Log paymentlog, String table)
        {
            OracleConnection conn = new OracleConnection();

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("UpdatePaymentLog", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_REFNO", OracleDbType.Varchar2, paymentlog.ReferenceNo, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_STATUS", OracleDbType.Int32, paymentlog.Status, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TABLE", OracleDbType.Varchar2, table, ParameterDirection.Input));

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
            }
            catch
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
        }

        internal DataTable GetPaymentDue(string username)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetPaymentDue", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];

        }

        internal DataTable GetAvailableTrainings()
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetAvailableTrainings", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable GetUserTrainings(String username, String filter)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetUserTrainings", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FILTER", OracleDbType.Varchar2, filter, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable GetAvailableTrainingsBatch(string username, int pageno, int pagecount, string searchstring, string from, string to,
            string sortstring)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("GetAvailableTrainingsBatch", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGENO", OracleDbType.Int32, pageno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGECOUNT", OracleDbType.Int32, pagecount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SEARCHSTRING", OracleDbType.Varchar2, searchstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FROM", OracleDbType.Varchar2, from, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TO", OracleDbType.Varchar2, to, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SORTSTRING", OracleDbType.Varchar2, sortstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            return dt;
        }

        internal DataTable GetUserTrainingsBatch(string username, int pageno, int pagecount, string searchstring, string from, string to,
            string sortstring)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("GetUserTrainingsBatch", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGENO", OracleDbType.Int32, pageno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGECOUNT", OracleDbType.Int32, pagecount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SEARCHSTRING", OracleDbType.Varchar2, searchstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FROM", OracleDbType.Varchar2, from, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TO", OracleDbType.Varchar2, to, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SORTSTRING", OracleDbType.Varchar2, sortstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            return dt;
        }

        internal DataTable GetPaymentItemByID(int p)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetPaymentItemByID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_ITEMID", OracleDbType.Varchar2, p, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable GetTrainingByID(string id)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetTrainingByID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_ITEMID", OracleDbType.Varchar2, id, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal long InsertUserTrainingInfo(string username, Training_Info traininginfo)
        {
            OracleConnection conn = new OracleConnection();
            long insertID = 0;

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("InsertUserTrainingInfo", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ITEMID", OracleDbType.Varchar2, traininginfo.TrainingID, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_REFNO", OracleDbType.Varchar2, traininginfo.ReferenceNo, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_STATUS", OracleDbType.Int32, traininginfo.Status, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ID", OracleDbType.Int32, ParameterDirection.Output));
                cmd.ExecuteNonQuery();
                insertID = Convert.ToInt64(cmd.Parameters["V_ID"].Value.ToString());

            }
            catch
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
            return insertID;
        }

        internal DataTable GetNews()
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetNews", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable GetUserTrainingsFilter(string username, string filter)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetUserTrainingsFilter", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }
            return ds.Tables[0];
        }

        internal long logUserAction(string username, string action, string ip)
        {
            OracleConnection conn = new OracleConnection();
            long insertID = 0;

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("LogUserAction", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ACTION", OracleDbType.Varchar2, action, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_IP", OracleDbType.Varchar2, ip, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ID", OracleDbType.Int32, ParameterDirection.Output));
                cmd.ExecuteNonQuery();
                insertID = Convert.ToInt64(cmd.Parameters["V_ID"].Value.ToString());

            }
            catch (Exception ex)
            {
                //throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
            return insertID;
        }

        internal DataTable GetUserInfoByEmail(string email)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetUserActivationByEmail", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_EMAIL", OracleDbType.Varchar2, email, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }
            return ds.Tables[0];
        }

        internal DataTable GetUserPwdByEmail(string email)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetUserPasswordByEmail", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_EMAIL", OracleDbType.Varchar2, email, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
            return ds.Tables[0];
        }

        internal DataTable GetTrainerInfo(string username, string filter)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetTrainerInfo", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FILTER", OracleDbType.Varchar2, filter, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable GetTrainerInfoBatch(string username, int pageno, int pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("GetTrainerInfoBatch", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGENO", OracleDbType.Int32, pageno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGECOUNT", OracleDbType.Int32, pagecount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SEARCHSTRING", OracleDbType.Varchar2, searchstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FROM", OracleDbType.Varchar2, from, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TO", OracleDbType.Varchar2, to, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SORTSTRING", OracleDbType.Varchar2, sortstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }
            return dt;
        }

        internal DataTable GetPhotographByID(string id)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("GetPhotographByID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_BIODATAID", OracleDbType.Varchar2, id, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }
            return dt;
        }

        internal int UpdateTrainerAssessment(string username, string id, string status, string result, string recommendation, int editstatus)
        {
            int resp = 0;
            OracleConnection conn = new OracleConnection();

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("UpdateTrainerAssessment", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TRAINERID", OracleDbType.Varchar2, id, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_STATUS", OracleDbType.Varchar2, status, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_RESULT", OracleDbType.Varchar2, result, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_RECOM", OracleDbType.Varchar2, recommendation, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_EDITSTATUS", OracleDbType.Int32, editstatus, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ID", OracleDbType.Int32, ParameterDirection.Output));
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                resp = Convert.ToInt32(cmd.Parameters["V_ID"].Value.ToString());
            }
            catch
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
            return resp;
        }

        internal DataTable GetArtisanInfo(string username, string filter)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetArtisanInfo", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FILTER", OracleDbType.Varchar2, filter, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable GetArtisanInfoBatch(string username, int pageno, int pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("GetArtisanInfoBatch", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGENO", OracleDbType.Int32, pageno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGECOUNT", OracleDbType.Int32, pagecount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SEARCHSTRING", OracleDbType.Varchar2, searchstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FROM", OracleDbType.Varchar2, from, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TO", OracleDbType.Varchar2, to, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SORTSTRING", OracleDbType.Varchar2, sortstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }
            return dt;
        }

        internal int UpdateArtisanAssessment(string username, string id, string status, string result, string recommendation, int editstatus)
        {
            int resp = 0;
            OracleConnection conn = new OracleConnection();

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("UpdateArtisanAssessment", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TRAINERID", OracleDbType.Varchar2, id, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_STATUS", OracleDbType.Varchar2, status, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_RESULT", OracleDbType.Varchar2, result, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_RECOM", OracleDbType.Varchar2, recommendation, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_EDITSTATUS", OracleDbType.Int32, editstatus, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ID", OracleDbType.Int32, ParameterDirection.Output));
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                resp = Convert.ToInt32(cmd.Parameters["V_ID"].Value.ToString());
            }
            catch
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
            return resp;
        }

        internal DataSet Admin_GetOverview()
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetOverview", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR1", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR2", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR3", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }

            return ds;
        }

        internal DataSet Admin_GetPaymentOverview()
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetPaymentOverview", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR1", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR2", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR3", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }

            return ds;
        }

        // get the list of artisans
        public DataSet Admin_GetArtisans()
        {
            DataSet dt = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetArtisan", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
            return dt;
        }
        // get the list of assesors
        public DataSet Admin_GetAssesors()
        {
            DataSet dt = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("ADMIN_GETASSESOR", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
            return dt;
        }

        // Approve artisans 
        public bool AdminApproveArtisans(int biodataid)
        {
            bool check = false;
            OracleConnection conn = new OracleConnection();
            try
            {
                conn = getConnection();
                OracleCommand cmd = new OracleCommand("APPROVE_USER", conn);
                cmd.Parameters.Add(new OracleParameter("V_BIODATAID", OracleDbType.Int32, Convert.ToInt32(biodataid), ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("RETVAL", OracleDbType.Int32)).Direction = ParameterDirection.Output;
                cmd.CommandType = CommandType.StoredProcedure;

                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                try
                {
                    cmd.ExecuteNonQuery();
                    int retval = Convert.ToInt32(cmd.Parameters["RETVAL"].Value.ToString());

                    if (retval > 0) check = true;
                }
                catch (Exception ex)
                {

                }

            }
            catch (Exception ex)
            {

            }
            return check;

            
        }

        // Approve assesors 
        public bool AdminApproveAssesors(int biodataid)
        {
            bool check = false;
            OracleConnection conn = new OracleConnection();
            try
            {
                conn = getConnection();
                OracleCommand cmd = new OracleCommand("APPROVE_USER", conn);
                cmd.Parameters.Add(new OracleParameter("V_BIODATAID", OracleDbType.Int32, Convert.ToInt32(biodataid), ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("RETVAL", OracleDbType.Int32)).Direction = ParameterDirection.Output;
                cmd.CommandType = CommandType.StoredProcedure;

                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                try
                {
                    cmd.ExecuteNonQuery();
                    int retval = Convert.ToInt32(cmd.Parameters["RETVAL"].Value.ToString());

                    if (retval > 0) check = true;
                }
                catch (Exception ex)
                {

                }

            }
            catch (Exception ex)
            {

            }
            return check;


        }





        // Approve trainers












        // get the list of trainers
        public DataSet Admin_Gettrainers()
        {
            DataSet dt = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_Gettrainer", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
            return dt;
        }

        // search datatable by ID for Artisans
        public DataTable DisplayDatabyID(string uniqueID)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetArtisanbyID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_unique", OracleDbType.Varchar2, uniqueID, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            return dt;
        }


        

        // search datatable by ID for Artisans
        public DataTable DisplayAssesorbyID(string uniqueID)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("ADMIN_GETASSESORBYID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_unique", OracleDbType.Varchar2, uniqueID, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            return dt;
        }


        // search datatable by ID for trainers
        public DataTable DisplayDatabyIDTrainers(string uniqueID)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetTrainerbyID", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_unique", OracleDbType.Varchar2, uniqueID, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            return dt;
        }

        // display registered users
        public DataSet Admin_DisplayRegisteredUsers()
        {
            DataSet dt = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_DisplayRegUsers", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            return dt;
        }
   
        // display registered Assesors
        public DataSet Admin_DisplayRegisteredAssesors()
        {
            DataSet dt = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("ADMIN_DISPLAYREGASSESORS", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            return dt;
        }


        //Get trainerslist
       
        public DataSet GetTrainerLists()
        {
            DataSet dt = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GETTRAINERS", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            return dt;
        }
        // Get Training List
        public DataSet GetTrainingLists()
        {
            DataSet dt = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GETTRAININGS", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            return dt;
        }

        // Get Assesor List
        public DataSet GetAssesorLists()
        {
            DataSet dt = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GETASSESORS", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            return dt;
        }



        // search registered users
        public DataSet Admin_SearchRegisteredUsers(string uniqueID)
        {
            DataSet dt = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_Search_DisplayRegUsers", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_UID", OracleDbType.Varchar2, uniqueID, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            return dt;
        }

    
        // search registered Assesors
        public DataSet Admin_SearchRegisteredAssesors(string uniqueID)
        {
            DataSet dt = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("ADMIN_SEARCH_REGASSESORS", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_UID", OracleDbType.Varchar2, uniqueID, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            return dt;
        }




        // display registered trainers 
        public DataSet Admin_DisplayRegisteredTrainers()
        {
            DataSet dt = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_DisplayRegTrainers", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            return dt;
        }




        // display artisan list using id
        public DataTable Admin_displayArtisanlist(int bid)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_displayartisans", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_BID", OracleDbType.Varchar2, bid, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
            return dt;
        }

        // display trainer list using id
        public DataTable Admin_displayTrainerlist(int bid)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_displaytrainers", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_BID", OracleDbType.Varchar2, bid, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
            return dt;
        }

       
        // display assesor list using id
        public DataTable Admin_displayassesorlist(int bid)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("ADMIN_DISPLAYASSESORS", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_BID", OracleDbType.Varchar2, bid, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
            return dt;
        }


        internal DataSet Admin_GetUsersOverview()
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetUsersOverview", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR1", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR2", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR3", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR4", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }

            return ds;
        }

        internal DataSet Admin_GetPendingUsersOverview()
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetPendingUsersOverview", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR1", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR2", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }

            return ds;
        }

        internal DataSet Admin_GetTrainingOverview()
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetTrainingOverview", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR1", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR2", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR3", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("CUR4", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }

            return ds;
        }

        internal DataTable Admin_GetUsersByCategory(int pageno, int pagecount, string searchstring
            // , string from, string to, string sortstring
            )
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("Admin_GetUsersByCategory", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_PAGENO", OracleDbType.Int32, pageno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGECOUNT", OracleDbType.Int32, pagecount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SEARCHSTRING", OracleDbType.Varchar2, searchstring, ParameterDirection.Input));
                // cmd.Parameters.Add(new OracleParameter("V_FROM", OracleDbType.Varchar2, from, ParameterDirection.Input));
                // cmd.Parameters.Add(new OracleParameter("V_TO", OracleDbType.Varchar2, to, ParameterDirection.Input));
                // cmd.Parameters.Add(new OracleParameter("V_SORTSTRING", OracleDbType.Varchar2, sortstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }

            return dt;
        }

        internal DataTable Admin_GetPendingUsersByCategory(int pageno, int pagecount, string searchstring
            // , string from, string to, string sortstring
            )
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("Admin_GetPendingUsers", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_PAGENO", OracleDbType.Int32, pageno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGECOUNT", OracleDbType.Int32, pagecount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SEARCHSTRING", OracleDbType.Varchar2, searchstring, ParameterDirection.Input));
                //cmd.Parameters.Add(new OracleParameter("V_FROM", OracleDbType.Varchar2, from, ParameterDirection.Input));
                //cmd.Parameters.Add(new OracleParameter("V_TO", OracleDbType.Varchar2, to, ParameterDirection.Input));
                //cmd.Parameters.Add(new OracleParameter("V_SORTSTRING", OracleDbType.Varchar2, sortstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                throw new Exception();
            }

            return dt;
        }

        internal int Admin_ApproveUsers(string biodataid)
        {
            int resp = 0;
            OracleConnection conn = new OracleConnection();

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("Admin_ApproveUsers", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_BIODATAID", OracleDbType.Varchar2, biodataid, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ID", OracleDbType.Int32, ParameterDirection.Output));
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                resp = Convert.ToInt32(cmd.Parameters["V_ID"].Value.ToString());
            }
            catch
            {
                throw new Exception();
            }

            if (conn.State.ToString() != "Closed") conn.Close(); // close the oracle connection
            return resp;
        }

        internal DataTable Admin_GetTrainingCount()
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetTrainingCount", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable Admin_GetTrainingBatch(int pageno, int pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("Admin_GetTrainingBatch", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_PAGENO", OracleDbType.Int32, pageno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGECOUNT", OracleDbType.Int32, pagecount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SEARCHSTRING", OracleDbType.Varchar2, searchstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FROM", OracleDbType.Varchar2, from, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TO", OracleDbType.Varchar2, to, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SORTSTRING", OracleDbType.Varchar2, sortstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            return dt;
        }

        internal bool Admin_SaveTrainingInfo(string title, string description, string venue, string price, string duration, string startDate, string endDate)
        {
            long insertID = 0;
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();

            //format date
            DateTime StartDate = new DateTime(), EndDate = new DateTime();
            StartDate = Convert.ToDateTime(startDate);
            EndDate = Convert.ToDateTime(endDate);

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("Admin_SaveTrainingInfo", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_TITLE", OracleDbType.Varchar2, title.ToUpper(), ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_DESC", OracleDbType.Varchar2, description, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_VENUE", OracleDbType.Varchar2, venue, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PRICE", OracleDbType.Varchar2, price, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_DURATION", OracleDbType.Varchar2, duration, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_STARTDATE", OracleDbType.Date, StartDate, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ENDDATE", OracleDbType.Date, EndDate, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ID", OracleDbType.Int64, ParameterDirection.Output));
                cmd.ExecuteNonQuery();
                insertID = Convert.ToInt64(cmd.Parameters["V_ID"].Value.ToString());

            }
            catch
            {
                throw new Exception();
            }

            return insertID > 0 ? true : false;
        }

        internal DataTable Admin_GetPaymentItemsCount()
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetPaymentItemsCount", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable Admin_GetPaymentItemsBatch(int pageno, int pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("Admin_GetPaymentItemsBatch", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_PAGENO", OracleDbType.Int32, pageno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGECOUNT", OracleDbType.Int32, pagecount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SEARCHSTRING", OracleDbType.Varchar2, searchstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FROM", OracleDbType.Varchar2, from, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TO", OracleDbType.Varchar2, to, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SORTSTRING", OracleDbType.Varchar2, sortstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            return dt;
        }

        internal bool Admin_SavePaymentItem(string item, string description, string paymenttype, string price, int usertype)
        {
            long insertID = 0;
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("Admin_SavePaymentItem", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_ITEM", OracleDbType.Varchar2, item.ToUpper(), ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_DESC", OracleDbType.Varchar2, description, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAYMENTTYPE", OracleDbType.Varchar2, paymenttype, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PRICE", OracleDbType.Varchar2, price, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_USERTYPE", OracleDbType.Int32, usertype, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ID", OracleDbType.Int64, ParameterDirection.Output));
                cmd.ExecuteNonQuery();
                insertID = Convert.ToInt64(cmd.Parameters["V_ID"].Value.ToString());

            }
            catch
            {
                throw new Exception();
            }

            return insertID > 0 ? true : false;
        }

        internal DataTable Admin_GetPaymentHistoryCount()
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetPaymentHistoryCount", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable Admin_GetPaymentHistoryBatch(int pageno, int pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("Admin_GetPaymentHistoryBatch", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_PAGENO", OracleDbType.Int32, pageno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGECOUNT", OracleDbType.Int32, pagecount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SEARCHSTRING", OracleDbType.Varchar2, searchstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FROM", OracleDbType.Varchar2, from, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TO", OracleDbType.Varchar2, to, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SORTSTRING", OracleDbType.Varchar2, sortstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            return dt;
        }

        internal bool Admin_SaveNews(string title, string author, string body)
        {
            long insertID = 0;
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();

            try
            {
                conn = getConnection(); // connect to oracle
                if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("Admin_SaveNews", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_TITLE", OracleDbType.Varchar2, title, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_AUTHOR", OracleDbType.Varchar2, author, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_BODY", OracleDbType.Clob, body, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_ID", OracleDbType.Int64, ParameterDirection.Output));
                cmd.ExecuteNonQuery();
                insertID = Convert.ToInt64(cmd.Parameters["V_ID"].Value.ToString());

            }
            catch
            {
                throw new Exception();
            }

            return insertID > 0 ? true : false;
        }

        internal DataTable Admin_GetNewsCount()
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("Admin_GetNewsCount", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable Admin_GetNewsBatch(int pageno, int pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                //if (conn.State != ConnectionState.Open) conn.Open(); // open the oracle connection
                OracleCommand cmd = new OracleCommand("Admin_GetNewsBatch", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_PAGENO", OracleDbType.Int32, pageno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_PAGECOUNT", OracleDbType.Int32, pagecount, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SEARCHSTRING", OracleDbType.Varchar2, searchstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_FROM", OracleDbType.Varchar2, from, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_TO", OracleDbType.Varchar2, to, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_SORTSTRING", OracleDbType.Varchar2, sortstring, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("CUR", OracleDbType.RefCursor, ParameterDirection.Output));
                da = new OracleDataAdapter(cmd);
                da.Fill(dt);
            }
            catch
            {
                throw new Exception();
            }

            return dt;
        }

        internal DataTable GetTransactionDetails(string referenceno, string username)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetTransactionDetails", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_REFNO", OracleDbType.Varchar2, referenceno, ParameterDirection.Input));
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }

        internal DataTable GetUserInfoByUsername(string username)
        {
            DataSet ds = new DataSet();
            OracleConnection conn = new OracleConnection();
            OracleDataAdapter da;

            try
            {
                conn = getConnection(); // connect to oracle
                OracleCommand cmd = new OracleCommand("GetUserInfoByUsername", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("V_USERNAME", OracleDbType.Varchar2, username, ParameterDirection.Input));
                cmd.Parameters.Add("CUR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                da = new OracleDataAdapter(cmd);
                da.Fill(ds);
            }
            catch
            {
                throw new Exception();
            }

            return ds.Tables[0];
        }
    }
}