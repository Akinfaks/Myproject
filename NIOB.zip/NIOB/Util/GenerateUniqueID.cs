﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NIOB.Util
{
    public class GenerateUniqueID
    {
        private static Random rng = new Random(Environment.TickCount);

        public static string GetUID(int length)
        {
            var number = rng.NextDouble().ToString("0.000000000000").Substring(2, length);
            return number;
        }
    }
}