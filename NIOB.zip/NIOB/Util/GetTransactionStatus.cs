﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NIOB.Util
{
    public class TransactionStatus
    {
        internal static string GetStatus(int p)
        {
            switch (p)
            {
                case 0:
                    return "Initiated";
                case 1:
                    return "Successful";
                case 2:
                    return "Failed";
                case 3:
                    return "Cancelled";
                default:
                    return "";
            }
        }


        internal static int GetStatusID(string status)
        {
            switch (status)
            {
                case "Initiated":
                    return 0;
                case "Successful":
                    return 1;
                case "Failed":
                    return 2;
                case "Cancelled":
                    return 3;
                default:
                    return 0;
            }
        }
    }
}