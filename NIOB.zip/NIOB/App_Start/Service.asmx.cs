﻿using Newtonsoft.Json;
using NIOB.BusinessLogic;
using NIOB.BusinessObjects;
using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;

namespace NIOB.App_Start
{
    /// <summary>
    /// Summary description for Service
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class Service : System.Web.Services.WebService
    {
        Logic logic = new Logic();      //instantiate logic class
        ConnectionManager connMngr = new ConnectionManager();
       


        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetLGA(string stateid)
        {
            DataTable dt = new DataTable();
            dt = logic.GetLGA(stateid);

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string CheckUsername(string username)
        {
            DataTable dt = new DataTable();
            dt = logic.CheckUsername(username);

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string CheckEmail(string email)
        {
            DataTable dt = new DataTable();
            dt = logic.CheckEmail(email);

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetPaymentHistoryBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (identity.IsAuthenticated)
            {
                dt = logic.GetPaymentHistoryBatch(username, pageno, pagecount, searchstring, from, to, sortstring);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }
            
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetTransactionDetails(string referenceno)
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return "error";

            if (identity.IsAuthenticated)
            {
                dt = connMngr.GetTransactionDetails(referenceno, username);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetPaymentInfo()
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return "error";

            if (identity.IsAuthenticated)
            {
                dt = connMngr.GetUserPaymentInfo(username);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetPaymentLog()
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return "error";

            if (identity.IsAuthenticated)
            {
                dt = connMngr.GetUserPaymentLog(username);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        
        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetPaymentDue()
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (identity.IsAuthenticated)
            {
                dt = connMngr.GetPaymentDue(username);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }
        
        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetAvailableTrainingsBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;
            if (username == "") return "error";
            if (identity.IsAuthenticated)
            {
                dt = logic.GetAvailableTrainingsBatch(username, pageno, pagecount, searchstring, from, to, sortstring);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }
            
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetAvailableTrainings()
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return "error";

            if (identity.IsAuthenticated)
            {
                dt = connMngr.GetAvailableTrainings();

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public bool LogPaymentInfo(String refno, String table, String status)
        {
            bool resp = false;
            //get username
            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return false;

            if (identity.IsAuthenticated)
            {
                //log paymentlog to db
                Payment_Log paymentlog = new Payment_Log();
                paymentlog.ReferenceNo = refno;
                paymentlog.Status = TransactionStatus.GetStatusID(status);
                try
                {
                    logic.UpdatePaymentLog(username, paymentlog, getTable(table));
                    resp = true;
                }
                catch
                {
                    return false;
                }                 
            }
                       
            //send reference number to user email
            //
            //

            return resp;
        }

        private string getTable(string activeRedirect)
        {
            switch (activeRedirect)
            {
                case "Payment":
                    return "payment_info";
                case "Trainings":
                    return "training_info";
                default:
                    return "";
            }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetUserTrainingsBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;
            if (username == "") return "error";
            if (identity.IsAuthenticated)
            {
                dt = logic.GetUserTrainingsBatch(username, pageno, pagecount, searchstring, from, to, sortstring);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetUserTrainings(string filter)
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return "error";

            if (identity.IsAuthenticated)
            {
                dt = connMngr.GetUserTrainings(username, filter);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetNews()
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return "error";

            if (identity.IsAuthenticated)
            {
                dt = connMngr.GetNews();

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetUserTrainingsFilter(string filter)
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return "error";

            if (identity.IsAuthenticated)
            {
                dt = connMngr.GetUserTrainingsFilter(username, filter);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string ResendActivationLink(string email)
        {
            string result = logic.ResendActivationLink(email);
            return result;
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string ResendPassword(string email)
        {
            string result = logic.ResendPassword(email);
            return result;
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetTrainerInfo(string filter)
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return "error";

            if (identity.IsAuthenticated)
            {
                dt = connMngr.GetTrainerInfo(username, filter);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetTrainerInfoBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;
            if (username == "") return "error";
            if (identity.IsAuthenticated)
            {
                dt = logic.GetTrainerInfoBatch(username, pageno, pagecount, searchstring, from, to, sortstring);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetPhotographByID(string id)
        {
            DataTable dt = new DataTable();

            //IPrincipal principal = Thread.CurrentPrincipal;
            //IIdentity identity = principal == null ? null : principal.Identity;
            //String username = identity == null ? "" : identity.Name;
            //if (username == "") return "error";
            //if (identity.IsAuthenticated)
            //{
                dt = connMngr.GetPhotographByID(id);

                if (dt != null && dt.Rows.Count > 0)
                {
                    Byte[] bytes = (byte[])dt.Rows[0]["PHOTOGRAPH"];
                    String file = Convert.ToBase64String(bytes);
                    return file;
                }
                else { return ""; }
            //}

            //else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public bool UpdateTrainerAssessment(String id, String status, String result, String recommendation, String action)
        {  
            bool resp = false;
            //get username
            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return false;

            if (identity.IsAuthenticated)
            {
                if (logic.UpdateTrainerAssessment(username, id, status, result, recommendation, action) > 0)
                    resp = true;
            }

            return resp;
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetArtisanInfo(string filter)
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return "error";

            if (identity.IsAuthenticated)
            {
                dt = connMngr.GetArtisanInfo(username, filter);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string GetArtisanInfoBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;
            if (username == "") return "error";
            if (identity.IsAuthenticated)
            {
                dt = logic.GetArtisanInfoBatch(username, pageno, pagecount, searchstring, from, to, sortstring);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            }

            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public bool UpdateArtisanAssessment(String id, String status, String result, String recommendation, String action)
        {
            bool resp = false;
            //get username
            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            if (username == "") return false;

            if (identity.IsAuthenticated)
            {
                if (logic.UpdateArtisanAssessment(username, id, status, result, recommendation, action) > 0)
                    resp = true;
            }

            return resp;
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetOverview()
        {
            DataSet dt = new DataSet();

            //IPrincipal principal = Thread.CurrentPrincipal;
            //IIdentity identity = principal == null ? null : principal.Identity;
            //String username = identity == null ? "" : identity.Name;

            //if (username == "") return "error";

            //if (!identity.IsAuthenticated)
            //{
                dt = connMngr.Admin_GetOverview();

                if (dt != null && dt.Tables.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            //}

            //else { return ""; }
        }
        
        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetPaymentOverview()
        {
            DataSet dt = new DataSet();

            //IPrincipal principal = Thread.CurrentPrincipal;
            //IIdentity identity = principal == null ? null : principal.Identity;
            //String username = identity == null ? "" : identity.Name;

            //if (username == "") return "error";

            //if (identity.IsAuthenticated)
            //{
                dt = connMngr.Admin_GetPaymentOverview();

                if (dt != null && dt.Tables.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            //}

            //else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetUsersOverview()
        {
            DataSet dt = new DataSet();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            //if (username == "") return "error";

            //if (identity.IsAuthenticated)
            //{
                dt = connMngr.Admin_GetUsersOverview();

                if (dt != null && dt.Tables.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            //}

            //else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetTrainingOverview()
        {
            DataSet dt = new DataSet();

            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            String username = identity == null ? "" : identity.Name;

            //if (username == "") return "error";

            //if (identity.IsAuthenticated)
            //{
            dt = connMngr.Admin_GetTrainingOverview();

            if (dt != null && dt.Tables.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
            //}

            //else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetUsersByCategory(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();

            //IPrincipal principal = Thread.CurrentPrincipal;
            //IIdentity identity = principal == null ? null : principal.Identity;
            //String username = identity == null ? "" : identity.Name;
            //if (username == "") return "error";
            //if (identity.IsAuthenticated)
            //{
                dt = logic.Admin_GetUsersByCategory(pageno, pagecount, searchstring, from, to, sortstring);

                if (dt != null && dt.Rows.Count > 0)
                {
                    string json = JsonConvert.SerializeObject(dt);
                    return json;
                }
                else { return ""; }
            //}

            //else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public bool Admin_ApproveUsers(String biodataid)
        {
            if (connMngr.Admin_ApproveUsers(biodataid) > 0)
                return true;            

            return false;
                
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetPendingUsersByCategory(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();

            //IPrincipal principal = Thread.CurrentPrincipal;
            //IIdentity identity = principal == null ? null : principal.Identity;
            //String username = identity == null ? "" : identity.Name;
            //if (username == "") return "error";
            //if (identity.IsAuthenticated)
            //{
            dt = logic.Admin_GetPendingUsersByCategory(pageno, pagecount, searchstring, from, to, sortstring);

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
            //}

            //else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetPendingUsersOverview()
        {
            DataSet dt = new DataSet();

            //IPrincipal principal = Thread.CurrentPrincipal;
            //IIdentity identity = principal == null ? null : principal.Identity;
            //String username = identity == null ? "" : identity.Name;

            //if (username == "") return "error";

            //if (identity.IsAuthenticated)
            //{
            dt = connMngr.Admin_GetPendingUsersOverview();

            if (dt != null && dt.Tables.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
            //}

            //else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetTrainingCount()
        {
            DataTable dt = new DataTable();

            dt = connMngr.Admin_GetTrainingCount();

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetTrainingBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = logic.Admin_GetTrainingBatch(pageno, pagecount, searchstring, from, to, sortstring);

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_SaveTrainingInfo(string title, string description, string venue, string price, string duration, string startDate, string endDate)
        { 
            if (!validateParams(new string[] { title, description, venue, price, duration, startDate, endDate }))
            {
                return "error";
            }

            if (connMngr.Admin_SaveTrainingInfo(title, description, venue, price, duration, startDate, endDate))
            {
                return "true";
            }
            else { return "false"; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetPaymentItemsCount()
        {
            DataTable dt = new DataTable();

            dt = connMngr.Admin_GetPaymentItemsCount();

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetPaymentItemsBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = logic.Admin_GetPaymentItemsBatch(pageno, pagecount, searchstring, from, to, sortstring);

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_SavePaymentItems(string item, string description, string paymenttype, string price, string usertype)
        {
            //'{item:"' + item + '",description:"' + description + '",paymenttype:"' + paymenttype + '",price:"' + price + '",usertype:"' + usertype + '"}'
            if (!validateParams(new string[] { item, description, paymenttype, price, usertype }))
            {
                return "error";
            }

            if (connMngr.Admin_SavePaymentItem(item, description, paymenttype, price, UserType.getTypeID(usertype)))
            {
                return "true";
            }
            else { return "false"; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetPaymentHistoryCount()
        {
            DataTable dt = new DataTable();

            dt = connMngr.Admin_GetPaymentHistoryCount();

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetPaymentHistoryBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = logic.Admin_GetPaymentHistoryBatch(pageno, pagecount, searchstring, from, to, sortstring);

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_SaveNews(string title, string author, string body)
        {
            //'{item:"' + item + '",description:"' + description + '",paymenttype:"' + paymenttype + '",price:"' + price + '",usertype:"' + usertype + '"}'
            if (!validateParams(new string[] { title, author, body }))
            {
                return "error";
            }

            if (connMngr.Admin_SaveNews(title, author, body))
            {
                return "true";
            }
            else { return "false"; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetNewsCount()
        {
            DataTable dt = new DataTable();

            dt = connMngr.Admin_GetNewsCount();

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
        }

        [WebMethod()]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Admin_GetNewsBatch(string pageno, string pagecount, string searchstring, string from, string to, string sortstring)
        {
            DataTable dt = new DataTable();
            dt = logic.Admin_GetNewsBatch(pageno, pagecount, searchstring, from, to, sortstring);

            if (dt != null && dt.Rows.Count > 0)
            {
                string json = JsonConvert.SerializeObject(dt);
                return json;
            }
            else { return ""; }
        }

        private bool validateParams(string[] endDate)
        {
            foreach (var item in endDate)
            {
                if (String.IsNullOrEmpty(item)) return false;
            }
            return true;
        }
    }
}
