﻿using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Artisan
{
    public partial class UserProfile : System.Web.UI.Page
    {

        ConnectionManager connMgr = new ConnectionManager();
        long _biodataid = 0;
        DataTable displayProfile = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                _biodataid = Convert.ToInt64(Session["active_biodataid"]);

                displayProfile = connMgr.displayArtisanrProfile(_biodataid);

                if (displayProfile != null && displayProfile.Rows.Count > 0)
                {
                    title.Value = displayProfile.Rows[0]["TITLE"].ToString();
                    firstname.Value = displayProfile.Rows[0]["FIRSTNAME"].ToString();
                    lastname.Value = displayProfile.Rows[0]["SURNAME"].ToString();
                    gender.Value = displayProfile.Rows[0]["GENDER"].ToString();
                    dob.Value = displayProfile.Rows[0]["DOB"].ToString();
                    phonenumber.Value = displayProfile.Rows[0]["PHONENUMBER"].ToString();
                    email.Value = displayProfile.Rows[0]["EMAIL"].ToString();
                    //username.Value = displayProfile.Rows[0]["USERNAME"].ToString();
                    address.Value = displayProfile.Rows[0]["STREET"].ToString();
                    stateOfOrigin.Value = displayProfile.Rows[0]["STATENAME"].ToString();
                    stateOfOrigin.Value = displayProfile.Rows[0]["STATENAME"].ToString();

                    primary.Value = displayProfile.Rows[0]["PRIMARYSCH"].ToString();
                    secondary.Value = displayProfile.Rows[0]["SECONDARY"].ToString();

                    technical.Value = displayProfile.Rows[0]["TECHNICAL"].ToString();

                    primarycert.Value = displayProfile.Rows[0]["PRIMARY_CERT"].ToString();
                    secondarycert.Value = displayProfile.Rows[0]["SECONDARY_CERT"].ToString();
                    technicalcert.Value = displayProfile.Rows[0]["TECHNICAL_CERT"].ToString();
                    tertiarycert.Value = displayProfile.Rows[0]["TERTIARY_CERT"].ToString();

                    titledesg.Value = displayProfile.Rows[0]["OCCUPATION"].ToString();
                    scope.Value = displayProfile.Rows[0]["SCOPE"].ToString();
                    empname.Value = displayProfile.Rows[0]["EMPLOYER"].ToString();
                    appdate.Value = displayProfile.Rows[0]["STARTDATE"].ToString();


                }
            }
        }
    }
}