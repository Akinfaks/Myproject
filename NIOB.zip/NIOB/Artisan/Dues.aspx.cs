﻿using NIOB.BusinessLogic;
using NIOB.BusinessObjects;
using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Artisan
{
    public partial class Dues : System.Web.UI.Page
    {
        Logic logic = new Logic();
        String _username;

        protected void Page_Load(object sender, EventArgs e)
        {
            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            _username = identity == null ? "" : identity.Name;

            if (_username == "") Response.Redirect("../Login");

            if (!Page.IsPostBack)
            {
                List<Payment_Item> payItems = new List<Payment_Item>();

                //get payment items
                payItems = logic.GetPaymentItemsByCategory(UserType.getTypeID("Artisan"));


                //get user payment info
                List<Payment_Info> userpaymentinfo = new List<Payment_Info>();
                userpaymentinfo = logic.GetUserPaymentInfo(_username);

                string _htmlTable = "";

                if (payItems != null)
                {
                    int count = 0;
                    foreach (Payment_Item item in payItems)
                    {
                        if (CheckPaidItems(item.ID, userpaymentinfo))
                        {
                            _htmlTable += "<tr><th scope='row'><input type='checkbox' disabled='disabled'/></th><td>" + item.Item + "</td><td>" + item.Description + "</td><td> <b>PAID </b></td></tr>";
                        }
                        else
                        {
                            count++;
                            _htmlTable += "<tr id='payment_item_row" + count + "'><th scope='row'><input type='checkbox' onchange=\"addToPayment('payment_item_row" + count + "','" + item.ID + "','" + item.Price + "')\" id='cbox_" + item.ID + "'/></th><td>" + item.Item + "</td><td>" + item.Description + "</td><td> ₦ " + item.Price + ".00 </td></tr>";
                        }
                    }
                    _htmlTable += "<tr><th scope='row'></th><td></td><td><b>Total</b> </td><td><b id='total_payment'> ₦ 0 </b></td></tr>";
                }
                item_tbl_body.InnerHtml = _htmlTable;
            }
        }

        private bool CheckPaidItems(int id, List<Payment_Info> userpaymentinfo)
        {
            foreach (var info in userpaymentinfo)
            {
                if (info.ItemID == id && info.Status == 1)
                {
                    return true;
                }                
            }
            return false;
        }

        protected void makePayment_Click(object sender, EventArgs e)
        {
            String _selectedItems = selectedItems.Value;
            Session["selectedItems"] = _selectedItems;
            Response.Redirect("ConfirmPayment");
        }
    }
}