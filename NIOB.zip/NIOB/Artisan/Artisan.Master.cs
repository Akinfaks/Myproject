﻿using NIOB.BusinessLogic;
using NIOB.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Artisan
{
    public partial class Artisan : System.Web.UI.MasterPage
    {
        UserObject user = new UserObject();
        Logic logic = new Logic();
        string _username;
        long _biodataid = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal == null ? null : principal.Identity;
            _username = identity == null ? "" : identity.Name; 
            user = logic.GetInfoByUsername(_username);

            if (user != null)
            {
                //store username in cookie for frontend use
                HttpCookie userIdCookie = new HttpCookie("UserID");
                userIdCookie.Value = _username;
                Response.Cookies.Add(userIdCookie);

                //attach user info to display
                _biodataid = user.biodata.ID;
                Session["active_biodataid"] = _biodataid;

                user_fullname.InnerText = user.biodata.Firstname + " " + user.biodata.Surname;
                userimage.Src = "data:image/png;base64," + Convert.ToBase64String(user.photo.Photograph);
                user_memberid.InnerHtml = "MemberID: <b>" + user.biodata.UniqueID + "</b>";

                Session["user_biodata"] = user.biodata;
            }
        }

        
    }
}