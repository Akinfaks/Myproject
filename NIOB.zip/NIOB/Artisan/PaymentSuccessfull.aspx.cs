﻿using NIOB.BusinessLogic;
using NIOB.BusinessObjects;
using NIOB.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Artisan
{
    public partial class PaymentSuccessfull : System.Web.UI.Page
    {
        Logic logic = new Logic();
        String _username;
        SendEmail _mailService = new SendEmail();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //get username
                IPrincipal principal = Thread.CurrentPrincipal;
                IIdentity identity = principal == null ? null : principal.Identity;
                _username = identity == null ? "" : identity.Name;

                if (_username == "") Response.Redirect("../Login");

                //get refno from querystring
                string refno = Request.QueryString["refno"].ToString();
                refno_span.InnerText = refno;

                //get  user name and email
                Biodata biodata =  new Biodata();
                Tbl_User tbl_user = new Tbl_User();
                string _name = "";
                if (Session["user_tblinfo"] != null)
                {
                    tbl_user = (Tbl_User)Session["user_tblinfo"];                    
                }
                else
                {
                    //display email not sent msg
                }
                if (Session["user_biodata"] != null)
	            {
                    biodata = (Biodata)Session["user_biodata"];
                    _name = biodata.Title + " " + biodata.Surname;
                }
                else
                {
                    _name = _username;
                }

                DataTable dt2 = new DataTable();
                dt2 = logic.GetTransactionDetails(refno, _username);

                if(dt2 != null && dt2.Rows.Count > 0) {
                    //bool result = logic.sendMailtoUser(dt.Rows[0].["EMAIL"].ToString(), dt.Rows[0].["SURNAME"].ToString() 
                     //send confirmation mail to user email
                    string success_mail = "Dear " + _name + ",<br/><br/>" +
                               "Your transaction was completed successfully. Your transaction details is<br/><br/>" +
                               "Transaction ID: <b>" + refno + "</b><br/>" +
                               "Type: <b>" + dt2.Rows[0][0].ToString() + "</b><br/>" +
                               "Item/Title: <b>" + dt2.Rows[0][1].ToString() + "</b><br/>" +
                               "Description: <b>" + dt2.Rows[0]["DESCRIPTION"].ToString() + "</b><br/>" +
                               "Timestamp: <b>" + dt2.Rows[0]["DATECREATED"].ToString().Substring(0, 19).Replace('T', ' ') + "</b><br/><br/><br/>" +
                               "Thank you.";
                    bool sendMail = false;
                    try
                    {
                        sendMail = _mailService.sendMail(tbl_user.Email, "NIOB Transaction Successful", success_mail);
                    }
                    catch(Exception ex)
                    {

                    }
                }

                //get active redirect page
                String activeRedirect = Session["activeRedirect"].ToString();
                if (activeRedirect == "Dues")
                {
                    backtoprevious.Text = "  &laquo; Back to Dues & Levies";
                    backtoprevious.PostBackUrl = activeRedirect;
                }
                else if (activeRedirect == "Trainings")
                {
                    backtoprevious.Text = "  &laquo; Back to Available Trainings";
                    backtoprevious.PostBackUrl = activeRedirect;
                }
                else
                {
                    Response.Redirect("Home");
                }
                
                //send reference number to user email
                //
                //
            }             
        }
    }
}