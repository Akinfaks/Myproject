﻿var totalrecords = 0, totalpages = 0;
var _data = null, usertraining_data = null, userenrolledtraining = [];
var pagecount = 10, searchstring = "", from = "from", to = "to", sortstring = "sortstring";
var ongoingcount = 0, pendingcount = 0, completedcount = 0, approvedcount = 0;

//get total records
//Send the AJAX call to the server
function getTotalRecords() {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetAvailableTrainings",
        data: '',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            if (result.d != "") {
                if (data.length != 0) {
                    totalrecords = data.length;
                }
            }
        }
    });
}

function getUserTrainings() {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetUserTrainings",
        data: '{"filter":"' + searchstring + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            if (result.d != "") {
                if (data.length != 0) {
                    usertraining_data = data;
                    console.log(usertraining_data)
                    for (var i = 0; i < usertraining_data.length; i++) {
                        var item = usertraining_data[i];
                        userenrolledtraining.push(item.TRAININGID)
                    }
                }
            } else { totalrecords = 0; }
        }
    });
}


$(document).ready(function () {
    displayActiveMsg();
    getUserTrainings();
    populateAllTrainings();
    populateUserTrainings();
    
});

function populateAllTrainings() {
    //check total records for pagination
    getTotalRecords();

    //reset pagination
    $('#pagination').css('display', 'none');
    $('#pagination').empty();
    $('#pagination').removeData("twbs-pagination");
    $('#pagination').unbind("page");
    if (totalrecords == 0) {
        $('#norecord').html("<center>No record found</center>")
    }
    else {
        if (totalrecords % pagecount > 0) {
            totalpages = totalrecords / pagecount + 1;
        } else {
            totalpages = totalrecords / pagecount;
        }

        if (totalpages < 2) {
            $('#pagination').css('display', 'none');
        } else {
            $('#pagination').css('display', 'initial');
        }

        $('#pagination').twbsPagination({
            totalPages: totalpages,
            visiblePages: 3,
            onPageClick: function (event, page) {
                //$('#page-content').text('Page ' + page);
                var html = "";
                $.ajax({
                    type: "POST",
                    url: "../Service.asmx/GetAvailableTrainingsBatch",
                    data: '{pageno:"' + page + '",pagecount: "' + pagecount + '",searchstring: "' + searchstring + '",from: "' + from + '",to:"' + to + '",sortstring: "' + sortstring + '"}',
                    contentType: "application/json; charset=utf-8",
                    //dataType: "json",
                    async: true,
                    success: function (result) {
                        var data = eval(result.d);
                        if (result.d != "") {
                            if (data.length != 0) {
                                console.log(data)
                                $.each(data, function (index, item) {
                                    //html += "<tr class='tr_training'><td>" + item.R + "</td><td style='width:20%'>" + item.TITLE + "</td><td style='width:25%'>" + item.DESCRIPTION + "</td><td style='width:20%'>" + item.VENUE + "</td><td>" + item.DURATION + "</td><td>" + formatDate(item.STARTDATE) + "</td><td style='vertical-align:middle'><a href='#' class='btn btn-success' onclick='payTraining(\""+item.ID+"\")' style='border-radius: 3px;'><b>Apply</b> </a></td></tr>";

                                    var enrolbtnhtml = "";

                                    if (userenrolledtraining.indexOf(item.ID) > -1) {
                                        enrolbtnhtml = "<div class='search-actions text-center'><div class='blue bolder bigger-150' style='margin-top: 20px'><span class='text-info'>₦</span> " + formatPrice(item.PRICE) + "</div><a class='search-btn-action btn btn-sm btn-block btn-success' disabled='disabled'>Enrolled</a></div>";
                                    } else {
                                        enrolbtnhtml = "<div class='search-actions text-center'><div class='blue bolder bigger-150' style='margin-top: 20px'><span class='text-info'>₦</span> " + formatPrice(item.PRICE) + "</div><a class='search-btn-action btn btn-sm btn-block btn-info' onclick='payTraining(\"" + item.ID + "\")' >Enrol</a></div>";
                                    }



                                    html += " <div class='media search-media'><div class='media-left'><a><img class='media-object' src='http://via.placeholder.com/72/72' style='width: 72px; height: 72px;' /></a></div><div class='media-body'><div><h4 class='media-heading'><span class='blue'>" + item.TITLE + "</span></h4></div><p>" + item.DESCRIPTION + "</p><span class='small'>Starts " + formatDate(item.STARTDATE) + " &nbsp;&nbsp;Duration: " + item.DURATION + " </span>"+enrolbtnhtml+"</div></div><br />";



                                });
                                $("#panelbody").html(html);
                            }
                        }
                    }
                });
            }
        });
    }
}

function formatDate(dateString) {
    return dateString.split("T")[0];
}

function formatPrice(price) {
    console.log(price)
    var _res = "", count = 0;
    for (var i = price.length - 1; i >= 0; i--) {
        count++;
        _res = price[i].concat(_res);
        if (count % 3 == 0 && i != 0) {
            _res = ','.concat(_res);
        }
        
    }
    return _res;
}

function payTraining(id) {
    //call paystack payment gateway
    window.location = "ConfirmTraining?id=" + id;
}

function displayActiveMsg() {
    var url = window.location;
    $('.msg_trainings').css('display', 'none')
    //$('.navbtn').removeClass('active');
    

    if (url.href.indexOf('#') > -1) {
        var activebtn = url.href.split('#')[1];
        console.log(activebtn)
        //set active btn
        $('#' + activebtn.toLowerCase()).addClass('active');

        //display active message
        $('#msg_' + activebtn.toLowerCase()).css('display', 'inline-block');


        if (activebtn.toLowerCase() == 'mytrainings') {
            triggerUserTrainingBtn();
        }
    } else {
        //set active btn
        $('#alltrainings').addClass('active');

        //display active message
        $('#msg_alltrainings').css('display', 'inline-block');
    }
}

$('.navbtn').click(function () {
    //set active btn
    $('.navbtn').removeClass('active');
    $('#' + this.id).addClass('active');

    //display message
    if (this.id == 'alltrainings') {
        $('.msg_trainings').css('display', 'none');
        $('#msg_alltrainings').css('display', 'inline-block');
    } else {
        $('.msg_trainings').css('display', 'none');
        $('#msg_mytrainings').css('display', 'inline-block');
        $('#' + this.id).addClass('active');
    }
    if (this.id == 'mytrainings') {
        $('#activetrainings').addClass('active');
    }
    //$('#panelbody').html('');

})

function formatDate(dateString) {
    return dateString.split("T")[0];
}

function getStatus(statusid) {
    switch (statusid) {
        case 1:
            return "PENDING";
        case 2:
            return "ONGOING";
        case 3:
            return "COMPLETED";
        case 4:
            return "APPROVED";
        default:
            return "";
    }
}

function getStatusID(status) {
    switch (status) {
        case "PENDING":
            return 1;
        case "ONGOING":
            return 2;
        case "COMPLETED":
            return 3;
        case "APPROVED":
            return 4;
        default:
            return 0;
    }
}

function setCount(statusid) {
    switch (statusid) {
        case 1:
            //"PENDING";
            pendingcount++; break;
        case 2:
            //"ONGOING";
            ongoingcount++; break;
        case 3:
            //"COMPLETED";
            completedcount++; break;
        case 4:
            //"APPROVED";
            approvedcount++; break;
        default:
            break;
    }
}

function populateUserTrainings() {
    $('#norecord').html(""); var cnt = 0, cnt2 = 0, cnt3 = 0;
    if (usertraining_data != null) {
        //_data = data;
        var html = "", html2 = "", html3 = "";
        

        $.each(usertraining_data, function (index, item) {
            var trainingstatus = getTrainingStatus(item.STARTDATE, item.ENDDATE);

            if (trainingstatus == 'Active') {
                html += " <div class='media search-media'><div class='media-left'><a><img class='media-object' src='http://via.placeholder.com/72/72' style='width: 72px; height: 72px;' /></a></div><div class='media-body'><div><h4 class='media-heading'><span class='blue'>" + item.TITLE + "</span></h4></div><p>" + item.DESCRIPTION + "</p><span class='small'>Started " + formatDate(item.STARTDATE) + " &nbsp;&nbsp;Ends " + formatDate(item.ENDDATE) + " </span><div class='search-actions text-center'><div class='blue bolder bigger-150' style='margin-top: 20px'>" + trainingstatus + "</div></div></div></div><br />";
                cnt++;
            }
            else if (trainingstatus == 'Upcoming')
            {
                html2 += " <div class='media search-media'><div class='media-left'><a><img class='media-object' src='http://via.placeholder.com/72/72' style='width: 72px; height: 72px;' /></a></div><div class='media-body'><div><h4 class='media-heading'><span class='blue'>" + item.TITLE + "</span></h4></div><p>" + item.DESCRIPTION + "</p><span class='small'>Starts " + formatDate(item.STARTDATE) + " &nbsp;&nbsp;Duration " + item.DURATION + " </span><div class='search-actions text-center'><div class='blue bolder bigger-150' style='margin-top: 20px'>" + trainingstatus + "</div></div></div></div><br />";
                cnt2++;
            }

            else if (trainingstatus == 'Completed')
            {
                html3 += " <div class='media search-media'><div class='media-left'><a><img class='media-object' src='http://via.placeholder.com/72/72' style='width: 72px; height: 72px;' /></a></div><div class='media-body'><div><h4 class='media-heading'><span class='blue'>" + item.TITLE + "</span></h4></div><p>" + item.DESCRIPTION + "</p><span class='small'>Ended " + formatDate(item.ENDDATE) + " </span><div class='search-actions text-center'><div class='blue bolder bigger-150' style='margin-top: 20px'>" + trainingstatus + "</div></div></div></div><br />";
                cnt3++;
            }

            //setCount(item.Status);
        });

        
        $("#panelbody_activetrainings").html(html != "" ? html : "<center>You have <b>0</b> active training</center>");
        $("#panelbody_upcomingtrainings").html(html2 != "" ? html2 : "<center>You have <b>0</b> upcoming training</center>");
        $("#panelbody_completedtrainings").html(html3 != "" ? html3 : "<center>You have <b>0</b> completed training</center>");

        $("#activetrainingcount").html('(' + cnt + ')');
        $("#upcomingtrainingcount").html('(' + cnt2 + ')');
        $("#completedtrainingcount").html('(' + cnt3 + ')');

    }
    else {
        $('#norecord').html("<center>No record found</center>")
        $("#activetrainingcount").html('(' + cnt + ')');
        $("#upcomingtrainingcount").html('(' + cnt2 + ')');
        $("#completedtrainingcount").html('(' + cnt3 + ')');
    }
}

function triggerUserTrainingBtn() {
    $("#mytrainings").css('display', 'none');
    $(".mytraining_submenu").css('display', 'initial');
    
    $('#activetrainings').addClass('active');
}

function triggerAllTrainingBtn() {    
    $("#mytrainings").css('display', 'initial');
    $(".mytraining_submenu").css('display', 'none');

}

function getTrainingStatus(startdate, enddate) {
    var _startdate = new Date(startdate);
    var _enddate = new Date(enddate);
    var datenow = Date.now();
    console.log(_startdate.getTime())
    console.log(datenow)
    if (datenow < _startdate.getTime()) {
        return 'Upcoming';
    }

    else if (datenow > _enddate.getTime()) {
        return 'Completed';
    }

    else if (datenow < _enddate && datenow > _startdate) {
        return 'Active';
    }
}

$('.mytraining_submenu').click(function () {
    var top = $('#panelbody_' + this.id).position().top;
    $(window).scrollTop(top);
})
