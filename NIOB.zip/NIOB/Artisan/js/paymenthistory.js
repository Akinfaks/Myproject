﻿var totalrecords = 0, totalpages = 0;
var pagecount = 10, searchstring = "searchstring", from = "from", to = "to", sortstring = "sortstring";

//get total records
//Send the AJAX call to the server
$(function () {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetPaymentLog",
        data: '',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            if (result.d != "") {
                var count = 0;
                if (data.length != 0) {
                    $.each(data, function (index, item) {
                        if (item.STATUS == "1") count++;
                    });

                    totalrecords = count;
                }
            }
        }
    });
})

$(document).ready(function () {
    //check total records
    if (totalrecords == 0) {
        $('#norecord').html("<center>No record found</center>")
        $('#spinner-loader').css('display','none')
    }
    else {
        if (totalrecords % pagecount > 0) {
            totalpages = totalrecords / pagecount + 1;
        } else {
            totalpages = totalrecords / pagecount;
        }

        //reset pagination
        $('#pagination').css('display', 'none');
        $('#pagination').empty();
        $('#pagination').removeData("twbs-pagination");
        $('#pagination').unbind("page");

        if (totalpages < 2) {
            $('#pagination').css('display', 'none');
        } else {
            $('#pagination').css('display', 'initial');
        }

        $('#pagination').twbsPagination({
            totalPages: totalpages,
            visiblePages: 5,
            onPageClick: function (event, page) {
                //$('#page-content').text('Page ' + page);
                var html = "";
                $.ajax({
                    type: "POST",
                    url: "../Service.asmx/GetPaymentHistoryBatch",
                    data: '{pageno:"' + page + '",pagecount: "' + pagecount + '",searchstring: "' + searchstring + '",from: "' + from + '",to:"' + to + '",sortstring: "' + sortstring + '"}',
                    contentType: "application/json; charset=utf-8",
                    //dataType: "json",
                    async: true,
                    success: function (result) {
                        //console.log(result)
                        var data = eval(result.d);
                        if (result.d != "") {
                            if (data.length != 0) {
                                var count = 0;
                                $.each(data, function (index, item) {
                                    count++;
                                    var altColor = count % 2 == 0 ? "background-color: #fbfbfb" : "";
                                    var status = item.STATUS == "1" ? "Success" : "Failed";
                                    html += "<tr data-toggle='modal' data-target='#myModal' style='height:50px; cursor: pointer;" + altColor + "' onclick='displayTransaction(\"" + item.REFERENCENO + "\")'><td>" + count + "</td><td>" + item.REFERENCENO + "</td><td>" + item.PAYMENTTYPE + "</td><td> ₦ " + item.AMOUNT + "</td><td>" + formatDate(item.DATECREATED) + "</td><td>" + status + "</td></tr>";
                                });
                                $("#tbody").html(html);
                                $('#spinner-loader').css('display', 'none')
                            }
                        }
                    }
                });
            }
        });
    }    
});

function formatDate(dateString) {
    return dateString.substring(0, 16).replace("T", " ");
}

function formatDate3(dateString) {
    return dateString.substring(0, 19).replace("T", " ");
}

function displayTransaction(refno) {
    $('#modal_refno').html('&nbsp;&nbsp;&nbsp;Reference ID: ' + refno)
    $('#modal_totalamount').html(''); $('#modal_date').html(''); $('#modalDisplay').html('<center><i class="fa fa-spinner fa-spin"></i></center>')
    
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetTransactionDetails",
        data: '{referenceno: "' + refno + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: true,
        success: function (result) {
            var data = eval(result.d);
            if (result.d != "") {
                
                if (data.length != 0) {
                    var html = "";
                    if (data[0].TYPE == 'Dues') {
                        var computed_price = 0;
                        $.each(data, function (index, item) {
                            html += "<div class='media search-media'><div class='media-left'></div><div class='media-body'><div><h4 class='media-heading'><span class='blue'>" + item.ITEM + "</span></h4></div><p>" + item.DESCRIPTION + "</p><div class='search-actions text-center'><div class='blue bolder bigger-150'><span class='text-info'>₦</span> " + formatPrice(item.PRICE) + "</div><span class='search-btn-action btn btn-sm btn-block btn-info' style='cursor: default'>Success</span></div></div></div><br />";

                            computed_price += parseInt(item.PRICE);
                        });
                        console.log(computed_price)
                        $('#modal_totalamount').html('Total &nbsp;&nbsp;&nbsp;&nbsp;<b> ₦ ' + formatPrice(computed_price.toString()) + '</b>');
                        $('#modal_date').html('&nbsp;&nbsp;&nbsp;Timestamp: ' + formatDate3(data[0].DATECREATED));
                    }
                    else if (data[0].TYPE == 'Training') {
                        var item = data[0];
                        var trainingstatus = getTrainingStatus(item.STARTDATE, item.ENDDATE);
                        html = "<div class='media search-media'><div class='media-left'><a><img class='media-object' src='http://via.placeholder.com/72/72' style='width: 72px; height: 72px;' /></a></div><div class='media-body'><div><h4 class='media-heading'><span class='blue'>" + item.TITLE + "</span></h4></div><p>" + item.DESCRIPTION + "</p><span class='small'>Starts " + formatDate2(item.STARTDATE) + " &nbsp;&nbsp;Ends " + formatDate2(item.ENDDATE) + " </span><div class='search-actions text-center'><div class='blue bolder bigger-150' style='margin-top: 20px'>" + trainingstatus + "</div></div></div></div><br />";

                        $('#modal_date').html('&nbsp;&nbsp;&nbsp;Timestamp: ' + formatDate3(item.DATECREATED));
                        $('#modal_totalamount').html('Amount &nbsp;&nbsp;&nbsp;&nbsp;<b> ₦ ' + formatPrice(item.PRICE) + '</b>')
                    }
                    
                    $('#modalDisplay').html(html)
                } else {
                    $('#modalDisplay').html('<center>no record found!</center>')

                }
            } else {
                $('#modalDisplay').html('<center>no record found!</center>')

            }
        },
        error: function (xhr, status, error) {
            console.log('error: ' +error)
        }
    });

}

function getTrainingStatus(startdate, enddate) {
    var _startdate = new Date(startdate);
    var _enddate = new Date(enddate);
    var datenow = Date.now();
    if (datenow < _startdate.getTime()) {
        return 'Upcoming';
    }

    else if (datenow > _enddate.getTime()) {
        return 'Completed';
    }

    else if (datenow < _enddate && datenow > _startdate) {
        return 'Active';
    }
}

function formatDate2(dateString) {
    return dateString.split("T")[0];
}

function formatPrice(price) {
    console.log(price)
    var _res = "", count = 0;
    for (var i = price.length - 1; i >= 0; i--) {
        count++;
        _res = price[i].concat(_res);
        if (count % 3 == 0 && i != 0) {
            _res = ','.concat(_res);
        }

    }
    return _res;
}