﻿var totalrecords = 0, totalpages = 0;
var pagecount = 10, searchstring = "searchstring", from = "from", to = "to", sortstring = "sortstring";

//get total records
//Send the AJAX call to the server
$(function () {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetAvailableTrainings",
        data: '',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            if (result.d != "") {
                if (data.length != 0) {
                    totalrecords = data.length;
                }
            }
        }
    });
})

$(document).ready(function () {
    //check total records
    if (totalrecords == 0) {
        $('#norecord').html("<center>No record found</center>")
    }
    else {
        if (totalrecords % pagecount > 0) {
            totalpages = totalrecords / pagecount + 1;
        } else {
            totalpages = totalrecords / pagecount;
        }

        $('#pagination').twbsPagination({
            totalPages: totalpages,
            visiblePages: 3,
            onPageClick: function (event, page) {
                //$('#page-content').text('Page ' + page);
                var html = "";
                $.ajax({
                    type: "POST",
                    url: "../Service.asmx/GetAvailableTrainingsBatch",
                    data: '{pageno:"' + page + '",pagecount: "' + pagecount + '",searchstring: "' + searchstring + '",from: "' + from + '",to:"' + to + '",sortstring: "' + sortstring + '"}',
                    contentType: "application/json; charset=utf-8",
                    //dataType: "json",
                    async: true,
                    success: function (result) {
                        var data = eval(result.d);
                        if (result.d != "") {
                            if (data.length != 0) {
                                console.log(data)
                                $.each(data, function (index, item) {
                                    html += "<tr class='tr_training'><td>" + item.R + "</td><td style='width:20%'>" + item.TITLE + "</td><td style='width:25%'>" + item.DESCRIPTION + "</td><td style='width:20%'>" + item.VENUE + "</td><td>" + item.DURATION + "</td><td>" + formatDate(item.STARTDATE) + "</td><td style='vertical-align:middle'><a href='#' class='btn btn-success' onclick='payTraining(\""+item.ID+"\")' style='border-radius: 3px;'><b>Apply</b> </a></td></tr>";
                                });
                                $("#tbody").html(html);
                            }
                        }
                    }
                });
            }
        });
    }
});

function formatDate(dateString) {
    return dateString.split("T")[0];
}

function payTraining(id) {
    //call paystack payment gateway
    window.location = "ConfirmTraining?id=" + id;
}


