﻿var totalrecords = 0, totalpages = 0, _data = null;
var pagecount = 10, searchstring = "", from = "from", to = "to", sortstring = "sortstring";
var ongoingcount = 0, pendingcount = 0, completedcount = 0, approvedcount = 0;
//var url = "../Service.asmx/GetUserTrainingsBatch";

//get total records
//Send the AJAX call to the server
$(function () {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetUserTrainings",
        data: '{"filter":""}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            if (result.d != "") {
                if (data.length != 0) {
                    totalrecords = data.length;
                }
            }
        }
    });
})

$(document).ready(function () {
    populateTable();
});

function formatDate(dateString) {
    return dateString.split("T")[0];
}

function getStatus(statusid) {
    switch (statusid) {
        case 1:
            return "PENDING";
        case 2:
            return "ONGOING";
        case 3:
            return "COMPLETED";
        case 4:
            return "APPROVED";
        default:
            return "";
    }
}

function getStatusID(status) {
    switch (status) {
        case "PENDING":
            return 1;
        case "ONGOING":
            return 2;
        case "COMPLETED":
            return 3;
        case "APPROVED":
            return 4;
        default:
            return 0;
    }
}

function setCount(statusid) {
    switch (statusid) {
        case 1:
            //"PENDING";
            pendingcount++; break;
        case 2:
            //"ONGOING";
            ongoingcount++; break;
        case 3:
            //"COMPLETED";
            completedcount++; break;
        case 4:
            //"APPROVED";
            approvedcount++; break;
        default:
            break;
    }
}

//manage tab filter on click
$("ul li a").click(function (event) {

    //reset pagination
    $('#pagination').empty();
    $('#pagination').removeData("twbs-pagination");
    $('#pagination').unbind("page");

    var html = ""; $("#norecord").html(""); $("#tbody").html("");
    var filter = event.toElement.innerText;
    searchstring = getStatusID(filter);
    if (searchstring == "0") searchstring = "";
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetUserTrainings",
        data: '{"filter":"' + searchstring + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            if (result.d != "") {
                if (data.length != 0) {
                    totalrecords = data.length;
                }
            } else { totalrecords = 0; }
        }
    });
    populateTable();
})

function populateTable() {
    //check total records
    if (totalrecords == 0) {
        $('#norecord').html("<center>No record found</center>")
    }
    else {
        if (totalrecords % pagecount > 0) {
            totalpages = totalrecords / pagecount + 1;
        } else {
            totalpages = totalrecords / pagecount;
        }
        console(totalpages)
        $('#pagination').twbsPagination({
            totalPages: totalpages,
            visiblePages: 3,
            onPageClick: function (event, page) {
                //$('#page-content').text('Page ' + page);
                var html = "";
                $.ajax({
                    type: "POST",
                    url: "../Service.asmx/GetUserTrainingsBatch",
                    data: '{pageno:"' + page + '",pagecount: "' + pagecount + '",searchstring: "' + searchstring + '",from: "' + from + '",to:"' + to + '",sortstring: "' + sortstring + '"}',
                    contentType: "application/json; charset=utf-8",
                    //dataType: "json",
                    async: true,
                    success: function (result) {

                        var data = eval(result.d);
                        if (result.d != "") {
                            if (data.length != 0) {
                                _data = data;
                                $.each(data, function (index, item) {
                                    html += "<tr class='tr_training'><td>" + item.R + "</td><td style='width:20%'>" + item.TITLE + "</td><td style='width:25%'>" + item.DESCRIPTION + "</td><td style='width:20%'>" + item.VENUE + "</td><td>" + item.DURATION + "</td><td>" + formatDate(item.STARTDATE) + "</td><td><b style='color:green'>" + getStatus(item.STATUS) + "</b></td></tr>";
                                    setCount(item.Status);
                                });
                                $("#tbody").html(html);
                            }
                        }
                    }
                });
            }
        });
    }
}


