﻿var activeNews; var _data;

//manage advert slide
var currentIndex = 0,
  items = { 0: "../Content/advertimages/Untitled2.jpg", 1: "../Content/advertimages/confirmmeee.jpg", 2: "../Content/advertimages/Untitled.jpg", 3: "../Content/advertimages/confirmmeee.jpg" },
  itemAmt = items.length;

//src = "../Content/images/confirmmeee.jpg"
$('#advert_img').attr("src", items[currentIndex]);
var autoSlide = setInterval(function () {
    currentIndex += 1;
    if (currentIndex > itemAmt - 1) {
        currentIndex = 0;
    }
    $('#advert_img').attr("src", items[currentIndex]);
    //cycleItems();
}, 10000);

function togglePanel(link, id) {
    console.log($($(link).children()[1]))
    sessionStorage["activeNews"] = id;
    if (!hasClass($($(link).children()[1]), "in")) {
        //$(link).addClass("spacebelow");
        var html = "", activeHtml = "";
        for (var i = 0; i < _data.length; i++) {
            var item = _data[i];
            if (item.ID == sessionStorage["activeNews"]) {
                activeHtml = loadOtherHtml(item)
                continue;   
            }
            html += loadOtherHtml(item);                
        }
        $("#newslist").html(activeHtml + html);
        $("body").scrollTop(0);
        sessionStorage.removeItem("activeNews");
    } else {
        $(link).removeClass("spacebelow");
    }  
}

function hasClass(element, cls) {    
    return (' ' + element[0].className + ' ').indexOf(' ' + cls + ' ') > -1;
}

//get total records
//Send the AJAX call to the server
$(function () {
    $.ajax({
        type: "POST",
        url: "../Service.asmx/GetNews",
        data: '',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (result) {
            var data = eval(result.d);
            if (result.d != "") {
                if (data.length != 0) {
                    console.log(data)
                    var html = "", activeHtml = "";
                    var spacebelow = "", collapsein = "";
                    _data = data;
                    for (var i = 0; i < data.length; i++) {
                        var item = data[i];
                        if (sessionStorage["activeNews"] != null) {
                            if (item.ID == sessionStorage["activeNews"]) 
                                activeHtml = loadActiveHtml(item)
                            else 
                                html += loadOtherHtml(item);
                        }
                        else
                        {
                            if (i == 0) 
                                activeHtml = loadActiveHtml(item);
                            else 
                                html += loadOtherHtml(item);                            
                        }
                    }
                    $("#newslist").html(activeHtml + html);
                }
            }
        }
    });
})

function formatDate(dateString) {
    //var time = moment(dateString).format('ddd MMMM Do YYYY, h:mm:ss a');
    var time = moment(dateString).format('llll');

    return time;
}

function loadActiveHtml(item) {
   //var headertitle = (item.TITLE).slice(0, 50);
    return "<div><div class='panel panel-default spacebelow' style='border: 0;' onclick='togglePanel(this, " + item.ID + ")'><div class='panel-heading'><div class='panel-title'><a data-toggle='collapse' data-parent='#accordion' href='#" + item.ID + "' style='text-decoration: none; background-color: #fefefe'><i class='fa fa-bars' style='color: #2d8035' aria-hidden='true'></i><b style='color: #0026ff'>&nbsp;&nbsp;&nbsp;" + item.TITLE + "</b><span style='margin-left:20px;color:#000'></span></a></div></div><div id='" + item.ID + "' class='panel-collapse collapse in' style='background-color: #fefefe'><div class='panel-body'><h2>" + item.TITLE + "</h2><span class='pull-right' style='font-family: Calibri; color: deepseagreen'>" + formatDate(item.DATECREATED) + "</span><br /><h5 style='line-height: 200%;'>" + item.BODY + "</h5></div></div></div></div>";
}

function loadOtherHtml(item) {
    //var headertitle = (item.TITLE).slice(0, 50);
    return "<div><div class='panel panel-default' style='border: 0;' onclick='togglePanel(this, " + item.ID + ")'><div class='panel-heading'><div class='panel-title'><a data-toggle='collapse' data-parent='#accordion' href='#" + item.ID + "' style='text-decoration: none; background-color: #fefefe'><i class='fa fa-bars' style='color: #2d8035' aria-hidden='true'></i><b style='color: #0026ff'>&nbsp;&nbsp;&nbsp;" + item.TITLE + "</b><span style='margin-left:20px;color:#000'></span></a></div></div><div id='" + item.ID + "' class='panel-collapse collapse' style='background-color: #fefefe'><div class='panel-body'><h2>" + item.TITLE + "</h2><span class='pull-right' style='font-family: Calibri; color: deepseagreen'>" + formatDate(item.DATECREATED) + "</span><br /><h5 style='line-height: 200%;'>" + item.BODY + "</h5></div></div></div></div>";
}



//function cycleItems() {
//    var item = $('#advert_img').attr("src", "../Content/advertimages/confirmmeee.jpg");
//    items.hide();
//    $('#advert_img').attr("src", "../Content/advertimages/confirmmeee.jpg");
//}


