﻿using NIOB.BusinessLogic;
using NIOB.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NIOB.Artisan
{
    public partial class ConfirmTraining : System.Web.UI.Page
    {
        Logic logic = new Logic();
        String _username;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //get username
                IPrincipal principal = Thread.CurrentPrincipal;
                IIdentity identity = principal == null ? null : principal.Identity;
                _username = identity == null ? "" : identity.Name;

                if (_username == "")
                    Response.Redirect("../Login", true);

                //get user info by username
                DataTable dt = logic.GetUserInfoByUsername(_username);
                email.Value = dt.Rows[0]["EMAIL"].ToString();

                //set price and refno variables
                int _totalprice = 0;
                string _refno;
                //get selected item
                string id = Request.QueryString["id"];

                //get and check if refno exist in paymentlog table, if true, regenerate
                _refno = Guid.NewGuid().ToString().Replace("-", "").Substring(0, 20).ToUpper();

                //get payment item class
                AvailableTraining training = new AvailableTraining();
                training = logic.GetTrainingByID(id);

                //get payment info class
                Training_Info traininginfo = new Training_Info();
                if (traininginfo != null)
                {
                    traininginfo.TrainingID = training.ID;
                    traininginfo.TrainingName = training.Title;
                    traininginfo.ReferenceNo = _refno;
                    traininginfo.Status = 0;

                    //save transaction in paymentinfo(individual payment item)
                    logic.InsertUserTrainingInfo(_username, traininginfo);


                    //get payment lgo class
                    Payment_Log paylog = new Payment_Log();
                    paylog.PaymentType = "Training";
                    paylog.Amount = training.Price;
                    paylog.ReferenceNo = _refno;
                    paylog.Status = 0;

                    //save transaction in paymentlog (one per transaction)
                    logic.InsertPaymentLog(_username, paylog);

                    price.Value = (Convert.ToInt32(training.Price) * 100).ToString();
                    refno.Value = _refno;
                    Session["activeRedirect"] = "Trainings";
                }
            }
            else
            {
                Response.Redirect("AvailableTrainings");
            }

        }
    }
}